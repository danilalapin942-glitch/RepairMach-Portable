from __future__ import annotations

import csv
import json
import math
import os
import shutil
import subprocess
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path


WORKSPACE = Path(r"C:\Users\admin\.codex\.chatgpt-projects\g-p-6910508be2a081919b9cb5881a96c92b")
HERE = Path(__file__).resolve().parent
SOURCE_DIR = WORKSPACE / "repeat_mig25rb_2026-09-01"
APP = WORKSPACE / "github_publish" / "RepairMach-Portable" / "app"
sys.path.insert(0, str(APP))

from vspaero_runner import generate_vspaero_sweep_script, parse_set_report


EXE = Path(r"C:\OpenVSP-3.51.1-win64-Python3.13\OpenVSP-3.51.1-win64\vspscript.exe")
RUNS = HERE / "runs"
STATUS = HERE / "status.json"
SUMMARY = HERE / "run_summary.csv"

SREF = 660.904
CREF = 16.378
BREF = 43.898

# Dense supersonic strip.  The alpha range lets us compare centered,
# one-degree and least-squares lift-curve slopes without changing geometry.
MACHS = (1.35, 1.40, 1.50, 1.60, 1.70, 1.90, 2.20)
ALPHAS = (-0.5, 0.0, 0.5, 1.0)
CONFIGS = {
    "full": SOURCE_DIR / "MiG-25RB_VSPAero_Wing_v2.vsp3",
    "thin_all": SOURCE_DIR / "component_thin_all.vsp3",
}
# Valid points finish in 4–8 s on this machine.  A much longer process is a
# divergent VSPAERO resonance, so terminate it early and use the documented
# symmetric Mach-offset recovery instead.
POINT_TIMEOUT_SECONDS = 30
ENABLE_OFFSET_RECOVERY = False


def now() -> datetime:
    return datetime.now(timezone.utc)


def tag(value: float) -> str:
    return f"{value:.3f}".rstrip("0").rstrip(".").replace("-", "m").replace(".", "p")


def case_id(config: str, mach: float, alpha: float) -> str:
    return f"{config}_M{tag(mach)}_A{tag(alpha)}"


def read_series(path: Path) -> dict[str, list[float]]:
    series: dict[str, list[float]] = {}
    if not path.is_file():
        return series
    with path.open("r", encoding="utf-8-sig", errors="replace", newline="") as stream:
        for row in csv.reader(stream):
            if not row:
                continue
            values: list[float] = []
            for raw in row[1:]:
                try:
                    value = float(raw)
                except ValueError:
                    continue
                # Preserve non-finite terminal values.  Dropping NaN here
                # would incorrectly expose the preceding finite iteration as
                # the converged result.
                values.append(value)
            if values and row[0].strip() not in series:
                series[row[0].strip()] = values
    return series


def last(series: dict[str, list[float]], key: str):
    values = series.get(key)
    return values[-1] if values else None


def finite_or_none(value):
    return value if value is not None and math.isfinite(value) else None


def process_ids(image: str) -> set[int]:
    proc = subprocess.run(
        ["tasklist", "/FI", f"IMAGENAME eq {image}", "/FO", "CSV", "/NH"],
        capture_output=True,
        text=True,
        errors="replace",
        check=False,
    )
    result: set[int] = set()
    for row in csv.reader((proc.stdout or "").splitlines()):
        if len(row) >= 2 and row[0].lower() == image.lower():
            try:
                result.add(int(row[1]))
            except ValueError:
                pass
    return result


def kill_pid(pid: int) -> None:
    subprocess.run(
        ["taskkill", "/PID", str(pid), "/T", "/F"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        timeout=12,
        check=False,
    )


def execute(script: Path, run_dir: Path, log: Path) -> tuple[int, float]:
    baseline = process_ids("vspaero.exe")
    started = time.monotonic()
    with log.open("w", encoding="utf-8", errors="replace") as stream:
        proc = subprocess.Popen(
            [str(EXE), "-script", str(script)],
            cwd=str(run_dir),
            stdout=stream,
            stderr=subprocess.STDOUT,
            creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0),
        )
        try:
            return_code = int(proc.wait(timeout=POINT_TIMEOUT_SECONDS) or 0)
        except subprocess.TimeoutExpired:
            kill_pid(proc.pid)
            for child in process_ids("vspaero.exe") - baseline:
                kill_pid(child)
            return_code = 124
    return return_code, time.monotonic() - started


def numerical_quality(data: dict[str, list[float]]) -> tuple[bool, dict]:
    values = {
        "Cy": finite_or_none(last(data, "CLtot")),
        "CDi": finite_or_none(last(data, "CDi")),
        "CDo": finite_or_none(last(data, "CDo")),
        "log10_L2": finite_or_none(last(data, "log10( L2Residual )")),
        "log10_max": finite_or_none(last(data, "log10( MaxResidual )")),
    }
    valid = (
        values["Cy"] is not None
        and abs(values["Cy"]) < 1.0
        and values["CDi"] is not None
        and abs(values["CDi"]) < 10.0
        and values["log10_L2"] is not None
        and values["log10_L2"] < -0.3
    )
    return valid, values


def load_cached(path: Path, results: Path, target_mach: float, mach_offset: float) -> dict | None:
    if not path.is_file():
        return None
    try:
        row = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    data = read_series(results)
    valid, values = numerical_quality(data)
    row.update(
        target_mach=target_mach,
        mach=target_mach + mach_offset,
        mach_offset=mach_offset,
        **values,
        status="OK" if valid else "FAILED_NUMERICAL",
    )
    return row


def run_point(config: str, source: Path, target_mach: float, alpha: float, mach_offset: float = 0.0) -> dict:
    mach = target_mach + mach_offset
    cid = case_id(config, mach, alpha)
    run_dir = RUNS / cid
    run_dir.mkdir(parents=True, exist_ok=True)
    results = run_dir / "results.csv"
    cached = load_cached(run_dir / "summary.json", results, target_mach, mach_offset)
    if cached:
        return cached

    model = run_dir / "model.vsp3"
    script = run_dir / "run.vspscript"
    log = run_dir / "process.log"
    shutil.copy2(source, model)

    kwargs = dict(
        mach_start=mach,
        mach_end=mach,
        mach_points=1,
        alpha_start=alpha,
        alpha_end=alpha,
        alpha_points=1,
        beta_deg=0.0,
        reference_area=SREF,
        reference_chord=CREF,
        reference_span=BREF,
        center=(0.0, 0.0, 0.0),
        fuselage_user_set=1,
        wing_user_set=2,
        ncpu=4,
        forward_gmres_convergence_factor=1.0,
        wake_num_iter=2,
        num_wake_nodes=24,
        wake_relax=0.8,
        require_all_geometries_assigned=False,
    )
    if config == "full":
        kwargs.update(
            tail_geometry_name="GO",
            tail_incidence_deg=0.0,
            engine_boundary="to_face",
            require_canonical_components=True,
            require_nonempty_fuselage_set=True,
        )
    else:
        kwargs.update(
            tail_geometry_name=None,
            require_canonical_components=False,
            require_nonempty_fuselage_set=False,
        )

    generate_vspaero_sweep_script(script, model, results, **kwargs)
    return_code, elapsed = execute(script, run_dir, log)

    output = log.read_text(encoding="utf-8", errors="replace") if log.is_file() else ""
    report = parse_set_report(output)
    data = read_series(results)
    numerical_valid, values = numerical_quality(data)
    row = {
        "case_id": cid,
        "config": config,
        "target_mach": target_mach,
        "mach": mach,
        "mach_offset": mach_offset,
        "alpha_deg": alpha,
        "status": "OK" if report.get("valid") and numerical_valid else "FAILED_NUMERICAL",
        "return_code": return_code,
        "runtime_s": elapsed,
        **values,
        "updated_at": now().isoformat(),
    }
    (run_dir / "summary.json").write_text(
        json.dumps(row, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return row


def write_status(state: str, completed: int, total: int, current: str = "", message: str = "") -> None:
    elapsed = max(0.001, time.monotonic() - START_MONOTONIC)
    rate = completed / elapsed if completed else 0.0
    eta = (total - completed) / rate if rate and completed < total else 0.0
    STATUS.write_text(
        json.dumps(
            {
                "state": state,
                "completed_cases": completed,
                "total_cases": total,
                "current": current,
                "message": message,
                "started_at": STARTED_AT,
                "updated_at": now().isoformat(),
                "elapsed_seconds": elapsed,
                "eta_seconds": eta,
                "eta_at": (now() + timedelta(seconds=eta)).isoformat() if eta else None,
                "selection_rule": "fixed geometry; centered-alpha numerical refinement; book curve excluded from solver",
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )


def main() -> None:
    RUNS.mkdir(parents=True, exist_ok=True)
    cases = [(config, source, mach, alpha, 0.0) for config, source in CONFIGS.items() for mach in MACHS for alpha in ALPHAS]
    rows: list[dict] = []
    failures = 0
    failed_exact_groups: set[tuple[str, float]] = set()
    write_status("running", 0, len(cases))
    for index, (config, source, target_mach, alpha, mach_offset) in enumerate(cases, start=1):
        cid = case_id(config, target_mach + mach_offset, alpha)
        write_status("running", index - 1, len(cases), cid)
        group = (config, target_mach)
        if group in failed_exact_groups:
            row = {
                "case_id": cid,
                "config": config,
                "target_mach": target_mach,
                "mach": target_mach,
                "mach_offset": 0.0,
                "alpha_deg": alpha,
                "status": "SKIPPED_GROUP_FAILURE",
                "return_code": "",
                "runtime_s": 0.0,
                "Cy": None,
                "CDi": None,
                "CDo": None,
                "log10_L2": None,
                "log10_max": None,
                "updated_at": now().isoformat(),
            }
        else:
            row = run_point(config, source, target_mach, alpha, mach_offset)
        rows.append(row)
        failures += row["status"] != "OK"
        if row["status"] != "OK":
            failed_exact_groups.add(group)
        print(json.dumps(row, ensure_ascii=False), flush=True)
        write_status("running", index, len(cases), cid, f"failures={failures}")

    failed_groups = sorted(
        {
            (row["config"], row["target_mach"])
            for row in rows
            if row["status"] != "OK" and row["mach_offset"] == 0.0
        }
    )
    offset_cases = [
        (config, CONFIGS[config], target_mach, alpha, offset)
        for config, target_mach in failed_groups
        for offset in (-0.002, 0.002)
        for alpha in ALPHAS
    ] if ENABLE_OFFSET_RECOVERY else []
    total = len(cases) + len(offset_cases)
    for extra_index, (config, source, target_mach, alpha, mach_offset) in enumerate(offset_cases, start=1):
        index = len(cases) + extra_index
        cid = case_id(config, target_mach + mach_offset, alpha)
        write_status("running", index - 1, total, cid, f"offset recovery; failures={failures}")
        row = run_point(config, source, target_mach, alpha, mach_offset)
        rows.append(row)
        failures += row["status"] != "OK"
        print(json.dumps(row, ensure_ascii=False), flush=True)
        write_status("running", index, total, cid, f"offset recovery; failures={failures}")

    fields = list(rows[0])
    with SUMMARY.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, delimiter=";")
        writer.writeheader()
        writer.writerows(rows)
    write_status(
        "complete" if failures == 0 else "complete_with_recovered_failures",
        total,
        total,
        message=f"exact_failures={len(failed_groups)} groups; total_failed_cases={failures}",
    )


START_MONOTONIC = time.monotonic()
STARTED_AT = now().isoformat()


if __name__ == "__main__":
    main()
