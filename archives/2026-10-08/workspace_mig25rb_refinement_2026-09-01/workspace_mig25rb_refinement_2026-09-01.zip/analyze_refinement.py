from __future__ import annotations

import csv
import json
import math
from collections import defaultdict
from pathlib import Path


HERE = Path(__file__).resolve().parent
INPUT = HERE / "run_summary.csv"
OUTPUT = HERE / "refinement_summary.csv"
METRICS = HERE / "refinement_metrics.json"

SREF = 660.904
BREF = 43.898
AR_EFFECTIVE = BREF * BREF / SREF
SWEEP_LE_DEG = 43.0
NORMAL_MACH_TRANSITION_WIDTH = 0.45
TARGET_MACHS = (1.35, 1.40, 1.50, 1.60, 1.70, 1.90, 2.20)

# Stable M=1.2 anchors from the immediately preceding fixed-geometry repeat.
# They are used only to bridge the VSPAERO blind band; no book value enters
# this interpolation.
PRIOR_SLOPES = {
    "full": {1.2: 0.035732093697},
    "thin_all": {1.2: 0.035874363308},
}

# Independent validation values digitized from the book.  They are used only
# after the numerical and semiempirical calculations have been completed.
REFERENCE = {1.4: 0.0540, 1.7: 0.0420, 2.2: 0.0345}
PREVIOUS_VALIDATION = [
    {"mach": 0.5, "calculated": 0.0619719573818356, "reference": 0.0640},
    {"mach": 0.8, "calculated": 0.07386176254745333, "reference": 0.0690},
    {"mach": 1.2, "calculated": 0.06671971767932867, "reference": 0.0640},
]


def read_rows() -> list[dict]:
    rows: list[dict] = []
    with INPUT.open("r", encoding="utf-8-sig", newline="") as stream:
        for raw in csv.DictReader(stream, delimiter=";"):
            if raw["status"] != "OK":
                continue
            rows.append(
                {
                    "config": raw["config"],
                    "target_mach": float(raw.get("target_mach") or raw["mach"]),
                    "mach": float(raw["mach"]),
                    "mach_offset": float(raw.get("mach_offset") or 0.0),
                    "alpha": float(raw["alpha_deg"]),
                    "Cy": float(raw["Cy"]),
                }
            )
    return rows


def linear_slope(points: list[tuple[float, float]]) -> tuple[float, float]:
    xbar = sum(x for x, _ in points) / len(points)
    ybar = sum(y for _, y in points) / len(points)
    sxx = sum((x - xbar) ** 2 for x, _ in points)
    slope = sum((x - xbar) * (y - ybar) for x, y in points) / sxx
    intercept = ybar - slope * xbar
    residuals = [y - (intercept + slope * x) for x, y in points]
    rms = math.sqrt(sum(value * value for value in residuals) / len(residuals))
    return slope, rms


def helmbold_unswept(mach: float) -> float:
    beta = math.sqrt(abs(1.0 - mach * mach))
    per_radian = 2.0 * math.pi * AR_EFFECTIVE / (
        2.0 + math.sqrt(4.0 + AR_EFFECTIVE * AR_EFFECTIVE * beta * beta)
    )
    return per_radian * math.pi / 180.0


def helmbold_swept(mach: float) -> float:
    beta = math.sqrt(abs(1.0 - mach * mach))
    sweep = math.radians(SWEEP_LE_DEG)
    per_radian = 2.0 * math.pi * AR_EFFECTIVE / (
        2.0
        + math.sqrt(
            4.0
            + AR_EFFECTIVE
            * AR_EFFECTIVE
            * (beta * beta + math.tan(sweep) ** 2)
        )
    )
    return per_radian * math.pi / 180.0


def smoothstep(value: float) -> float:
    value = max(0.0, min(1.0, value))
    return value * value * (3.0 - 2.0 * value)


def sweep_weight(mach: float, width: float = NORMAL_MACH_TRANSITION_WIDTH) -> float:
    normal_mach = mach * math.cos(math.radians(SWEEP_LE_DEG))
    return smoothstep((normal_mach - 1.0) / width)


def main() -> None:
    grouped: dict[tuple[str, float, float], list[tuple[float, float]]] = defaultdict(list)
    for row in read_rows():
        grouped[(row["config"], row["target_mach"], row["mach_offset"])].append((row["alpha"], row["Cy"]))

    slopes: dict[tuple[str, float, float], dict] = {}
    for key, points in grouped.items():
        if len(points) != 4:
            continue
        points.sort()
        regression, rms = linear_slope(points)
        values = dict(points)
        centered = (values[0.5] - values[-0.5]) / 1.0
        forward = values[1.0] - values[0.0]
        spread = 100.0 * (max(centered, forward, regression) - min(centered, forward, regression)) / max(abs(regression), 1e-12)
        slopes[key] = {
            "regression": regression,
            "centered": centered,
            "forward": forward,
            "fit_rms": rms,
            "slope_spread_pct": spread,
        }

    def interpolate_anchor(config: str, mach: float) -> dict:
        anchors: dict[float, dict] = {
            key[1]: value
            for key, value in slopes.items()
            if key[0] == config and key[2] == 0.0
        }
        for anchor_mach, anchor_slope in PRIOR_SLOPES[config].items():
            anchors[anchor_mach] = {
                "regression": anchor_slope,
                "centered": anchor_slope,
                "forward": anchor_slope,
                "fit_rms": 0.0,
                "slope_spread_pct": 0.0,
            }
        lower = max(value for value in anchors if value < mach)
        upper = min(value for value in anchors if value > mach)
        fraction = (mach - lower) / (upper - lower)
        result = {}
        for key in ("regression", "centered", "forward", "fit_rms", "slope_spread_pct"):
            result[key] = anchors[lower][key] + fraction * (anchors[upper][key] - anchors[lower][key])
        result["source"] = "stable_anchor_interpolation"
        result["offset_spread_pct"] = 0.0
        result["interpolation_span"] = f"{lower:.2f}-{upper:.2f}"
        return result

    def recovered(config: str, mach: float) -> dict:
        exact = slopes.get((config, mach, 0.0))
        if exact:
            return {**exact, "source": "exact", "offset_spread_pct": 0.0, "interpolation_span": ""}
        minus = slopes.get((config, mach, -0.002))
        plus = slopes.get((config, mach, 0.002))
        if not minus or not plus:
            return interpolate_anchor(config, mach)
        result = {}
        for key in ("regression", "centered", "forward", "fit_rms", "slope_spread_pct"):
            result[key] = 0.5 * (minus[key] + plus[key])
        result["source"] = "symmetric_offset"
        result["offset_spread_pct"] = 100.0 * abs(plus["regression"] - minus["regression"]) / max(abs(result["regression"]), 1e-12)
        result["interpolation_span"] = ""
        return result

    output_rows: list[dict] = []
    for mach in TARGET_MACHS:
        full = recovered("full", mach)
        thin = recovered("thin_all", mach)
        residual = full["regression"] - thin["regression"]
        unswept = helmbold_unswept(mach)
        swept = helmbold_swept(mach)
        weight = sweep_weight(mach)
        semi = unswept * (1.0 - weight) + swept * weight
        hybrid = semi + residual
        reference = REFERENCE.get(mach)
        error = 100.0 * (hybrid - reference) / reference if reference else None
        output_rows.append(
            {
                "mach": mach,
                "normal_mach": mach * math.cos(math.radians(SWEEP_LE_DEG)),
                "full_Cya_regression": full["regression"],
                "full_Cya_centered": full["centered"],
                "full_Cya_forward": full["forward"],
                "full_slope_spread_pct": full["slope_spread_pct"],
                "full_source": full["source"],
                "full_offset_spread_pct": full["offset_spread_pct"],
                "full_interpolation_span": full["interpolation_span"],
                "thin_Cya_regression": thin["regression"],
                "thin_slope_spread_pct": thin["slope_spread_pct"],
                "thin_source": thin["source"],
                "thin_offset_spread_pct": thin["offset_spread_pct"],
                "thin_interpolation_span": thin["interpolation_span"],
                "thick_body_residual": residual,
                "sweep_weight": weight,
                "semiempirical_unswept": unswept,
                "semiempirical_swept": swept,
                "semiempirical_blended": semi,
                "Cya_hybrid_refined": hybrid,
                "book_Cya": reference,
                "error_pct": error,
                "abs_error_pct": abs(error) if error is not None else None,
            }
        )

    with OUTPUT.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(output_rows[0]), delimiter=";")
        writer.writeheader()
        writer.writerows(output_rows)

    validation = [row for row in output_rows if row["book_Cya"] is not None]
    combined_validation = list(PREVIOUS_VALIDATION)
    combined_validation.extend(
        {
            "mach": row["mach"],
            "calculated": row["Cya_hybrid_refined"],
            "reference": row["book_Cya"],
        }
        for row in validation
    )
    for row in combined_validation:
        row["error_pct"] = 100.0 * (row["calculated"] - row["reference"]) / row["reference"]
        row["abs_error_pct"] = abs(row["error_pct"])
    with (HERE / "combined_validation_summary.csv").open(
        "w", encoding="utf-8-sig", newline=""
    ) as stream:
        writer = csv.DictWriter(stream, fieldnames=list(combined_validation[0]), delimiter=";")
        writer.writeheader()
        writer.writerows(combined_validation)

    combined_mean_abs = sum(row["abs_error_pct"] for row in combined_validation) / len(combined_validation)
    combined_max_abs = max(row["abs_error_pct"] for row in combined_validation)
    combined_bias = sum(row["error_pct"] for row in combined_validation) / len(combined_validation)
    metrics = {
        "method": "RM92-CYA-WINGBODY-2-refinement-candidate",
        "geometry_fixed": True,
        "wing_configuration": "Wing without underfuselage part",
        "effective_aspect_ratio": AR_EFFECTIVE,
        "leading_edge_sweep_deg": SWEEP_LE_DEG,
        "normal_mach_transition": [1.0, 1.0 + NORMAL_MACH_TRANSITION_WIDTH],
        "blind_band_treatment": "interpolate only the VSPAERO full-minus-thin residual between stable anchors",
        "max_alpha_slope_spread_pct": max(
            max(row["full_slope_spread_pct"], row["thin_slope_spread_pct"])
            for row in output_rows
        ),
        "max_offset_spread_pct": max(
            max(row["full_offset_spread_pct"], row["thin_offset_spread_pct"])
            for row in output_rows
        ),
        "mean_abs_error_pct": sum(row["abs_error_pct"] for row in validation) / len(validation),
        "max_abs_error_pct": max(row["abs_error_pct"] for row in validation),
        "points_within_11_pct": sum(row["abs_error_pct"] <= 11.0 for row in validation),
        "validation_points": len(validation),
        "full_range_mean_abs_error_pct": combined_mean_abs,
        "full_range_max_abs_error_pct": combined_max_abs,
        "full_range_signed_bias_pct": combined_bias,
        "full_range_points_within_11_pct": sum(
            row["abs_error_pct"] <= 11.0 for row in combined_validation
        ),
        "full_range_validation_points": len(combined_validation),
        "full_range_balanced_acceptance": (
            combined_mean_abs <= 11.0
            and combined_max_abs <= 20.0
            and abs(combined_bias) <= 5.0
        ),
        "combined_validation": combined_validation,
        "rows": output_rows,
    }
    METRICS.write_text(
        json.dumps(metrics, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(metrics, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
