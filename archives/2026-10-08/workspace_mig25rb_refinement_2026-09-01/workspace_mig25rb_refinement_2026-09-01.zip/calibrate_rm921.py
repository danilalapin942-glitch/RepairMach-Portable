from __future__ import annotations

import csv
import json
import math
from pathlib import Path


HERE = Path(__file__).resolve().parent
AR = 2.915755395639912
SWEEP_DEG = 43.0
ROBUST = {
    "normal_mach_transition_width": 0.35,
    "supersonic_efficiency": 0.93,
    "residual_limit_ratio": 0.05,
}


def load_data() -> list[dict]:
    low = [
        {"mach": 0.5, "book": 0.0640, "unswept": 0.0612402278188356, "swept": 0.052427657402277, "residual": 0.000731729563},
        {"mach": 0.8, "book": 0.0690, "unswept": 0.06865712795945333, "swept": 0.056371307488831846, "residual": 0.005204634588},
        {"mach": 1.2, "book": 0.0640, "unswept": 0.06686198729032868, "swept": 0.055476719276084885, "residual": -0.000142269611},
    ]
    high = []
    with (HERE / "refinement_summary.csv").open("r", encoding="utf-8-sig", newline="") as stream:
        for raw in csv.DictReader(stream, delimiter=";"):
            if not raw["book_Cya"]:
                continue
            high.append(
                {
                    "mach": float(raw["mach"]),
                    "book": float(raw["book_Cya"]),
                    "unswept": float(raw["semiempirical_unswept"]),
                    "swept": float(raw["semiempirical_swept"]),
                    "residual": float(raw["thick_body_residual"]),
                }
            )
    return sorted(low + high, key=lambda row: row["mach"])


def predict(row: dict, width: float, efficiency: float, residual_limit: float) -> dict:
    normal_mach = row["mach"] * math.cos(math.radians(SWEEP_DEG))
    coordinate = max(0.0, min(1.0, (normal_mach - 1.0) / width))
    weight = coordinate * coordinate * (3.0 - 2.0 * coordinate)
    principal = row["unswept"] * (1.0 - weight) + row["swept"] * weight
    selected_efficiency = efficiency if row["mach"] >= 1.2 else 1.0
    cap = residual_limit * abs(principal)
    limited_residual = max(-cap, min(cap, row["residual"]))
    calculated = selected_efficiency * principal + limited_residual
    error = 100.0 * (calculated - row["book"]) / row["book"]
    return {
        **row,
        "normal_mach": normal_mach,
        "sweep_weight": weight,
        "principal": principal,
        "selected_efficiency": selected_efficiency,
        "limited_residual": limited_residual,
        "calculated": calculated,
        "error_pct": error,
        "abs_error_pct": abs(error),
    }


def score(data: list[dict], params: tuple[float, float, float], indices: list[int]) -> tuple[float, float, float]:
    rows = [predict(data[index], *params) for index in indices]
    errors = [row["error_pct"] for row in rows]
    return (
        max(abs(value) for value in errors),
        sum(abs(value) for value in errors) / len(errors),
        abs(sum(errors) / len(errors)),
    )


def grid() -> list[tuple[float, float, float]]:
    return [
        (width / 100.0, efficiency / 1000.0, limit / 1000.0)
        for width in range(15, 46)
        for efficiency in range(920, 1001, 2)
        for limit in range(5, 51)
    ]


def main() -> None:
    data = load_data()
    candidates = grid()
    all_indices = list(range(len(data)))
    mathematical_best = min(candidates, key=lambda item: score(data, item, all_indices))

    loo = []
    for holdout in all_indices:
        training = [index for index in all_indices if index != holdout]
        selected = min(candidates, key=lambda item: score(data, item, training))
        predicted = predict(data[holdout], *selected)
        loo.append(
            {
                "holdout_mach": data[holdout]["mach"],
                "selected_width": selected[0],
                "selected_efficiency": selected[1],
                "selected_residual_limit": selected[2],
                "training_score": score(data, selected, training),
                "holdout_error_pct": predicted["error_pct"],
            }
        )

    robust_tuple = (
        ROBUST["normal_mach_transition_width"],
        ROBUST["supersonic_efficiency"],
        ROBUST["residual_limit_ratio"],
    )
    rows = [predict(row, *robust_tuple) for row in data]
    with (HERE / "rm921_validation.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), delimiter=";")
        writer.writeheader()
        writer.writerows(rows)

    errors = [row["error_pct"] for row in rows]
    neighborhood = [
        (width, efficiency, limit)
        for width in (0.30, 0.35, 0.40)
        for efficiency in (0.92, 0.93, 0.94)
        for limit in (0.04, 0.05)
    ]
    neighborhood_pass = sum(score(data, item, all_indices)[0] <= 5.0 for item in neighborhood)
    output = {
        "method": "RM92.1-CYA-WINGBODY-3-working",
        "working_project": "MiG-25RB",
        "reference_used_for_development_calibration": True,
        "mathematical_best": {
            "parameters": mathematical_best,
            "score_max_mean_bias_abs_pct": score(data, mathematical_best, all_indices),
        },
        "selected_rounded_engineering_parameters": ROBUST,
        "selection_reason": "rounded values; residual cap equals the 5% numerical budget; robust neighborhood retained",
        "mean_abs_error_pct": sum(abs(value) for value in errors) / len(errors),
        "max_abs_error_pct": max(abs(value) for value in errors),
        "signed_bias_pct": sum(errors) / len(errors),
        "points_within_5_pct": sum(abs(value) <= 5.0 for value in errors),
        "point_count": len(rows),
        "leave_one_out": loo,
        "leave_one_out_max_abs_error_pct": max(abs(row["holdout_error_pct"]) for row in loo),
        "neighborhood_candidates": len(neighborhood),
        "neighborhood_candidates_within_5_pct": neighborhood_pass,
        "rows": rows,
    }
    (HERE / "rm921_calibration.json").write_text(
        json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
