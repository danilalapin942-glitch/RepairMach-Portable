$ErrorActionPreference = 'Stop'
$Python = 'C:\Users\admin\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
& $Python (Join-Path $Here 'run_refinement.py') *>> (Join-Path $Here 'run_refinement.log')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $Python (Join-Path $Here 'analyze_refinement.py') *>> (Join-Path $Here 'analyze_refinement.log')
exit $LASTEXITCODE
