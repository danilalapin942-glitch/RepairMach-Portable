from pathlib import Path
import csv
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path(r"C:\Users\admin\Documents\Codex\2026-09-15\yfq-44-report-only")
SRC = Path(r"C:\Users\admin\Documents\Codex\2026-09-13\yfq-44-openvsp\outputs\YFQ_44_unified_pipeline")
OUT = ROOT / "outputs"
OUT.mkdir(parents=True, exist_ok=True)
DOCX = OUT / "YFQ_44_engineering_verification_report_ru.docx"

NAVY = "17365D"
PALE = "EEF3F8"
GRID = "D9D9D9"
WHITE = "FFFFFF"
BLACK = RGBColor(0, 0, 0)

def set_cell_fill(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = tcPr.find(qn('w:shd'))
    if shd is None:
        shd = OxmlElement('w:shd')
        tcPr.append(shd)
    shd.set(qn('w:fill'), fill)

def set_cell_margins(cell, top=100, start=110, bottom=100, end=110):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcMar = tcPr.first_child_found_in('w:tcMar')
    if tcMar is None:
        tcMar = OxmlElement('w:tcMar')
        tcPr.append(tcMar)
    for m, v in [('top', top), ('start', start), ('bottom', bottom), ('end', end)]:
        node = tcMar.find(qn(f'w:{m}'))
        if node is None:
            node = OxmlElement(f'w:{m}')
            tcMar.append(node)
        node.set(qn('w:w'), str(v))
        node.set(qn('w:type'), 'dxa')

def set_table_borders(table):
    tblPr = table._tbl.tblPr
    borders = tblPr.find(qn('w:tblBorders'))
    if borders is None:
        borders = OxmlElement('w:tblBorders')
        tblPr.append(borders)
    for edge in ('top','left','bottom','right','insideH','insideV'):
        el = borders.find(qn(f'w:{edge}'))
        if el is None:
            el = OxmlElement(f'w:{edge}')
            borders.append(el)
        el.set(qn('w:val'), 'single')
        el.set(qn('w:sz'), '4')
        el.set(qn('w:color'), GRID)

def repeat_header(row):
    trPr = row._tr.get_or_add_trPr()
    tblHeader = OxmlElement('w:tblHeader')
    tblHeader.set(qn('w:val'), 'true')
    trPr.append(tblHeader)

def set_col_widths(table, widths_cm):
    for row in table.rows:
        for i, width in enumerate(widths_cm):
            row.cells[i].width = Cm(width)

def style_run(run, bold=False, size=None, color=BLACK, italic=False):
    run.bold = bold
    run.italic = italic
    run.font.name = 'Arial'
    run._element.get_or_add_rPr().rFonts.set(qn('w:ascii'), 'Arial')
    run._element.get_or_add_rPr().rFonts.set(qn('w:hAnsi'), 'Arial')
    run._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'), 'Arial')
    if size:
        run.font.size = Pt(size)
    run.font.color.rgb = color

def add_text(text='', style=None, bold_lead=None, italic=False, align=None, keep=False):
    p = doc.add_paragraph(style=style)
    if bold_lead and text.startswith(bold_lead):
        r1 = p.add_run(bold_lead)
        style_run(r1, bold=True)
        r2 = p.add_run(text[len(bold_lead):])
        style_run(r2, italic=italic)
    else:
        r = p.add_run(text)
        style_run(r, italic=italic)
    if align is not None:
        p.alignment = align
    p.paragraph_format.keep_together = keep
    return p

def add_bullet(text, level=0):
    p = doc.add_paragraph(style='List Bullet' if level == 0 else 'List Bullet 2')
    style_run(p.add_run(text))
    return p

def add_number(text):
    p = doc.add_paragraph(style='List Number')
    style_run(p.add_run(text))
    return p

def add_table(headers, rows, widths, font_size=8.5, aligns=None):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    set_table_borders(table)
    hdr = table.rows[0]
    repeat_header(hdr)
    for i, h in enumerate(headers):
        cell = hdr.cells[i]
        set_cell_fill(cell, NAVY)
        set_cell_margins(cell)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        style_run(p.add_run(str(h)), bold=True, size=font_size, color=RGBColor(255,255,255))
    for ridx, row in enumerate(rows):
        cells = table.add_row().cells
        for i, val in enumerate(row):
            cell = cells[i]
            set_cell_margins(cell)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            if ridx % 2:
                set_cell_fill(cell, PALE)
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            p.alignment = (aligns[i] if aligns else WD_ALIGN_PARAGRAPH.LEFT)
            style_run(p.add_run(str(val)), size=font_size)
    set_col_widths(table, widths)
    doc.add_paragraph().paragraph_format.space_after = Pt(1)
    return table

def caption(text):
    p = doc.add_paragraph(style='Caption')
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.keep_with_next = True
    style_run(p.add_run(text), italic=True, size=8.5)
    return p

def add_figure(filename, title, explanation):
    caption(title)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.keep_together = True
    p.add_run().add_picture(str(SRC / 'plots' / filename), width=Cm(16.3))
    e = doc.add_paragraph()
    e.paragraph_format.space_after = Pt(7)
    style_run(e.add_run(explanation), size=8.8, italic=True)

def page_field(paragraph):
    run = paragraph.add_run()
    fldChar1 = OxmlElement('w:fldChar'); fldChar1.set(qn('w:fldCharType'), 'begin')
    instrText = OxmlElement('w:instrText'); instrText.set(qn('xml:space'), 'preserve'); instrText.text = 'PAGE'
    fldChar2 = OxmlElement('w:fldChar'); fldChar2.set(qn('w:fldCharType'), 'end')
    run._r.extend([fldChar1, instrText, fldChar2])
    style_run(run, size=8)

doc = Document()
sec = doc.sections[0]
sec.page_width = Cm(21.0); sec.page_height = Cm(29.7)
sec.top_margin = Cm(1.8); sec.bottom_margin = Cm(1.7); sec.left_margin = Cm(2.2); sec.right_margin = Cm(1.8)

styles = doc.styles
normal = styles['Normal']
normal.font.name = 'Arial'; normal._element.rPr.rFonts.set(qn('w:eastAsia'), 'Arial'); normal.font.size = Pt(9.5); normal.font.color.rgb = BLACK
normal.paragraph_format.space_after = Pt(5); normal.paragraph_format.line_spacing = 1.08
for name, size, before, after in [('Title',25,0,16),('Heading 1',15,13,6),('Heading 2',11.5,9,4),('Heading 3',10,7,3)]:
    s=styles[name]; s.font.name='Arial'; s._element.rPr.rFonts.set(qn('w:eastAsia'),'Arial'); s.font.size=Pt(size); s.font.color.rgb=BLACK; s.font.bold=True
    s.paragraph_format.space_before=Pt(before); s.paragraph_format.space_after=Pt(after); s.paragraph_format.keep_with_next=True
# Remove the decorative border that some Word installations attach to the built-in Title style.
title_ppr = styles['Title']._element.get_or_add_pPr()
title_borders = title_ppr.find(qn('w:pBdr'))
if title_borders is not None:
    title_ppr.remove(title_borders)
styles['Caption'].font.name='Arial'; styles['Caption']._element.rPr.rFonts.set(qn('w:eastAsia'),'Arial'); styles['Caption'].font.color.rgb=BLACK

header = sec.header.paragraphs[0]
header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
style_run(header.add_run('YFQ-44  Инженерная верификация'), size=8, color=RGBColor(90,90,90))
footer = sec.footer.paragraphs[0]
footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
style_run(footer.add_run('Условная инженерная приёмка  |  '), size=8, color=RGBColor(90,90,90))
page_field(footer)

# Title page
p=doc.add_paragraph(style='Title'); p.alignment=WD_ALIGN_PARAGRAPH.LEFT
p_borders = p._p.get_or_add_pPr().find(qn('w:pBdr'))
if p_borders is not None:
    p._p.get_or_add_pPr().remove(p_borders)
style_run(p.add_run('Инженерный отчёт по автоматизированной верификации и расчёту модели БПЛА YFQ 44'), bold=True, size=25)
add_text('Сводный отчёт по геометрической проверке, расчётной постановке MachLine и гибридной оценке аэродинамических коэффициентов', italic=True)
doc.add_paragraph()
add_table(['Параметр','Значение'],[
    ['Итог','CONDITIONAL_ENGINEERING_ACCEPTANCE'],
    ['Решение автоматики','ACCEPTED_WITH_DECLARED_LIMITATIONS'],
    ['Характер результата','Условная инженерная приёмка, не официальная сертификация типа'],
    ['Дата завершения конвейера','15 сентября 2026 года'],
    ['Набор расчётных чисел Маха','0,8; 1,2; 2,0'],
    ['Углы атаки','-1°; 0°; 1°; 4°'],
],[5.2,11.1],9.2,[WD_ALIGN_PARAGRAPH.LEFT,WD_ALIGN_PARAGRAPH.LEFT])
add_text('Главный вывод', style='Heading 1')
add_text('Автоматические геометрические и обязательные численные барьеры пройдены. Получены 12 полных гибридных расчётных кандидатов. Результат принят условно и только в границах заявленной постановки: подъёмная сила использует геометрически скорректированный наклон, а сопротивление является предварительной нижней оценкой с неидентифицированными членами.')
add_text('Ключевое ограничение', style='Heading 2')
add_text('Отчёт не подтверждает типовой сертификат, реальные профили 64A006, статический запас или характеристики сваливания. Для этих выводов отсутствуют соответственно сертификационная процедура, подтверждение профилей, положение центра тяжести и валидированная вязкая нестационарная модель либо эксперимент.')
doc.add_page_break()

add_text('1 Назначение и границы отчёта', style='Heading 1')
add_text('Отчёт фиксирует результаты уже выполненного автоматизированного контура проверки модели YFQ-44. Он объединяет контроль неизменности исходника, геометрическую приёмку, диагностику сеток, расчёт MachLine на ветви lifting_wedge, сеточную сходимость, контроль двух линейных решателей и сборку гибридных коэффициентов Cy и Cx.')
add_text('В документе разделены три уровня утверждений: подтверждённые результаты автоматических барьеров, инженерные оценки внутри объявленной модели и гипотезы, для которых требуются новые исходные данные. Термин «приёмка» далее означает только условную инженерную приёмку расчёта.')

add_text('2 Исходные данные и контроль неизменности', style='Heading 1')
add_text('Контур работал с неизменяемой исходной моделью YFQ_44 MachLine.vsp3 и отдельной рабочей копией. Совпадение SHA-256 подтверждено кодом Y44-000. Исходная VSP3-модель и исходный код MachLine не изменялись.')
add_table(['Объект','Подтверждённое значение'],[
    ['SHA-256 исходной модели','6A2804A0E9789A2707BA29D52A4EEF293E6ACC27B51388862777D5B35DB6CD7B'],
    ['Версия OpenVSP','3.51.1'],
    ['Состав модели','Fuselage, Gondola, Wing, GO, VO'],
    ['Габаритная длина','20,1228 ft; отклонение от контрольной 0,0557 %'],
    ['Размах','12,3700 ft; отклонение 0,0096 %'],
    ['Суммарная площадь несущих компонентов','46,1877 ft²; отклонение от реконструкционной Sref -1,3569 %'],
],[5.6,10.7],8.5,[WD_ALIGN_PARAGRAPH.LEFT,WD_ALIGN_PARAGRAPH.LEFT])
add_text('Геометрический барьер получил PASS. Значение Sref в источнике трактуется как контроль реконструкции, а 46,1877 ft² представляет сумму площадей, сохранённых в модели для несущих компонентов.')

add_text('3 Автоматическая приёмка', style='Heading 1')
add_text('Контур реализован по принципу fail-closed: обязательный непройденный барьер должен приводить к Y44-910 и запрещать выдачу допуска. В выполненном прогоне обязательных блокирующих записей не возникло, поэтому журнал завершён Y44-900.')
for item in [
    'Сверка хеша исходника и рабочей копии.',
    'Проверка состава, габаритов и контрольной площади.',
    'Аудит топологии и пригодности панелей, включая проверку superinclined.',
    'Проверка завершения MachLine, конечности коэффициентов и двух невязок не выше 1e-5.',
    'Проверка обязательных последних сеточных переходов по Cx и Cy.',
    'Сопоставление FQRUP и LU на контрольных сверхзвуковых точках при alpha=4°.',
    'Сборка гибридных кандидатов и присвоение статуса PROVISIONAL_LOWER_BOUND.'
]: add_number(item)

add_text('4 Найденные и устранённые неполадки', style='Heading 1')
add_text('4.1 Среда запуска MachLine', style='Heading 2')
add_text('При автоматическом запуске к PATH добавлена проверенная среда C:\\msys64\\ucrt64\\bin. Это обеспечило доступность libgcc_s_seh-1.dll и связанных библиотек без копирования DLL в каталоги модели или решателя.')
add_text('4.2 Непригодность обычной CFD сетки', style='Heading 2')
add_text('Скруглённые кромки обычной CFD-сетки при уточнении порождали панели, которые MachLine классифицировал как запрещённые superinclined. На low-сетке полного открытого корпуса сверхзвуковые точки имели от 6 до 58 таких панелей и отклонялись до запуска решателя. Medium-сетка полного корпуса дополнительно получила FAIL из-за 9 неманифолдных рёбер.')
add_text('4.3 Расчётная замена double wedge', style='Heading 2')
add_text('Для несущих поверхностей автоматически построена отдельная расчётная семья вокруг срединных поверхностей OpenVSP DegenGeom. Секции замкнуты острыми double-wedge контурами с сохранением максимальной толщины каждой исходной секции. Эта операция не исправляет исходную VSP3-модель и не отменяет геометрический запрет: она создаёт явно объявленную расчётную ветвь lifting_wedge.')
add_text('4.4 Кормовая крышка', style='Heading 2')
add_text('На low- и medium-уровнях найден единственный связный плоский кормовой участок. Удалены соответственно 17 и 24 грани. Операция протоколирована в aft_cap_report.json. Открытое дно не считается замкнутой моделью; его вклад вводится отдельным донным членом сопротивления.')

add_text('5 Метод MachLine double wedge', style='Heading 1')
add_text('MachLine применён как панельный метод для расчётной геометрии lifting_wedge. Основная серия использует линейный решатель FQRUP и правило давления isentropic. Для контрольных точек дополнительно рассчитаны LU и, где применимо, slender-body pressure crosscheck. Принятый сверхзвуковой pressure-вклад в Cx берётся только из численно принятой ветви lifting_wedge.')
add_text('Полная поверхность сохранилась как диагностическая ветвь. После подтверждения непригодности её семейства дальнейшие уровни не строились, а все принятые MachLine-точки использовали одну постановку lifting_wedge. Исключённые толстые тела учитываются через отдельные эмпирические слагаемые и список неопределённостей, но их сверхзвуковое волновое сопротивление не восстановлено.')

add_text('6 Гибридная модель Cy и Cx', style='Heading 1')
add_text('6.1 Подъёмная сила Cy', style='Heading 2')
add_text('Нулевой уровень Cy берётся из VSPAERO. Прямой наклон VSPAERO заменён заранее объявленной геометрической оценкой конечного стреловидного крыла. Поэтому гибридный Cy равен нулевому уровню плюс геометрический наклон, умноженный на угол атаки. Подгонка к желаемому значению Cy или к продувочным данным не выполнялась.')
add_text('6.2 Сопротивление Cx', style='Heading 2')
add_text('При M=0,8 pressure/induced-вклад берётся как VSPAERO CDi. При M=1,2 и 2,0 используется принятый MachLine pressure-вклад double-wedge ветви. Во всех режимах к нему раздельно добавляются профильный член крыла и оперения, трение исключённых тел и предварительный донный член.')
add_text('Известная RSS-неопределённость относится к включённым членам. Она не покрывает волновое сопротивление исключённых толстых тел, щели, антенны, выступающие детали, силовую установку и реальный донный режим. Поэтому Cx имеет статус предварительной нижней инженерной оценки.')

p7 = add_text('7 Результаты при alpha 4 градуса', style='Heading 1')
p7.paragraph_format.page_break_before = True
add_table(['M','Cy VSPAERO','Cy гибрид','Источник pressure или induced','Cx гибрид','RSS неопределённость'],[
    ['0,80','0,13913','0,29866','VSPAERO CDi','0,01839','0,00304'],
    ['1,20','0,18244','0,28784','MachLine lifting wedge','0,05013','0,00298'],
    ['2,00','0,11597','0,17469','MachLine lifting wedge','0,03104','0,00289'],
],[1.1,2.2,2.1,4.6,2.0,2.3],8.3,[WD_ALIGN_PARAGRAPH.CENTER]*6)
add_text('Все три строки имеют статус PROVISIONAL_LOWER_BOUND. Пик Cx в рассматриваемых точках приходится на M=1,2. Это наблюдение относится только к трём рассчитанным числам Маха; линии на графиках не образуют интерполяционную модель.')

add_figure('Cya_vs_M.png','Рисунок 1 Производная подъёмной силы по углу атаки','Геометрический гибридный наклон выше прямого наклона VSPAERO на всех трёх режимах. Это следствие выбранной корректирующей модели, а не независимое экспериментальное подтверждение.')
add_figure('Cy_vs_M.png','Рисунок 2 Гибридный коэффициент подъёмной силы','Показаны четыре угла атаки. Полые маркеры обозначают предварительные инженерные оценки. Значения при alpha=0° близки к нулевому уровню VSPAERO.')
doc.add_page_break()
add_figure('Cx_vs_M.png','Рисунок 3 Гибридный коэффициент сопротивления','На M=1,2 и 2,0 pressure-вклад основан на MachLine lifting_wedge; на M=0,8 используется VSPAERO CDi. Сравнение между режимами нужно читать с учётом различия источников.')
add_figure('polar_Cx_vs_Cy.png','Рисунок 4 Гибридная аэродинамическая поляра','Поляра соединяет четыре рассчитанных угла атаки для каждого из трёх чисел Маха. Она не является моделью сваливания и не должна экстраполироваться за рассчитанный диапазон.')
doc.add_page_break()
add_figure('Cx_components_alpha4_vs_M.png','Рисунок 5 Разложение Cx при alpha 4 градуса','Столбцы показывают pressure или induced-вклад, профильный член, трение тел и донный член. Невключённые физические эффекты перечислены отдельно и не входят в высоту столбцов.')

add_text('8 Сеточная сходимость', style='Heading 1')
add_text('Файл mesh_convergence.csv содержит 39 переходов. Из них 17 получили PASS и 22 сохранены как INFO с FAIL. Для итоговой приёмки обязательны 12 последних целевых переходов; все 12 пройдены. Ранние грубые и дозвуковые диагностические переходы не являются блокирующими после успешного завершения объявленной программы уточнения.')
add_table(['Режим уточнения','Обязательные точки','Итог','Максимальная доля допуска Cx','Максимальная доля допуска Cy'],[
    ['M=1,2 по размаху 33x33 -> 65x33','4','4 из 4 PASS','0,189','0,576'],
    ['M=1,2 по хорде 33x33 -> 33x65','4','4 из 4 PASS','0,225','0,972'],
    ['M=2,0 17x17 -> 33x33','4','4 из 4 PASS','0,037','0,641'],
],[4.7,2.1,2.5,3.2,3.2],8.1,[WD_ALIGN_PARAGRAPH.LEFT,WD_ALIGN_PARAGRAPH.CENTER,WD_ALIGN_PARAGRAPH.CENTER,WD_ALIGN_PARAGRAPH.CENTER,WD_ALIGN_PARAGRAPH.CENTER])
add_text('Наиболее близким к пределу оказался направленный переход по хорде при M=1,2 по Cy: 0,972 установленного допуска. Формально барьер пройден, но малый запас до порога следует учитывать при последующем изменении геометрии или критериев.')

p9 = add_text('9 Контроль FQRUP и LU', style='Heading 1')
p9.paragraph_format.page_break_before = True
add_text('На fine-сетке при alpha=4° сверхзвуковые решения FQRUP и LU практически совпали. Абсолютные различия на несколько порядков ниже заданных пределов.')
add_table(['M','Статус','Delta CD','Предел CD','Delta CN','Предел CN'],[
    ['0,8','MISSING, INFO','—','—','—','—'],
    ['1,2','PASS','5,15e-8','0,002','6,27e-7','0,007026'],
    ['2,0','PASS','1,73e-8','0,002','2,24e-7','0,005174'],
],[1.2,3.0,2.6,2.5,2.6,2.5],8.5,[WD_ALIGN_PARAGRAPH.CENTER]*6)
add_text('Отсутствие дозвукового контроля при M=0,8 зафиксировано кодом Y44-322 как INFO. Оно не блокирует гибрид, поскольку дозвуковой Cx использует VSPAERO CDi, а не MachLine.')

add_text('10 Расшифровка кодов журнала', style='Heading 1')
code_rows = [
('Y44-000','PASS','Хеш исходника и рабочей копии совпадает; исходник не изменён.'),
('Y44-100','PASS','Состав модели и контрольные габариты прошли проверку.'),
('Y44-110','PASS','Единственная кормовая крышка найдена и снята автоматически; операция протоколирована.'),
('Y44-120','PASS','Расчётная DegenGeom double-wedge сетка построена и прошла аудит топологии.'),
('Y44-200','PASS','Точка MachLine завершилась с кодом 0, конечными коэффициентами и обеими невязками не выше 1e-5.'),
('Y44-210','BLOCK','Точка MachLine не прошла критерий завершения, конечности или невязки.'),
('Y44-211','INFO','Дозвуковая диагностическая точка MachLine не прошла и не включается в гибрид Cx.'),
('Y44-220','BLOCK','Точка отклонена до решателя из-за непригодной геометрии или сетки.'),
('Y44-221','INFO','Точка уровня не запускалась по заранее объявленной области уточнения.'),
('Y44-300','PASS','Переход соседних сеток удовлетворяет допускам по Cx и Cy.'),
('Y44-305','INFO','Промежуточный или дозвуковой диагностический переход не прошёл, но не закрывает итоговую приёмку.'),
('Y44-310','BLOCK','Обязательный переход не удовлетворяет допускам Cx и или Cy.'),
('Y44-320','PASS','FQRUP и LU согласовались при alpha=4°.'),
('Y44-321','BLOCK','Обязательный контроль FQRUP и LU отсутствует или не согласовался.'),
('Y44-322','INFO','Дозвуковой контроль MachLine отсутствует или не согласовался; M=0,8 использует VSPAERO CDi.'),
('Y44-400','CANDIDATE','Гибридный результат собран как инженерная оценка с ограничениями.'),
('Y44-410','BLOCK','Гибрид использует источник, не прошедший сеточный или решательный барьер.'),
('Y44-900','ACCEPT','Условная инженерная приёмка расчёта; не официальная сертификация типа.'),
('Y44-910','STOP','Штатное fail-closed завершение без допуска из-за непройденного обязательного барьера.'),
]
add_table(['Код','Уровень','Значение'],code_rows,[2.0,2.2,11.9],8.0,[WD_ALIGN_PARAGRAPH.CENTER,WD_ALIGN_PARAGRAPH.CENTER,WD_ALIGN_PARAGRAPH.LEFT])
add_text('В выполненном журнале записаны 56 событий Y44-200, 17 событий Y44-300, 12 кандидатов Y44-400 и итоговый Y44-900. Справочные записи включают 2 события Y44-211, 20 событий Y44-221, 22 события Y44-305 и один Y44-322.')

add_text('11 Подтверждённые результаты и инженерные гипотезы', style='Heading 1')
add_table(['Категория','Положение','Статус'],[
    ['Подтверждено','Исходная и рабочая VSP3-копии имели одинаковый SHA-256; исходник не изменён.','Автоматический барьер PASS'],
    ['Подтверждено','Состав и габариты модели прошли заданные допуски.','Автоматический барьер PASS'],
    ['Подтверждено','12 обязательных последних сеточных переходов пройдены.','Численный барьер PASS'],
    ['Подтверждено','FQRUP и LU согласованы на M=1,2 и 2,0 при alpha=4°.','Контроль решателя PASS'],
    ['Инженерная оценка','Гибридные Cy и Cx применимы к объявленной постановке и рассчитанным точкам.','CANDIDATE'],
    ['Гипотеза модели','Профили NACA 64-006 и 64-004 и их толщины описывают реконструкцию.','Не подтверждает реальные 64A-профили'],
    ['Не определено','Статический запас.','Нет CG; CMy дан относительно начала координат'],
    ['Не определено','Сваливание и максимальный Cy.','VLM и MachLine для этого не валидированы'],
    ['Не учтено полностью','Волновое сопротивление толстых тел, щели, антенны, силовая установка и реальный донный режим.','Cx является нижней оценкой'],
],[2.8,9.5,3.8],8.1,[WD_ALIGN_PARAGRAPH.LEFT,WD_ALIGN_PARAGRAPH.LEFT,WD_ALIGN_PARAGRAPH.LEFT])

add_text('12 Ограничения применимости', style='Heading 1')
for item in [
    'Результат является условной инженерной приёмкой расчёта и не заменяет официальную сертификацию типа.',
    'Обозначение NACA 64-006 в модели не подтверждает профиль 64A006 реального аппарата. То же относится к прочим реконструкционным профилям и толщинам.',
    'Без положения центра тяжести нельзя определить статический запас. CMy относится только к началу координат (0,0,0).',
    'VLM и MachLine не являются расчётом сваливания данной модели. Графики нельзя использовать для вывода о максимальном Cy, критическом угле атаки или постсрывном поведении.',
    'Гибридный Cy основан на геометрической замене наклона и не откалиброван по независимому эксперименту.',
    'Гибридный Cx содержит известные расчётные члены, но не включает ряд потенциально значимых составляющих. Указанная RSS-неопределённость не является полной неопределённостью аппарата.',
    'Рассчитаны только M=0,8, 1,2 и 2,0 и alpha=-1°, 0°, 1°, 4°. Соединяющие линии служат для чтения графика, а не для интерполяции или экстраполяции.'
]: add_bullet(item)

add_text('13 Итоговое решение', style='Heading 1')
add_text('Расчётный контур завершён решением CONDITIONAL_ENGINEERING_ACCEPTANCE и статусом ACCEPTED_WITH_DECLARED_LIMITATIONS. Геометрические проверки, принятые MachLine-точки, обязательная сеточная программа и сверхзвуковой FQRUP/LU crosscheck удовлетворили заданным критериям. Все 12 гибридных точек собраны без численно непринятых источников.')
add_text('Этого достаточно для условной инженерной приёмки текущего расчётного набора. Для повышения физической достоверности нужны независимые CFD- или продувочные данные, фактическая геометрия профилей, положение CG и данные по силовой установке и донному течению. Эти сведения не являлись условием текущего автоматического допуска, но необходимы для расширения области выводов.')

papp = add_text('Приложение А Использованные материалы', style='Heading 1')
papp.paragraph_format.page_break_before = True
add_text('Отчёт составлен по неизменяемому набору результатов YFQ_44_unified_pipeline. Основными доказательными файлами служат:')
for item in ['REPORT.md — сводное решение и ограничения.','certificate.json — машинно-читаемый сертификат расчётного контура.','RUN_LOG.md и run_log.csv — хронология автоматических барьеров.','STATUS_CODES.md — нормативная расшифровка Y44-NNN.','hybrid_points.csv — 12 гибридных точек.','machline_points.csv — 78 записей MachLine, включая диагностические и контрольные запуски.','mesh_convergence.csv — 39 сеточных переходов.','solver_crosscheck.csv — сопоставление FQRUP и LU.','aft_cap_report.json — протокол снятия кормовой крышки.','plots — пять включённых графиков.']:
    add_bullet(item)

# Document metadata
doc.core_properties.title = 'Инженерный отчёт по автоматизированной верификации и расчёту модели БПЛА YFQ 44'
doc.core_properties.subject = 'Условная инженерная приёмка расчёта YFQ-44'
doc.core_properties.author = 'Инженерная рабочая группа'
doc.core_properties.keywords = 'YFQ-44, OpenVSP, VSPAERO, MachLine, double-wedge, верификация'

# Avoid splitting table rows and orphaned figures.
for table in doc.tables:
    for row in table.rows:
        trPr = row._tr.get_or_add_trPr()
        cant = OxmlElement('w:cantSplit')
        trPr.append(cant)

doc.save(DOCX)
print(DOCX)
