#!/usr/bin/env python3
"""Generate a compact MachLine matrix around the M=1.2 drag discrepancy."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path


HERE = Path(__file__).resolve().parent
INPUTS = HERE / "inputs"
REPORTS = HERE / "reports"
MESHES = (
    ("7k", Path(r"C:\RepairMach\02_working_meshes\final\MIG_full_7k.tri")),
    ("13k", Path(r"C:\RepairMach\02_working_meshes\final\MIG_full_13k_repaired.tri")),
    ("21k", Path(r"C:\RepairMach\02_working_meshes\final\MIG_full_21k_repaired.tri")),
)
CORE_MACHS = (1.10, 1.15, 1.20, 1.25, 1.30)
CORE_ALPHAS = (-2.0, 0.0, 2.0)
CONTROLS = ((0.80, 0.0), (1.70, 0.0))
PRESSURE_RULES = ("isentropic", "slender-body")
SREF_FT2 = 409.631374


def machline_path(path: Path) -> str:
    return str(path.resolve()).replace("\\", "/").replace("C:/", "C://", 1)


def tag(value: float, prefix: str) -> str:
    sign = "m" if value < 0 else "p"
    return f"{prefix}{sign}{abs(value):.2f}".replace(".", "p")


def main() -> None:
    INPUTS.mkdir(parents=True, exist_ok=True)
    REPORTS.mkdir(parents=True, exist_ok=True)
    points = [(mach, alpha) for mach in CORE_MACHS for alpha in CORE_ALPHAS]
    points.extend(CONTROLS)
    rows: list[dict] = []
    number = 0
    for grid, mesh in MESHES:
        if not mesh.is_file():
            raise FileNotFoundError(mesh)
        for mach, alpha in points:
            for rule in PRESSURE_RULES:
                number += 1
                rule_tag = "ise" if rule == "isentropic" else "sln"
                case_id = f"{number:03d}_{grid}_{tag(mach, 'M')}_{tag(alpha, 'A')}_{rule_tag}"
                input_path = INPUTS / f"{case_id}.json"
                report_path = REPORTS / f"{case_id}_report.json"
                angle = math.radians(alpha)
                payload = {
                    "flow": {
                        "freestream_velocity": [100.0 * math.cos(angle), 0.0, 100.0 * math.sin(angle)],
                        "gamma": 1.4,
                        "freestream_mach_number": mach,
                    },
                    "geometry": {
                        "file": machline_path(mesh),
                        "spanwise_axis": "+y",
                        "wake_model": {
                            "trefftz_distance": 80.0,
                            "wake_present": False,
                            "append_wake": False,
                            "wake_shedding_angle": 150.0,
                        },
                        "reference": {"area": SREF_FT2},
                    },
                    "solver": {
                        "formulation": "dirichlet-morino",
                        "matrix_solver": "GMRES" if mach < 1.0 else "FQRUP",
                        "control_point_offset": 0.00001,
                    },
                    "post_processing": {
                        "pressure_rules": {
                            "isentropic": True,
                            "second-order": True,
                            "slender-body": True,
                            "linear": True,
                        },
                        "pressure_for_forces": rule,
                    },
                    "output": {
                        "body_file": "none",
                        "wake_file": "none",
                        "control_point_file": "none",
                        "report_file": machline_path(report_path),
                    },
                }
                text = json.dumps(payload, indent=2).replace("1e-05", "0.00001")
                input_path.write_text(text + "\n", encoding="utf-8")
                rows.append({
                    "case_id": case_id,
                    "input_name": input_path.name,
                    "input_path": str(input_path.resolve()),
                    "report_path": str(report_path.resolve()),
                    "grid": grid,
                    "mesh_path": str(mesh),
                    "mach": f"{mach:.2f}",
                    "alpha_deg": f"{alpha:.1f}",
                    "pressure_rule": rule,
                    "solver": payload["solver"]["matrix_solver"],
                })
    manifest = HERE / "manifest.csv"
    with manifest.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter=";")
        writer.writeheader()
        writer.writerows(rows)
    print(f"Generated {len(rows)} cases in {manifest}")


if __name__ == "__main__":
    main()
