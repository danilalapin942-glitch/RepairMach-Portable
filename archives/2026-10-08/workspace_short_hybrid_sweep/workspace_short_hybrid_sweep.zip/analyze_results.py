#!/usr/bin/env python3
"""Build zero-lift and additive semi-empirical comparison tables."""

from __future__ import annotations

import csv
import math
from collections import defaultdict
from datetime import datetime
from pathlib import Path


HERE = Path(__file__).resolve().parent
SREF_FT2 = 409.631374
SWET_BODY_FT2 = 882.403
THICKNESS_RATIO = 0.07
FINENESS_RATIO = 8.5
WING_TAIL_MULTIPLIER = 1.2
BOOK_CX0 = {0.8: 0.023, 1.2: 0.048, 1.7: 0.044}
GAPS = (0.0010, 0.00145, 0.00190)
ANTENNA_AREA_FT2 = 0.05
ANTENNA_SHAPE_CD = 1.1


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter=";"))


def write_rows(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def wing_profile_drag(mach: float) -> float:
    return WING_TAIL_MULTIPLIER * 0.003 * (0.93 + 2.8 * THICKNESS_RATIO) * (1.0 - 0.025 * mach)


def body_friction_drag(mach: float) -> float:
    return 0.0025 * (1.0 + 0.9 / FINENESS_RATIO) * (1.0 - 0.025 * mach) * SWET_BODY_FT2 / SREF_FT2


def error(value: float, reference: float | None) -> float | str:
    return "" if reference is None else 100.0 * (value - reference) / reference


def zero_lift(group: list[dict[str, str]]) -> tuple[float, float, float]:
    points = {float(row["alpha_deg"]): row for row in group}
    if not {-2.0, 0.0, 2.0}.issubset(points):
        row = min(group, key=lambda item: abs(float(item["alpha_deg"])))
        return float(row["CD_stream"]), float(row["CN_stream"]), 0.0
    dm, d0, dp = (float(points[a]["CD_stream"]) for a in (-2.0, 0.0, 2.0))
    nm, n0, np = (float(points[a]["CN_stream"]) for a in (-2.0, 0.0, 2.0))
    slope_n = (np - nm) / 4.0
    alpha_zl = -n0 / slope_n if abs(slope_n) > 1.0e-12 else 0.0
    alpha_zl = max(-4.0, min(4.0, alpha_zl))
    linear_d = (dp - dm) / 4.0
    quad_d = (dp + dm - 2.0 * d0) / 8.0
    cd_zl = d0 + linear_d * alpha_zl + quad_d * alpha_zl * alpha_zl
    return cd_zl, n0, alpha_zl


def main() -> None:
    rows = [row for row in read_rows(HERE / "run_summary.csv") if row["status"] == "OK"]
    grouped: dict[tuple[str, float, str], list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        grouped[(row["grid"], float(row["mach"]), row["pressure_rule"])].append(row)

    output = []
    antenna = ANTENNA_SHAPE_CD * ANTENNA_AREA_FT2 / SREF_FT2
    for (grid, mach, rule), group in sorted(grouped.items()):
        h0, cn_alpha0, alpha_zl = zero_lift(group)
        profile = wing_profile_drag(mach)
        friction = body_friction_drag(mach)
        h1 = h0 + profile + friction
        h2_low, h2_nom, h2_high = (h1 + value for value in GAPS)
        h3 = h2_nom + antenna
        book = BOOK_CX0.get(round(mach, 2))
        output.append({
            "grid": grid,
            "mach": mach,
            "pressure_rule": rule,
            "alpha_zero_lift_deg": alpha_zl,
            "CN_at_alpha0": cn_alpha0,
            "H0_pressure": h0,
            "wing_profile": profile,
            "body_friction": friction,
            "H1_pressure_plus_viscous": h1,
            "gaps_low": GAPS[0],
            "gaps_nominal": GAPS[1],
            "gaps_high": GAPS[2],
            "H2_low": h2_low,
            "H2_nominal": h2_nom,
            "H2_high": h2_high,
            "antenna_sensitivity": antenna,
            "H3_nominal_plus_antenna": h3,
            "book_Cx0": "" if book is None else book,
            "H0_error_pct": error(h0, book),
            "H1_error_pct": error(h1, book),
            "H2_nominal_error_pct": error(h2_nom, book),
            "H3_error_pct": error(h3, book),
        })
    write_rows(HERE / "hybrid_ladder.csv", output)

    at_m12 = [row for row in output if abs(float(row["mach"]) - 1.2) < 1.0e-9]
    report = [
        "# Короткая гибридная серия M=1.2",
        "",
        f"Завершено: {datetime.now().astimezone().isoformat(timespec='seconds')}",
        "",
        "H0 — давление MachLine; H1 — H0 + профиль/трение; H2 — H1 + щели;",
        "H3 — H2 + оценка чувствительности к антеннам. Значение антенн не является калибровкой:",
        f"использована условная суммарная лобовая площадь {ANTENNA_AREA_FT2:.3f} ft².",
        "",
        "| сетка | правило | alpha(CN=0) | H0 | H1 | H2 nominal | H3 | ошибки H0/H1/H2/H3 |",
        "|---|---|---:|---:|---:|---:|---:|---:|",
    ]
    for row in at_m12:
        report.append(
            "| {grid} | {pressure_rule} | {alpha_zero_lift_deg:.3f} | {H0_pressure:.5f} | "
            "{H1_pressure_plus_viscous:.5f} | {H2_nominal:.5f} | "
            "{H3_nominal_plus_antenna:.5f} | {H0_error_pct:+.1f}% / {H1_error_pct:+.1f}% / "
            "{H2_nominal_error_pct:+.1f}% / {H3_error_pct:+.1f}% |".format(**row)
        )
    report.extend([
        "",
        "Выбор варианта по совпадению с книгой автоматически не выполняется. Сначала проверяется",
        "сходимость по сетке и физическая применимость каждого дополнительного слагаемого.",
    ])
    (HERE / "REPORT.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print(f"Wrote {len(output)} ladder rows")


if __name__ == "__main__":
    main()
