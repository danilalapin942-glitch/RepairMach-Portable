param([int]$MaxCases = 0)

$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot
$manifestPath = Join-Path $here 'manifest.csv'
$inputRoot = Join-Path $here 'inputs'
$summaryPath = Join-Path $here 'run_summary.csv'
$statusPath = Join-Path $here 'status.json'
$masterLog = Join-Path $here 'machline.log'
$completePath = Join-Path $here 'COMPLETE.txt'
$exe = Join-Path (Split-Path $here -Parent) 'RepairMach_Portable_Candidate\engines\MachLine\machline.exe'
$python = Join-Path (Split-Path $here -Parent) 'RepairMach_Portable_Candidate\runtime\python\python.exe'

$env:OMP_NUM_THREADS = '4'
if (-not (Test-Path -LiteralPath $manifestPath)) { throw "Manifest not found: $manifestPath" }
if (-not (Test-Path -LiteralPath $exe)) { throw "MachLine not found: $exe" }

$cases = @(Import-Csv -LiteralPath $manifestPath -Delimiter ';')
$completed = @{}
if (Test-Path -LiteralPath $summaryPath) {
    foreach ($row in (Import-Csv -LiteralPath $summaryPath -Delimiter ';')) {
        if ($row.status -eq 'OK') { $completed[$row.case_id] = $true }
    }
} else {
    'case_id;grid;mach;alpha_deg;pressure_rule;solver;status;exit_code;runtime_s;Cx;Cy;Cz;CD_stream;CN_stream;residual_norm;report_path' |
        Set-Content -LiteralPath $summaryPath -Encoding utf8
}

$executed = 0
foreach ($case in $cases) {
    if ($completed.ContainsKey($case.case_id)) { continue }
    if ($MaxCases -gt 0 -and $executed -ge $MaxCases) { break }
    $executed++
    $started = Get-Date
    Push-Location $inputRoot
    try {
        $caseOutput = @($case.input_name) | & $exe 2>&1
        $exitCode = $LASTEXITCODE
    } finally {
        Pop-Location
    }
    $caseOutput | ForEach-Object { $_.ToString() } | Add-Content -LiteralPath $masterLog -Encoding utf8

    $status = 'FAILED'
    $runtime = $cx = $cy = $cz = $cd = $cn = $residual = ''
    if (Test-Path -LiteralPath $case.report_path) {
        try {
            $report = Get-Content -Raw -LiteralPath $case.report_path | ConvertFrom-Json
            $status = if ([int]$report.solver_results.solver_status_code -eq 0) { 'OK' } else { 'SOLVER_FAILED' }
            $runtime = [double]$report.total_runtime
            $cx = [double]$report.total_forces.Cx
            $cy = [double]$report.total_forces.Cy
            $cz = [double]$report.total_forces.Cz
            $angle = [Math]::PI * [double]$case.alpha_deg / 180.0
            $cd = $cx * [Math]::Cos($angle) + $cz * [Math]::Sin($angle)
            $cn = $cz * [Math]::Cos($angle) - $cx * [Math]::Sin($angle)
            $residual = [double]$report.solver_results.residual.norm
        } catch {
            $status = 'REPORT_ERROR'
        }
    }
    $values = @(
        $case.case_id, $case.grid, $case.mach, $case.alpha_deg, $case.pressure_rule,
        $case.solver, $status, $exitCode, $runtime, $cx, $cy, $cz, $cd, $cn,
        $residual, $case.report_path
    ) | ForEach-Object { ([string]$_).Replace(';', ',') }
    ($values -join ';') | Add-Content -LiteralPath $summaryPath -Encoding utf8

    $done = @((Import-Csv -LiteralPath $summaryPath -Delimiter ';') | Where-Object status -eq 'OK').Count
    [ordered]@{
        state = 'running'
        current_case = $case.case_id
        completed = $done
        total = $cases.Count
        completed_percent = [Math]::Round(100.0 * $done / $cases.Count, 1)
        last_case_runtime_s = $runtime
        started = $started.ToString('o')
        updated = (Get-Date).ToString('o')
    } | ConvertTo-Json | Set-Content -LiteralPath $statusPath -Encoding utf8
}

$remaining = @($cases | Where-Object { -not $completed.ContainsKey($_.case_id) }).Count - $executed
if ($remaining -le 0) {
    & $python (Join-Path $here 'analyze_results.py')
    "Completed: $((Get-Date).ToString('o'))" | Set-Content -LiteralPath $completePath -Encoding utf8
    $final = Get-Content -LiteralPath $statusPath -Raw | ConvertFrom-Json
    $final.state = 'complete'
    $final.updated = (Get-Date).ToString('o')
    $final | ConvertTo-Json | Set-Content -LiteralPath $statusPath -Encoding utf8
}
