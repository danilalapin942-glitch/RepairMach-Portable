from __future__ import annotations

import csv
import json
import math
import os
import shutil
import subprocess
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path


WORKSPACE = Path(r"C:\Users\admin\.codex\.chatgpt-projects\g-p-6910508be2a081919b9cb5881a96c92b")
HERE = Path(__file__).resolve().parent
APP = WORKSPACE / "github_publish" / "RepairMach-Portable" / "app"
sys.path.insert(0, str(APP))

from vspaero_runner import generate_vspaero_sweep_script, parse_set_report


EXE = Path(r"C:\OpenVSP-3.51.1-win64-Python3.13\OpenVSP-3.51.1-win64\vspscript.exe")
SOURCE = HERE / "MiG-25RB_VSPAero_Wing_v2.vsp3"
RUNS = HERE / "runs"
STATUS = HERE / "status.json"
SUMMARY = HERE / "run_summary.csv"
MAX_WALL_SECONDS = int(7.5 * 3600)
POINT_TIMEOUT_SECONDS = 300

SREF = 660.904
CREF = 16.378
BREF = 43.898


def now() -> datetime:
    return datetime.now(timezone.utc)


def iso_now() -> str:
    return now().isoformat()


def tag(value: float) -> str:
    return f"{value:.2f}".rstrip("0").rstrip(".").replace(".", "p")


BASE_MACHS = [0.5, 0.8, 1.2, 1.7, 2.2]


def make_cases() -> list[dict]:
    cases: list[dict] = []
    # The first pair is a pilot and also forms part of the baseline curve.
    ordered = [1.2] + [m for m in BASE_MACHS if m != 1.2]
    for mach in ordered:
        for alpha in (0.0, 1.0, 2.0):
            cases.append({
                "stage": "baseline",
                "mach": mach,
                "alpha": alpha,
                "wake": 2,
                "nodes": 24,
                "relax": 0.8,
                "gmres": 1.0,
            })
    for mach in (0.5, 1.2, 1.7, 2.2):
        for name, wake, nodes in (("coarse", 1, 12), ("refined", 4, 36)):
            for alpha in (0.0, 1.0):
                cases.append({
                    "stage": f"convergence_{name}",
                    "mach": mach,
                    "alpha": alpha,
                    "wake": wake,
                    "nodes": nodes,
                    "relax": 0.8,
                    "gmres": 1.0,
                })
    return cases


CASES = make_cases()


def case_id(case: dict) -> str:
    return f"{case['stage']}_M{tag(case['mach'])}_A{tag(case['alpha'])}"


def process_ids(image: str) -> set[int]:
    proc = subprocess.run(
        ["tasklist", "/FI", f"IMAGENAME eq {image}", "/FO", "CSV", "/NH"],
        capture_output=True,
        text=True,
        errors="replace",
        check=False,
    )
    result = set()
    for row in csv.reader((proc.stdout or "").splitlines()):
        if len(row) >= 2 and row[0].lower() == image.lower():
            try:
                result.add(int(row[1]))
            except ValueError:
                pass
    return result


def kill_pid(pid: int) -> None:
    try:
        subprocess.run(
            ["taskkill", "/PID", str(pid), "/T", "/F"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=12,
            check=False,
        )
    except subprocess.TimeoutExpired:
        try:
            os.kill(pid, 15)
        except OSError:
            pass


def execute(script: Path, directory: Path) -> tuple[int, str, float]:
    baseline = process_ids("vspaero.exe")
    started = time.monotonic()
    log = directory / "process.log"
    with log.open("w", encoding="utf-8", errors="replace") as stream:
        proc = subprocess.Popen(
            [str(EXE), "-script", str(script)],
            cwd=str(directory),
            stdout=stream,
            stderr=subprocess.STDOUT,
            creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0),
        )
        try:
            code = int(proc.wait(timeout=POINT_TIMEOUT_SECONDS) or 0)
        except subprocess.TimeoutExpired:
            kill_pid(proc.pid)
            for child in process_ids("vspaero.exe") - baseline:
                kill_pid(child)
            code = 124
    return code, log.read_text(encoding="utf-8", errors="replace"), time.monotonic() - started


def read_series(path: Path) -> dict[str, list[float]]:
    series: dict[str, list[float]] = {}
    if not path.is_file():
        return series
    with path.open("r", encoding="utf-8-sig", errors="replace", newline="") as stream:
        for row in csv.reader(stream):
            if not row:
                continue
            values = []
            for raw in row[1:]:
                try:
                    value = float(raw)
                except ValueError:
                    continue
                if math.isfinite(value):
                    values.append(value)
            if values and row[0].strip() not in series:
                series[row[0].strip()] = values
    return series


def last(series: dict[str, list[float]], key: str):
    values = series.get(key)
    return values[-1] if values else None


def write_status(state: str, completed: int, current: str = "", message: str = "") -> None:
    elapsed = max(0.001, time.monotonic() - START_MONOTONIC)
    rate = completed / elapsed if completed else 0.0
    remaining = len(CASES) - completed
    eta = remaining / rate if rate else None
    STATUS.write_text(json.dumps({
        "state": state,
        "pid": os.getpid(),
        "completed_cases": completed,
        "total_cases": len(CASES),
        "current": current,
        "message": message,
        "started_at": STARTED_AT,
        "updated_at": iso_now(),
        "elapsed_seconds": elapsed,
        "eta_seconds": eta,
        "eta_at": (now() + timedelta(seconds=eta)).isoformat() if eta else None,
        "max_wall_seconds": MAX_WALL_SECONDS,
        "reference": {"Sref_ft2": SREF, "Cref_ft": CREF, "Bref_ft": BREF},
        "selection_rule": "exposed-only Wing diagnostic; fixed geometry; book curve excluded from solver selection",
    }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


FIELDS = [
    "case_id", "stage", "mach", "alpha_deg", "status", "return_code", "runtime_s",
    "Cy", "CDi", "CDo", "log10_L2", "log10_max", "wake", "nodes", "updated_at",
]


def append_summary(row: dict) -> None:
    new = not SUMMARY.exists()
    with SUMMARY.open("a", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=FIELDS, delimiter=";")
        if new:
            writer.writeheader()
        writer.writerow({key: row.get(key, "") for key in FIELDS})


def cached(cid: str) -> bool:
    path = RUNS / cid / "summary.json"
    if not path.is_file():
        return False
    try:
        return bool(json.loads(path.read_text(encoding="utf-8")).get("finished"))
    except (ValueError, OSError):
        return False


def run_case(case: dict) -> dict:
    cid = case_id(case)
    directory = RUNS / cid
    directory.mkdir(parents=True, exist_ok=True)
    model = directory / "model.vsp3"
    script = directory / "run.vspscript"
    result_csv = directory / "results.csv"
    shutil.copy2(SOURCE, model)
    generate_vspaero_sweep_script(
        script,
        model,
        result_csv,
        mach_start=case["mach"],
        mach_end=case["mach"],
        mach_points=1,
        alpha_start=case["alpha"],
        alpha_end=case["alpha"],
        alpha_points=1,
        beta_deg=0.0,
        reference_area=SREF,
        reference_chord=CREF,
        reference_span=BREF,
        center=(0.0, 0.0, 0.0),
        fuselage_user_set=1,
        wing_user_set=2,
        ncpu=4,
        forward_gmres_convergence_factor=case["gmres"],
        wake_num_iter=case["wake"],
        num_wake_nodes=case["nodes"],
        wake_relax=case["relax"],
        tail_geometry_name="GO",
        tail_incidence_deg=0.0,
        # The imported model had the inlet on To Face but retained a different
        # outlet mode.  Apply the same explicit To Face boundary to both ends
        # so the flow-through gondola has one unambiguous VSPAERO treatment.
        engine_boundary="to_face",
        require_canonical_components=True,
        require_nonempty_fuselage_set=True,
        require_all_geometries_assigned=False,
    )
    code, output, elapsed = execute(script, directory)
    report = parse_set_report(output)
    series = read_series(result_csv)
    row = {
        "finished": True,
        "case_id": cid,
        "stage": case["stage"],
        "mach": case["mach"],
        "alpha_deg": case["alpha"],
        "status": "OK" if code == 0 and report.get("valid") and report.get("calculation_complete") and last(series, "CLtot") is not None else "FAILED",
        "return_code": code,
        "runtime_s": elapsed,
        "Cy": last(series, "CLtot"),
        "CDi": last(series, "CDi"),
        "CDo": last(series, "CDo"),
        "log10_L2": last(series, "log10( L2Residual )"),
        "log10_max": last(series, "log10( MaxResidual )"),
        "wake": case["wake"],
        "nodes": case["nodes"],
        "updated_at": iso_now(),
    }
    (directory / "summary.json").write_text(json.dumps(row, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    append_summary(row)
    return row


def main() -> None:
    if not EXE.is_file():
        raise FileNotFoundError(EXE)
    if not SOURCE.is_file():
        raise FileNotFoundError(SOURCE)
    RUNS.mkdir(exist_ok=True)
    completed = sum(cached(case_id(case)) for case in CASES)
    write_status("running", completed)
    failures = 0
    for case in CASES:
        if time.monotonic() - START_MONOTONIC >= MAX_WALL_SECONDS:
            write_status("time_budget_complete", completed, message="7.5 h wall-time budget reached")
            return
        cid = case_id(case)
        if cached(cid):
            continue
        write_status("running", completed, current=cid)
        row = run_case(case)
        completed += 1
        failures += row["status"] != "OK"
        write_status("running", completed, current=cid, message=f"failures={failures}")
    write_status("complete" if failures == 0 else "complete_with_failures", completed, message=f"failures={failures}")


START_MONOTONIC = time.monotonic()
STARTED_AT = iso_now()


if __name__ == "__main__":
    main()
