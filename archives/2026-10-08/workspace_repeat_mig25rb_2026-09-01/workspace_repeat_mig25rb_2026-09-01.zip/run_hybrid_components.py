from __future__ import annotations

import csv
import json
import math
import shutil
import subprocess
import sys
import time
from pathlib import Path


WORKSPACE = Path(r"C:\Users\admin\.codex\.chatgpt-projects\g-p-6910508be2a081919b9cb5881a96c92b")
HERE = Path(__file__).resolve().parent
APP = WORKSPACE / "github_publish" / "RepairMach-Portable" / "app"
sys.path.insert(0, str(APP))

from vspaero_runner import generate_vspaero_sweep_script, parse_set_report


EXE = Path(r"C:\OpenVSP-3.51.1-win64-Python3.13\OpenVSP-3.51.1-win64\vspscript.exe")
SREF = 660.904
CREF = 16.378
BREF = 43.898
MACHS = (0.5, 0.8, 1.2, 1.3, 1.4, 1.7, 2.2)
CONFIGS = {
    "wing_only": HERE / "component_wing_only.vsp3",
    "thin_all": HERE / "component_thin_all.vsp3",
}


def tag(value: float) -> str:
    return f"{value:.1f}".replace(".", "p")


def read_series(path: Path) -> dict[str, list[float]]:
    series: dict[str, list[float]] = {}
    if not path.is_file():
        return series
    with path.open("r", encoding="utf-8-sig", errors="replace", newline="") as stream:
        for row in csv.reader(stream):
            if not row:
                continue
            values = []
            for raw in row[1:]:
                try:
                    value = float(raw)
                except ValueError:
                    continue
                if math.isfinite(value):
                    values.append(value)
            if values and row[0].strip() not in series:
                series[row[0].strip()] = values
    return series


def last(series: dict[str, list[float]], key: str):
    values = series.get(key)
    return values[-1] if values else None


def run_point(config: str, source: Path, mach: float, alpha: float) -> dict:
    run_dir = HERE / "hybrid_component_runs" / config / f"M{tag(mach)}_A{int(alpha)}"
    run_dir.mkdir(parents=True, exist_ok=True)
    model = run_dir / "model.vsp3"
    script = run_dir / "run.vspscript"
    results = run_dir / "results.csv"
    log = run_dir / "process.log"
    shutil.copy2(source, model)
    generate_vspaero_sweep_script(
        script,
        model,
        results,
        mach_start=mach,
        mach_end=mach,
        mach_points=1,
        alpha_start=alpha,
        alpha_end=alpha,
        alpha_points=1,
        beta_deg=0.0,
        reference_area=SREF,
        reference_chord=CREF,
        reference_span=BREF,
        center=(0.0, 0.0, 0.0),
        fuselage_user_set=1,
        wing_user_set=2,
        ncpu=4,
        forward_gmres_convergence_factor=1.0,
        wake_num_iter=2,
        num_wake_nodes=24,
        wake_relax=0.8,
        tail_geometry_name=None,
        require_canonical_components=False,
        require_nonempty_fuselage_set=False,
        require_all_geometries_assigned=False,
    )
    started = time.monotonic()
    with log.open("w", encoding="utf-8", errors="replace") as stream:
        completed = subprocess.run(
            [str(EXE), "-script", str(script)],
            cwd=str(run_dir),
            stdout=stream,
            stderr=subprocess.STDOUT,
            timeout=240,
            check=False,
        )
    output = log.read_text(encoding="utf-8", errors="replace")
    report = parse_set_report(output)
    data = read_series(results)
    return {
        "config": config,
        "mach": mach,
        "alpha_deg": alpha,
        "status": "OK" if report.get("valid") and last(data, "CLtot") is not None else "FAILED",
        "return_code": completed.returncode,
        "runtime_s": time.monotonic() - started,
        "Cy": last(data, "CLtot"),
        "log10_L2": last(data, "log10( L2Residual )"),
        "log10_max": last(data, "log10( MaxResidual )"),
    }


def main() -> None:
    rows = []
    for config, source in CONFIGS.items():
        for mach in MACHS:
            for alpha in (0.0, 1.0):
                row = run_point(config, source, mach, alpha)
                rows.append(row)
                print(json.dumps(row, ensure_ascii=False), flush=True)

    path = HERE / "hybrid_component_summary.csv"
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), delimiter=";")
        writer.writeheader()
        writer.writerows(rows)
    (HERE / "hybrid_component_status.json").write_text(
        json.dumps(
            {
                "state": "complete" if all(r["status"] == "OK" for r in rows) else "complete_with_failures",
                "completed": len(rows),
                "failures": sum(r["status"] != "OK" for r in rows),
            },
            ensure_ascii=False,
            indent=2,
        ) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
