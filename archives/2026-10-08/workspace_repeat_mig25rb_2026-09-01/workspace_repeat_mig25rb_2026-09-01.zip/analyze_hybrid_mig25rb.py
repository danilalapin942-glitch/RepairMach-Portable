from __future__ import annotations

import csv
import json
import math
from pathlib import Path


HERE = Path(__file__).resolve().parent
SREF = 660.904
BREF = 43.898
AR_EFFECTIVE = BREF * BREF / SREF

# Full-aircraft values are direct, converged VSPAERO increments.  M=1.4 is
# reused from the preceding complete series because the five-point repeat was
# intentionally a screening run and reproduced all common points bit-for-bit.
FULL = {
    0.5: 0.029202437083,
    0.8: 0.035502433024,
    1.2: 0.035732093697,
    1.4: 0.03664879,
    1.7: 0.032419044953,
    2.2: 0.024969398934,
}

# Direct thin-system VSPAERO increments from this run.
THIN_ALL = {
    0.5: 0.028470707520,
    0.8: 0.030297798436,
    1.2: 0.035874363308,
    1.4: 0.036693095062,
    1.7: 0.032495484254,
    2.2: 0.024461111668,
}

# Digitized only for post-calculation verification; never used in the hybrid
# computation.  Figure 2.5, practical aerodynamics of MiG-25RB.
REFERENCE = {
    0.5: 0.0640,
    0.8: 0.0690,
    1.2: 0.0640,
    1.4: 0.0540,
    1.7: 0.0420,
    2.2: 0.0345,
}


def finite_wing_slope(mach: float, aspect_ratio: float) -> float:
    beta = math.sqrt(abs(1.0 - mach * mach))
    per_radian = 2.0 * math.pi * aspect_ratio / (
        2.0 + math.sqrt(4.0 + aspect_ratio * aspect_ratio * beta * beta)
    )
    return per_radian * math.pi / 180.0


def main() -> None:
    rows = []
    for mach in sorted(FULL):
        semi_effective_planform = finite_wing_slope(mach, AR_EFFECTIVE)
        thick_body_residual = FULL[mach] - THIN_ALL[mach]
        # RM92 candidate: replace the complete inviscid thin-system slope by
        # the semiempirical effective wing-body planform and retain only the
        # directly calculated thick-body/interference residual.
        hybrid = semi_effective_planform + thick_body_residual
        direct_error = 100.0 * (FULL[mach] - REFERENCE[mach]) / REFERENCE[mach]
        hybrid_error = 100.0 * (hybrid - REFERENCE[mach]) / REFERENCE[mach]
        rows.append({
            "mach": mach,
            "Cya_full_vspaero": FULL[mach],
            "Cya_thin_all_vspaero": THIN_ALL[mach],
            "Cya_thick_body_residual": thick_body_residual,
            "effective_aspect_ratio": AR_EFFECTIVE,
            "Cya_effective_planform_semiempirical": semi_effective_planform,
            "Cya_hybrid": hybrid,
            "book_Cya": REFERENCE[mach],
            "direct_error_pct": direct_error,
            "hybrid_error_pct": hybrid_error,
            "hybrid_abs_error_pct": abs(hybrid_error),
            "method": "RM92-CYA-WINGBODY-1-candidate",
        })

    with (HERE / "hybrid_mig25rb_summary.csv").open(
        "w", encoding="utf-8-sig", newline=""
    ) as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), delimiter=";")
        writer.writeheader()
        writer.writerows(rows)

    metrics = {
        "method": "RM92-CYA-WINGBODY-1-candidate",
        "reference_is_postprocessing_only": True,
        "effective_aspect_ratio": AR_EFFECTIVE,
        "mean_abs_direct_error_pct": sum(abs(r["direct_error_pct"]) for r in rows) / len(rows),
        "mean_abs_hybrid_error_pct": sum(r["hybrid_abs_error_pct"] for r in rows) / len(rows),
        "max_abs_hybrid_error_pct": max(r["hybrid_abs_error_pct"] for r in rows),
        "points_within_11_pct": sum(r["hybrid_abs_error_pct"] <= 11.0 for r in rows),
        "points_within_20_pct": sum(r["hybrid_abs_error_pct"] <= 20.0 for r in rows),
        "point_count": len(rows),
        "rows": rows,
    }
    (HERE / "hybrid_mig25rb_metrics.json").write_text(
        json.dumps(metrics, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(metrics, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
