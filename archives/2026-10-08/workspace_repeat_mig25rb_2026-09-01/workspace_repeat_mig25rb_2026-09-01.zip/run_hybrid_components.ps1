$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$python = 'C:\Users\admin\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$log = Join-Path $here 'hybrid_components.log'

if (-not (Test-Path -LiteralPath $python)) { throw "Python not found: $python" }

Set-Location -LiteralPath $here
& $python (Join-Path $here 'run_hybrid_components.py') *>> $log
