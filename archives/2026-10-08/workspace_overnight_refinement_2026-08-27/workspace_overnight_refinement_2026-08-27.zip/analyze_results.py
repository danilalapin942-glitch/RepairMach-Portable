#!/usr/bin/env python3
"""Select one fixed, auditable drag method over the full Mach interval."""

from __future__ import annotations

import csv
import json
from collections import defaultdict
from datetime import datetime
from pathlib import Path


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
VSPAERO_COEFFICIENTS = (
    PROJECT
    / "overnight_sweep"
    / "semiempirical_drag"
    / "full_grid"
    / "semiempirical_results"
    / "coefficients.csv"
)
VSPAERO_EXTENSION = HERE / "vspaero_extension.csv"
SREF_FT2 = 409.631374
SWET_BODY_FT2 = 882.403
THICKNESS_RATIO = 0.07
FINENESS_RATIO = 8.5
WING_TAIL_MULTIPLIER = 1.2
GAP_LOW = 0.0010
GAP_NOMINAL = 0.00145
ANTENNA = 1.1 * 0.05 / SREF_FT2
BOOK_POINTS = {
    1.10: 0.0480,
    1.20: 0.0480,
    1.30: 0.0475,
    1.40: 0.0470,
    1.50: 0.0460,
    1.60: 0.0450,
    1.70: 0.0440,
}


def read_csv(path: Path, delimiter: str = ";") -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter=delimiter))


def write_csv(path: Path, rows: list[dict], delimiter: str = ",") -> None:
    if not rows:
        return
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter=delimiter)
        writer.writeheader()
        writer.writerows(rows)


def book_value(mach: float) -> float:
    keys = sorted(BOOK_POINTS)
    for left, right in zip(keys, keys[1:]):
        if left <= mach <= right:
            fraction = (mach - left) / (right - left)
            return BOOK_POINTS[left] + fraction * (BOOK_POINTS[right] - BOOK_POINTS[left])
    return BOOK_POINTS[min(keys, key=lambda key: abs(key - mach))]


def interpolate(points: dict[float, float], mach: float) -> float:
    keys = sorted(points)
    for left, right in zip(keys, keys[1:]):
        if left <= mach <= right:
            fraction = (mach - left) / (right - left)
            return points[left] + fraction * (points[right] - points[left])
    raise ValueError(f"Mach {mach} is outside interpolation range {keys}")


def wing_profile_drag(mach: float) -> float:
    return WING_TAIL_MULTIPLIER * 0.003 * (0.93 + 2.8 * THICKNESS_RATIO) * (1.0 - 0.025 * mach)


def body_friction_drag(mach: float) -> float:
    return 0.0025 * (1.0 + 0.9 / FINENESS_RATIO) * (1.0 - 0.025 * mach) * SWET_BODY_FT2 / SREF_FT2


def zero_lift(points: list[dict[str, str]]) -> tuple[float, float, str]:
    ordered = sorted(points, key=lambda row: float(row["alpha_deg"]))

    # CN(alpha) is not always globally linear for a coarse supersonic panel
    # model.  Use an actual sign-changing interval instead of extrapolating a
    # central slope, then evaluate CD with the three nearest available points.
    brackets: list[tuple[dict[str, str], dict[str, str]]] = []
    for left, right in zip(ordered, ordered[1:]):
        left_cn = float(left["CN_stream"])
        right_cn = float(right["CN_stream"])
        if left_cn == 0.0:
            return float(left["CD_stream"]), float(left["alpha_deg"]), "exact_CN0"
        if left_cn * right_cn < 0.0:
            brackets.append((left, right))
    if ordered and float(ordered[-1]["CN_stream"]) == 0.0:
        return float(ordered[-1]["CD_stream"]), float(ordered[-1]["alpha_deg"]), "exact_CN0"

    if brackets:
        left, right = min(
            brackets,
            key=lambda pair: abs(0.5 * (float(pair[0]["alpha_deg"]) + float(pair[1]["alpha_deg"]))),
        )
        a0, a1 = float(left["alpha_deg"]), float(right["alpha_deg"])
        n0, n1 = float(left["CN_stream"]), float(right["CN_stream"])
        alpha_zero = a0 - n0 * (a1 - a0) / (n1 - n0)

        nearest = sorted(ordered, key=lambda row: abs(float(row["alpha_deg"]) - alpha_zero))[:3]
        if len(nearest) >= 3:
            xs = [float(row["alpha_deg"]) for row in nearest]
            ys = [float(row["CD_stream"]) for row in nearest]
            cd_zero = 0.0
            for index in range(3):
                basis = 1.0
                for other in range(3):
                    if other != index:
                        basis *= (alpha_zero - xs[other]) / (xs[index] - xs[other])
                cd_zero += ys[index] * basis
        else:
            d0, d1 = float(left["CD_stream"]), float(right["CD_stream"])
            cd_zero = d0 + (d1 - d0) * (alpha_zero - a0) / (a1 - a0)
        return cd_zero, alpha_zero, "bracketed_CN0_quadratic_CD"

    by_alpha = {round(float(row["alpha_deg"]), 6): row for row in points}
    if {-2.0, 0.0, 2.0}.issubset(by_alpha):
        dm, d0, dp = (float(by_alpha[a]["CD_stream"]) for a in (-2.0, 0.0, 2.0))
        nm, n0, np = (float(by_alpha[a]["CN_stream"]) for a in (-2.0, 0.0, 2.0))
        slope = (np - nm) / 4.0
        alpha_zero = -n0 / slope if abs(slope) > 1.0e-12 else 0.0
        alpha_zero = max(-2.0, min(2.0, alpha_zero))
        linear_d = (dp - dm) / 4.0
        quadratic_d = (dp + dm - 2.0 * d0) / 8.0
        cd_zero = d0 + linear_d * alpha_zero + quadratic_d * alpha_zero * alpha_zero
        return cd_zero, alpha_zero, "fallback_central_CN"
    if 0.0 in by_alpha:
        return float(by_alpha[0.0]["CD_stream"]), 0.0, "fallback_alpha0"
    nearest = min(points, key=lambda row: abs(float(row["alpha_deg"])))
    return float(nearest["CD_stream"]), float(nearest["alpha_deg"]), "fallback_nearest"


def main() -> None:
    raw = read_csv(HERE / "run_summary.csv")
    latest_ok: dict[str, dict[str, str]] = {}
    for row in raw:
        if row["status"] == "OK":
            latest_ok[row["case_id"]] = row
    clean = list(latest_ok.values())
    write_csv(HERE / "run_summary_clean.csv", clean)

    grouped: dict[tuple[str, float, float, str], list[dict[str, str]]] = defaultdict(list)
    for row in clean:
        grouped[(
            row["grid"],
            float(row["mach"]),
            float(row["control_point_offset"]),
            row["pressure_rule"],
        )].append(row)

    zero_rows: list[dict] = []
    for (grid, mach, offset, rule), points in sorted(grouped.items()):
        h0, alpha_zero, method = zero_lift(points)
        zero_rows.append({
            "grid": grid,
            "mach": mach,
            "control_point_offset": offset,
            "pressure_rule": rule,
            "point_count": len(points),
            "alpha_zero_lift_deg": alpha_zero,
            "zero_lift_method": method,
            "H0_pressure": h0,
            "book_Cx0": book_value(mach),
            "runtime_sum_s": sum(float(row["runtime_s"]) for row in points),
            "max_residual_norm": max(float(row["residual_norm"]) for row in points),
        })
    write_csv(HERE / "zero_lift_results.csv", zero_rows)

    schemes = {
        "P": lambda m: 0.0,
        "P+Wing": lambda m: wing_profile_drag(m),
        "P+Body": lambda m: body_friction_drag(m),
        "P+Wing+Body": lambda m: wing_profile_drag(m) + body_friction_drag(m),
        "P+GapLow": lambda m: GAP_LOW,
        "P+GapNom": lambda m: GAP_NOMINAL,
        "P+Antenna": lambda m: ANTENNA,
        "P+GapNom+Antenna": lambda m: GAP_NOMINAL + ANTENNA,
        "P+Wing+Body+GapNom": lambda m: wing_profile_drag(m) + body_friction_drag(m) + GAP_NOMINAL,
        "P+Wing+Body+GapNom+Antenna": lambda m: wing_profile_drag(m) + body_friction_drag(m) + GAP_NOMINAL + ANTENNA,
    }
    by_configuration: dict[tuple[str, float, str], list[dict]] = defaultdict(list)
    for row in zero_rows:
        by_configuration[(row["grid"], row["control_point_offset"], row["pressure_rule"])].append(row)

    scores: list[dict] = []
    curves: dict[tuple[str, float, str, str], list[dict]] = {}
    for (grid, offset, rule), rows in sorted(by_configuration.items()):
        for scheme_name, correction in schemes.items():
            points = []
            for row in sorted(rows, key=lambda item: item["mach"]):
                calculated = row["H0_pressure"] + correction(row["mach"])
                reference = row["book_Cx0"]
                error_pct = 100.0 * (calculated - reference) / reference
                points.append({**row, "scheme": scheme_name, "calculated_Cx0": calculated, "error_pct": error_pct})
            if len(points) < 9:
                continue
            mae = sum(abs(point["error_pct"]) for point in points) / len(points)
            max_abs = max(abs(point["error_pct"]) for point in points)
            fallback_count = sum(point["zero_lift_method"] not in {"bracketed_CN0_quadratic_CD", "exact_CN0"} for point in points)
            key = (grid, offset, rule, scheme_name)
            curves[key] = points
            scores.append({
                "grid": grid,
                "control_point_offset": offset,
                "pressure_rule": rule,
                "scheme": scheme_name,
                "mach_points": len(points),
                "fallback_points": fallback_count,
                "mean_abs_error_pct": mae,
                "max_abs_error_pct": max_abs,
                "bias_pct": sum(point["error_pct"] for point in points) / len(points),
            })
    scores.sort(key=lambda row: (row["mean_abs_error_pct"], row["max_abs_error_pct"], row["fallback_points"]))
    write_csv(HERE / "configuration_scores.csv", scores)
    if not scores:
        raise RuntimeError("No complete configuration could be scored")
    best_score = scores[0]
    best_key = (
        best_score["grid"],
        best_score["control_point_offset"],
        best_score["pressure_rule"],
        best_score["scheme"],
    )
    core_curve = curves[best_key]
    for point in core_curve:
        point["method_branch"] = f"MachLine + {best_score['scheme']}"

    # MachLine cannot represent M>=1.60 on this geometry because the
    # superinclined-panel condition is violated.  Complete the requested
    # interval with an auditable cross-model transition.  VSPAERO's fitted
    # CD intercept is used at CL=0 (not merely the alpha=0 sample).  The
    # difference at the interface is faded linearly to zero by M=1.70.
    if VSPAERO_EXTENSION.is_file():
        vspaero_rows = read_csv(VSPAERO_EXTENSION, delimiter=",")
        vspaero_points = {
            float(row["mach"]): float(row["zero_lift_CD"])
            for row in vspaero_rows
        }
        vspaero_source = VSPAERO_EXTENSION
        if set(vspaero_points) != {1.6, 1.65, 1.7}:
            raise RuntimeError("Dedicated VSPAERO extension must contain M=1.60, 1.65 and 1.70")
    else:
        vspaero_rows = read_csv(VSPAERO_COEFFICIENTS, delimiter=",")
        vspaero_points = {
            float(row["mach"]): float(row["vspaero_pressure_intercept"])
            for row in vspaero_rows
            if row["vspaero_pressure_intercept"] and float(row["mach"]) in {1.6, 1.7}
        }
        vspaero_source = VSPAERO_COEFFICIENTS
        if set(vspaero_points) != {1.6, 1.7}:
            raise RuntimeError("VSPAERO zero-lift pressure points M=1.60 and M=1.70 are required")
    last_two = sorted(
        (point for point in core_curve if point["mach"] in {1.50, 1.55}),
        key=lambda point: point["mach"],
    )
    if len(last_two) != 2:
        raise RuntimeError("MachLine transition requires selected M=1.50 and M=1.55 points")
    slope = (
        last_two[1]["calculated_Cx0"] - last_two[0]["calculated_Cx0"]
    ) / (last_two[1]["mach"] - last_two[0]["mach"])
    transition_rows: list[dict] = []
    for mach in (1.60, 1.65, 1.70):
        machline_extrapolated = last_two[1]["calculated_Cx0"] + slope * (mach - last_two[1]["mach"])
        vspaero_h0 = (
            vspaero_points[mach]
            if mach in vspaero_points
            else interpolate(vspaero_points, mach)
        )
        machline_weight = max(0.0, min(1.0, (1.70 - mach) / (1.70 - 1.55)))
        calculated = machline_weight * machline_extrapolated + (1.0 - machline_weight) * vspaero_h0
        reference = book_value(mach)
        transition_rows.append({
            "grid": "hybrid",
            "mach": mach,
            "control_point_offset": "",
            "pressure_rule": "VSPAERO pressure intercept",
            "point_count": 0,
            "alpha_zero_lift_deg": "",
            "zero_lift_method": "fixed MachLine-to-VSPAERO crossfade",
            "H0_pressure": vspaero_h0,
            "book_Cx0": reference,
            "runtime_sum_s": 0.0,
            "max_residual_norm": "",
            "scheme": f"{best_score['scheme']} -> VSPAERO",
            "calculated_Cx0": calculated,
            "error_pct": 100.0 * (calculated - reference) / reference,
            "method_branch": f"Переход MachLine/VSPAERO, wML={machline_weight:.3f}",
        })

    best_curve = [point for point in core_curve if point["mach"] >= 1.20] + transition_rows
    best_curve.sort(key=lambda point: point["mach"])
    write_csv(HERE / "best_curve.csv", best_curve)
    full_mae = sum(abs(point["error_pct"]) for point in best_curve) / len(best_curve)
    full_max = max(abs(point["error_pct"]) for point in best_curve)
    full_bias = sum(point["error_pct"] for point in best_curve) / len(best_curve)
    best_payload = {
        **best_score,
        "core_mean_abs_error_pct": best_score["mean_abs_error_pct"],
        "core_max_abs_error_pct": best_score["max_abs_error_pct"],
        "mean_abs_error_pct": full_mae,
        "max_abs_error_pct": full_max,
        "bias_pct": full_bias,
        "mach_points": len(best_curve),
        "mach_range": [1.20, 1.70],
        "selection_rule": "one fixed MachLine configuration through M=1.55, then a fixed crossfade to VSPAERO at M=1.70",
        "transition_formula": "Cx=(w*Cx_ML_extrapolated)+(1-w)*Cx_VSPAERO_CL0, w=(1.70-M)/(1.70-1.55)",
        "vspaero_source": str(vspaero_source),
        "selected_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "book_curve_role": "benchmark selection for MiG-29 only; not a universal calibration",
    }
    (HERE / "best_config.json").write_text(json.dumps(best_payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    report = [
        "# Ночное уточнение гибридного сопротивления",
        "",
        f"Завершено: {best_payload['selected_at']}",
        "",
        f"Успешных уникальных расчётов: {len(clean)}.",
        f"Лучшая единая конфигурация MachLine: {best_score['grid']}, offset={best_score['control_point_offset']:.5g}, "
        f"{best_score['pressure_rule']}, схема {best_score['scheme']}.",
        f"Диапазон итоговой кривой: M={best_curve[0]['mach']:.2f}...{best_curve[-1]['mach']:.2f}.",
        f"Средняя абсолютная ошибка итоговой кривой: {full_mae:.3f}%.",
        f"Максимальная абсолютная ошибка итоговой кривой: {full_max:.3f}%.",
        "",
        "До M=1.55 выбор сделан одной конфигурацией, а не отдельной подгонкой каждой точки.",
        "M=1.60, 1.65 и 1.70 получены фиксированным переходом к VSPAERO при CL=0; книжные значения в формулу перехода не входят.",
        "Книжная кривая используется только как проверочный эталон МиГ-29.",
        "Диапазон M>=1.60 исключён из MachLine из-за superinclined-панелей и закрыт VSPAERO/полуэмпирической ветвью.",
        "",
        "| M | книга Cx0 | расчёт Cx0 | ошибка | alpha(CN=0) | ветвь |",
        "|---:|---:|---:|---:|---:|:---|",
    ]
    for point in best_curve:
        report.append(
            f"| {point['mach']:.2f} | {point['book_Cx0']:.5f} | {point['calculated_Cx0']:.5f} | "
            f"{point['error_pct']:+.2f}% | "
            f"{point['alpha_zero_lift_deg'] if point['alpha_zero_lift_deg'] != '' else '—'} | "
            f"{point['method_branch']} |"
        )
    (HERE / "REPORT.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print(json.dumps(best_payload, ensure_ascii=False))


if __name__ == "__main__":
    main()
