#!/usr/bin/env python3
"""Generate the dedicated M=1.60/1.65/1.70 VSPAERO zero-lift sweep."""

from __future__ import annotations

from pathlib import Path


HERE = Path(__file__).resolve().parent
RUN_DIR = HERE / "vspaero_extension"
SOURCE = Path(r"C:\RepairMach\01_geometry_cases\full_aircraft\FUCKOFF_MIG5_closed.vsp3")
BASE = "RepairMach91_M160_M170"


def vsp_path(path: Path) -> str:
    return str(path.resolve()).replace("\\", "/")


def main() -> None:
    if not SOURCE.is_file():
        raise FileNotFoundError(SOURCE)
    RUN_DIR.mkdir(parents=True, exist_ok=True)
    script = f'''void main()
{{
    string source = "{vsp_path(SOURCE)}";
    string base = "{BASE}";
    int thick_set = 7;
    int thin_set = 6;

    ClearVSPModel();
    ReadVSPFile( source );
    Update();
    array<string> geoms = FindGeoms();
    if ( geoms.size() < 6 )
    {{
        Print( "REPAIRMACH_EXTENSION_ERROR=expected_at_least_6_geometries" );
        return;
    }}
    for ( uint i = 0; i < geoms.size(); ++i )
    {{
        SetSetFlag( geoms[i], thick_set, false );
        SetSetFlag( geoms[i], thin_set, false );
    }}
    SetSetFlag( geoms[0], thick_set, true );
    SetSetFlag( geoms[2], thick_set, true );
    SetSetFlag( geoms[3], thin_set, true );
    SetSetFlag( geoms[4], thin_set, true );
    SetSetFlag( geoms[5], thin_set, true );
    Update();
    WriteVSPFile( base + ".vsp3", SET_ALL );

    string comp = "VSPAEROComputeGeometry";
    SetAnalysisInputDefaults( comp );
    SetIntAnalysisInput( comp, "GeomSet", {{ thick_set }}, 0 );
    SetIntAnalysisInput( comp, "ThinGeomSet", {{ thin_set }}, 0 );
    SetIntAnalysisInput( comp, "Symmetry", {{ 0 }}, 0 );
    ExecAnalysis( comp );

    string sweep = "VSPAEROSweep";
    SetAnalysisInputDefaults( sweep );
    SetIntAnalysisInput( sweep, "GeomSet", {{ thick_set }}, 0 );
    SetIntAnalysisInput( sweep, "ThinGeomSet", {{ thin_set }}, 0 );
    SetIntAnalysisInput( sweep, "Symmetry", {{ 0 }}, 0 );
    SetIntAnalysisInput( sweep, "RefFlag", {{ 0 }}, 0 );
    SetDoubleAnalysisInput( sweep, "Sref", {{ 409.631374 }}, 0 );
    SetDoubleAnalysisInput( sweep, "bref", {{ 37.270341 }}, 0 );
    SetDoubleAnalysisInput( sweep, "cref", {{ 12.3614 }}, 0 );
    SetDoubleAnalysisInput( sweep, "Xcg", {{ 20.46778 }}, 0 );
    SetDoubleAnalysisInput( sweep, "Ycg", {{ 0.0 }}, 0 );
    SetDoubleAnalysisInput( sweep, "Zcg", {{ 0.0 }}, 0 );
    SetDoubleAnalysisInput( sweep, "AlphaStart", {{ -2.0 }}, 0 );
    SetDoubleAnalysisInput( sweep, "AlphaEnd", {{ 4.0 }}, 0 );
    SetIntAnalysisInput( sweep, "AlphaNpts", {{ 7 }}, 0 );
    SetDoubleAnalysisInput( sweep, "BetaStart", {{ 0.0 }}, 0 );
    SetDoubleAnalysisInput( sweep, "BetaEnd", {{ 0.0 }}, 0 );
    SetIntAnalysisInput( sweep, "BetaNpts", {{ 1 }}, 0 );
    SetDoubleAnalysisInput( sweep, "MachStart", {{ 1.60 }}, 0 );
    SetDoubleAnalysisInput( sweep, "MachEnd", {{ 1.70 }}, 0 );
    SetIntAnalysisInput( sweep, "MachNpts", {{ 3 }}, 0 );
    SetIntAnalysisInput( sweep, "WakeNumIter", {{ 1 }}, 0 );
    SetIntAnalysisInput( sweep, "NCPU", {{ 4 }}, 0 );
    SetStringAnalysisInput( sweep, "RedirectFile", {{ base + "_solver.log" }}, 0 );
    ExecAnalysis( sweep );
    Print( "REPAIRMACH_EXTENSION_COMPLETE=1" );
}}
'''
    (RUN_DIR / "extension.vspscript").write_text(script, encoding="utf-8")
    print(RUN_DIR / "extension.vspscript")


if __name__ == "__main__":
    main()
