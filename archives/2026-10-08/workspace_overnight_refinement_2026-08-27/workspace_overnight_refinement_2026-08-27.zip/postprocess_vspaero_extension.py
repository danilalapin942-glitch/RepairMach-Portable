#!/usr/bin/env python3
"""Fit CD = CD0 + A*CL^2 for the dedicated VSPAERO extension."""

from __future__ import annotations

import csv
import sys
from collections import defaultdict
from pathlib import Path


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
sys.path.insert(0, str(PROJECT / "RepairMach_Portable_Candidate" / "app"))

from aero_hybrid import parse_vspaero_polar  # noqa: E402


def linear_fit(xs: list[float], ys: list[float]) -> tuple[float, float, float]:
    mean_x = sum(xs) / len(xs)
    mean_y = sum(ys) / len(ys)
    ss_x = sum((value - mean_x) ** 2 for value in xs)
    slope = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys)) / ss_x
    intercept = mean_y - slope * mean_x
    ss_tot = sum((value - mean_y) ** 2 for value in ys)
    ss_res = sum((y - (intercept + slope * x)) ** 2 for x, y in zip(xs, ys))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 1.0
    return slope, intercept, r2


def main() -> None:
    polar = HERE / "vspaero_extension" / "RepairMach91_M160_M170.polar"
    points = parse_vspaero_polar(polar)
    grouped: dict[float, list[dict[str, float]]] = defaultdict(list)
    for point in points:
        if 1.59 <= point["Mach"] <= 1.71 and abs(point["CLtot"]) < 5.0 and abs(point["CDtot"]) < 1.0:
            grouped[round(point["Mach"], 2)].append(point)
    rows = []
    for mach in (1.60, 1.65, 1.70):
        group = grouped.get(mach, [])
        if len(group) < 5:
            raise RuntimeError(f"Not enough valid VSPAERO points at M={mach:.2f}: {len(group)}")
        induced_a, cd0, r2 = linear_fit(
            [point["CLtot"] ** 2 for point in group],
            [point["CDtot"] for point in group],
        )
        cla, cl0, cl_r2 = linear_fit(
            [point["AoA"] for point in group],
            [point["CLtot"] for point in group],
        )
        rows.append({
            "mach": mach,
            "point_count": len(group),
            "zero_lift_CD": cd0,
            "induced_A": induced_a,
            "cd_fit_r2": r2,
            "cla_per_deg": cla,
            "cl_at_alpha0": cl0,
            "cl_fit_r2": cl_r2,
            "polar": str(polar),
        })
    output = HERE / "vspaero_extension.csv"
    with output.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(output)


if __name__ == "__main__":
    main()
