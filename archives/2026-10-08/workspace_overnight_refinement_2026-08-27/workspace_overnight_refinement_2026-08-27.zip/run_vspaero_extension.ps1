$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot
$runDir = Join-Path $here 'vspaero_extension'
$complete = Join-Path $runDir 'COMPLETE.txt'
$output = Join-Path $here 'vspaero_extension.csv'
$python = Join-Path (Split-Path $here -Parent) 'RepairMach_Portable_Candidate\runtime\python\python.exe'
$vspscript = 'C:\OpenVSP-3.51.0-win64-Python3.13\OpenVSP-3.51.0-win64\vspscript.exe'
$polar = Join-Path $runDir 'RepairMach91_M160_M170.polar'
$log = Join-Path $runDir 'vspscript.log'

if ((Test-Path -LiteralPath $complete) -and (Test-Path -LiteralPath $output)) { return }
if (-not (Test-Path -LiteralPath $vspscript)) { throw "vspscript not found: $vspscript" }

$solverComplete = (Test-Path -LiteralPath $polar) -and
    ((Get-Item -LiteralPath $polar).Length -gt 0) -and
    (Test-Path -LiteralPath $log) -and
    ((Get-Content -Raw -LiteralPath $log) -match 'REPAIRMACH_EXTENSION_COMPLETE=1')

if (-not $solverComplete) {
    & $python (Join-Path $here 'generate_vspaero_extension.py')
    if ($LASTEXITCODE -ne 0) { throw "VSPAERO extension generation failed: $LASTEXITCODE" }

    $script = Join-Path $runDir 'extension.vspscript'
    Push-Location $runDir
    try {
        $vspOutput = & $vspscript -script $script 2>&1
        $code = $LASTEXITCODE
    } finally {
        Pop-Location
    }
    $vspOutput | ForEach-Object { $_.ToString() } | Set-Content -LiteralPath $log -Encoding utf8
    $solverComplete = (Test-Path -LiteralPath $polar) -and
        ((Get-Item -LiteralPath $polar).Length -gt 0) -and
        (($vspOutput -join "`n") -match 'REPAIRMACH_EXTENSION_COMPLETE=1')
    if (-not $solverComplete) {
        throw "VSPAERO extension failed with exit code $code"
    }
}
& $python (Join-Path $here 'postprocess_vspaero_extension.py')
if ($LASTEXITCODE -ne 0) { throw "VSPAERO extension postprocess failed: $LASTEXITCODE" }
"Completed: $((Get-Date).ToString('o'))" | Set-Content -LiteralPath $complete -Encoding utf8
