#!/usr/bin/env python3
"""Generate the 7–8 hour MachLine refinement matrix."""

from __future__ import annotations

import csv
import json
import math
import sys
from pathlib import Path


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
sys.path.insert(0, str(PROJECT / "RepairMach_Portable_Candidate" / "app"))
sys.path.insert(0, str(PROJECT / "overnight_sweep"))

from tri_mesh import read_tri  # noqa: E402
from hybrid_preflight import supersonic_inclination_summary  # noqa: E402


INPUTS = HERE / "inputs"
REPORTS = HERE / "reports"
MESHES = {
    "7k": Path(r"C:\RepairMach\02_working_meshes\final\MIG_full_7k.tri"),
    "13k": Path(r"C:\RepairMach\02_working_meshes\final\MIG_full_13k_repaired.tri"),
    "21k": Path(r"C:\RepairMach\02_working_meshes\final\MIG_full_21k_repaired.tri"),
}
MACHS = tuple(round(1.10 + 0.05 * index, 2) for index in range(10))
ALPHAS = {
    "7k": (-4.0, -2.0, 0.0, 2.0, 4.0),
    "13k": (-4.0, -2.0, 0.0, 2.0, 4.0),
    "21k": tuple(float(value) for value in range(-4, 5)),
}
OFFSETS = (0.00001, 0.00010)
SREF_FT2 = 409.631374


def machline_path(path: Path) -> str:
    return str(path.resolve()).replace("\\", "/").replace("C:/", "C://", 1)


def number_tag(value: float, prefix: str) -> str:
    sign = "m" if value < 0 else "p"
    return f"{prefix}{sign}{abs(value):.5f}".rstrip("0").rstrip(".").replace(".", "p")


def write_csv(path: Path, rows: list[dict], delimiter: str = ";") -> None:
    if not rows:
        return
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter=delimiter)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    INPUTS.mkdir(parents=True, exist_ok=True)
    REPORTS.mkdir(parents=True, exist_ok=True)
    runnable: list[dict] = []
    preflight: list[dict] = []
    case_number = 0

    for grid, mesh_path in MESHES.items():
        if not mesh_path.is_file():
            raise FileNotFoundError(mesh_path)
        mesh = read_tri(mesh_path)
        alpha_values = ALPHAS[grid]
        geometry_checks: dict[tuple[float, float], int] = {}
        for mach in MACHS:
            for alpha in alpha_values:
                count = supersonic_inclination_summary(mesh, mach, alpha)["count"]
                geometry_checks[(mach, alpha)] = count
                preflight.append({
                    "grid": grid,
                    "mach": f"{mach:.2f}",
                    "alpha_deg": f"{alpha:.1f}",
                    "superinclined_panels": count,
                    "status": "RUNNABLE" if count == 0 else "SKIPPED_GEOMETRY",
                })

        specifications: list[tuple[float, float, str]] = []
        for mach in MACHS:
            for alpha in alpha_values:
                for offset in OFFSETS:
                    specifications.append((mach, alpha, "isentropic"))
        if grid == "21k":
            for mach in MACHS:
                for alpha in (-2.0, 0.0, 2.0):
                    specifications.append((mach, alpha, "slender-body"))

        for spec_index, (mach, alpha, pressure_rule) in enumerate(specifications):
            offset = OFFSETS[spec_index % 2] if pressure_rule == "isentropic" else OFFSETS[0]
            if geometry_checks[(mach, alpha)] != 0:
                continue
            case_number += 1
            rule_tag = "ise" if pressure_rule == "isentropic" else "sln"
            case_id = "_".join((
                f"{case_number:03d}",
                grid,
                number_tag(mach, "M"),
                number_tag(alpha, "A"),
                number_tag(offset, "O"),
                rule_tag,
            ))
            input_path = INPUTS / f"{case_id}.json"
            report_path = REPORTS / f"{case_id}_report.json"
            angle = math.radians(alpha)
            payload = {
                "flow": {
                    "freestream_velocity": [100.0 * math.cos(angle), 0.0, 100.0 * math.sin(angle)],
                    "gamma": 1.4,
                    "freestream_mach_number": mach,
                },
                "geometry": {
                    "file": machline_path(mesh_path),
                    "spanwise_axis": "+y",
                    "wake_model": {
                        "trefftz_distance": 80.0,
                        "wake_present": False,
                        "append_wake": False,
                        "wake_shedding_angle": 150.0,
                    },
                    "reference": {"area": SREF_FT2},
                },
                "solver": {
                    "formulation": "dirichlet-morino",
                    "matrix_solver": "FQRUP",
                    "control_point_offset": offset,
                },
                "post_processing": {
                    "pressure_rules": {
                        "isentropic": True,
                        "second-order": True,
                        "slender-body": True,
                        "linear": True,
                    },
                    "pressure_for_forces": pressure_rule,
                },
                "output": {
                    "body_file": "none",
                    "wake_file": "none",
                    "control_point_file": "none",
                    "report_file": machline_path(report_path),
                },
            }
            json_text = json.dumps(payload, indent=2)
            # MachLine's bundled JSON reader misreads the compact spelling
            # ``1e-05`` as an extremely small number. Preserve the same value
            # in fixed-point notation so the solver receives exactly 1e-5.
            json_text = json_text.replace('"control_point_offset": 1e-05', '"control_point_offset": 0.00001')
            input_path.write_text(json_text + "\n", encoding="utf-8")
            runnable.append({
                "case_id": case_id,
                "input_name": input_path.name,
                "input_path": str(input_path.resolve()),
                "report_path": str(report_path.resolve()),
                "grid": grid,
                "mesh_path": str(mesh_path),
                "mach": f"{mach:.2f}",
                "alpha_deg": f"{alpha:.1f}",
                "control_point_offset": f"{offset:.5f}",
                "pressure_rule": pressure_rule,
                "solver": "FQRUP",
            })

    write_csv(HERE / "manifest.csv", runnable)
    write_csv(HERE / "preflight.csv", preflight)
    plan = {
        "generated_cases": len(runnable),
        "estimated_hours": 7.2,
        "mach_range": [min(MACHS), max(MACHS)],
        "purpose": "fixed-method drag validation; mesh and control-point-offset sensitivity",
        "excluded": "Any Mach/alpha geometry with superinclined panels",
    }
    (HERE / "plan.json").write_text(json.dumps(plan, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Generated {len(runnable)} runnable cases")


if __name__ == "__main__":
    main()
