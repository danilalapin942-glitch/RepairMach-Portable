#!/usr/bin/env python3
"""Append dense-alpha validation cases only at problematic Mach numbers."""

from __future__ import annotations

import csv
import json
import math
import sys
from pathlib import Path


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
sys.path.insert(0, str(PROJECT / "RepairMach_Portable_Candidate" / "app"))
sys.path.insert(0, str(PROJECT / "overnight_sweep"))

from tri_mesh import read_tri  # noqa: E402
from hybrid_preflight import supersonic_inclination_summary  # noqa: E402


MESHES = {
    "7k": Path(r"C:\RepairMach\02_working_meshes\final\MIG_full_7k.tri"),
    "13k": Path(r"C:\RepairMach\02_working_meshes\final\MIG_full_13k_repaired.tri"),
    "21k": Path(r"C:\RepairMach\02_working_meshes\final\MIG_full_21k_repaired.tri"),
}
TARGETS = {
    1.20: (-1.50, -1.00, -0.50, 0.50, 1.00, 1.25, 1.50),
    1.25: (-1.50, -1.00, -0.50, -0.25, 0.25, 0.50, 1.00, 1.50),
    1.50: (-1.75, -1.50, -1.25, -1.00, -0.75, -0.50, 0.50, 1.00, 1.50),
    1.55: (-1.50, -1.25, -1.00, -0.75, -0.50, -0.25, 0.25, 0.50, 0.75, 1.00, 1.50),
}
OFFSETS = {"7k": (0.00001, 0.00010), "13k": (0.00001, 0.00010), "21k": (0.00001,)}
SREF_FT2 = 409.631374


def machline_path(path: Path) -> str:
    return str(path.resolve()).replace("\\", "/").replace("C:/", "C://", 1)


def number_tag(value: float, prefix: str) -> str:
    sign = "m" if value < 0 else "p"
    return f"{prefix}{sign}{abs(value):.5f}".rstrip("0").rstrip(".").replace(".", "p")


def main() -> None:
    manifest_path = HERE / "manifest.csv"
    with manifest_path.open("r", encoding="utf-8-sig", newline="") as handle:
        existing = list(csv.DictReader(handle, delimiter=";"))
    fields = list(existing[0])
    keys = {
        (row["grid"], float(row["mach"]), float(row["alpha_deg"]), float(row["control_point_offset"]), row["pressure_rule"])
        for row in existing
    }
    added: list[dict[str, str]] = []
    preflight: list[dict[str, str | int]] = []
    serial = 1

    for grid, mesh_path in MESHES.items():
        mesh = read_tri(mesh_path)
        for mach, alphas in TARGETS.items():
            for alpha in alphas:
                count = supersonic_inclination_summary(mesh, mach, alpha)["count"]
                preflight.append({
                    "grid": grid,
                    "mach": f"{mach:.2f}",
                    "alpha_deg": f"{alpha:.2f}",
                    "superinclined_panels": count,
                    "status": "RUNNABLE" if count == 0 else "SKIPPED_GEOMETRY",
                })
                if count != 0:
                    continue
                for offset in OFFSETS[grid]:
                    key = (grid, mach, alpha, offset, "isentropic")
                    if key in keys:
                        continue
                    case_id = "_".join((
                        f"R{serial:03d}", grid, number_tag(mach, "M"), number_tag(alpha, "A"),
                        number_tag(offset, "O"), "ise",
                    ))
                    serial += 1
                    input_path = HERE / "inputs" / f"{case_id}.json"
                    report_path = HERE / "reports" / f"{case_id}_report.json"
                    angle = math.radians(alpha)
                    payload = {
                        "flow": {
                            "freestream_velocity": [100.0 * math.cos(angle), 0.0, 100.0 * math.sin(angle)],
                            "gamma": 1.4,
                            "freestream_mach_number": mach,
                        },
                        "geometry": {
                            "file": machline_path(mesh_path),
                            "spanwise_axis": "+y",
                            "wake_model": {
                                "trefftz_distance": 80.0,
                                "wake_present": False,
                                "append_wake": False,
                                "wake_shedding_angle": 150.0,
                            },
                            "reference": {"area": SREF_FT2},
                        },
                        "solver": {
                            "formulation": "dirichlet-morino",
                            "matrix_solver": "FQRUP",
                            "control_point_offset": offset,
                        },
                        "post_processing": {
                            "pressure_rules": {
                                "isentropic": True,
                                "second-order": True,
                                "slender-body": True,
                                "linear": True,
                            },
                            "pressure_for_forces": "isentropic",
                        },
                        "output": {
                            "body_file": "none",
                            "wake_file": "none",
                            "control_point_file": "none",
                            "report_file": machline_path(report_path),
                        },
                    }
                    text = json.dumps(payload, indent=2).replace(
                        '"control_point_offset": 1e-05', '"control_point_offset": 0.00001'
                    )
                    input_path.write_text(text + "\n", encoding="utf-8")
                    row = {
                        "case_id": case_id,
                        "input_name": input_path.name,
                        "input_path": str(input_path.resolve()),
                        "report_path": str(report_path.resolve()),
                        "grid": grid,
                        "mesh_path": str(mesh_path),
                        "mach": f"{mach:.2f}",
                        "alpha_deg": f"{alpha:.2f}",
                        "control_point_offset": f"{offset:.5f}",
                        "pressure_rule": "isentropic",
                        "solver": "FQRUP",
                    }
                    added.append(row)
                    keys.add(key)

    if added:
        with manifest_path.open("a", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields, delimiter=";")
            writer.writerows(added)
    with (HERE / "targeted_preflight.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(preflight[0]))
        writer.writeheader()
        writer.writerows(preflight)
    print(f"Appended {len(added)} targeted cases; manifest now has {len(existing) + len(added)} cases")


if __name__ == "__main__":
    main()
