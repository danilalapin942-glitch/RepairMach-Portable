param([int]$MaxCases = 0)

$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot
$manifestPath = Join-Path $here 'manifest.csv'
$inputRoot = Join-Path $here 'inputs'
$summaryPath = Join-Path $here 'run_summary.csv'
$statusPath = Join-Path $here 'status.json'
$logPath = Join-Path $here 'machline.log'
$completePath = Join-Path $here 'COMPLETE.txt'
$exe = Join-Path (Split-Path $here -Parent) 'RepairMach_Portable_Candidate\engines\MachLine\machline.exe'
$python = Join-Path (Split-Path $here -Parent) 'RepairMach_Portable_Candidate\runtime\python\python.exe'
$node = 'C:\Users\admin\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
$marker = 'C:\Users\admin\.cache\codex-runtimes\codex-primary-runtime\plugins\openai-primary-runtime\plugins\spreadsheets\skills\spreadsheets\container_tools\mark_artifact_operation_started.mjs'
$runStarted = Get-Date

$env:OMP_NUM_THREADS = '4'
if (-not (Test-Path -LiteralPath $manifestPath)) { throw "Manifest not found: $manifestPath" }
if (-not (Test-Path -LiteralPath $exe)) { throw "MachLine not found: $exe" }
Remove-Item -LiteralPath $completePath -Force -ErrorAction SilentlyContinue

$cases = @(Import-Csv -LiteralPath $manifestPath -Delimiter ';')
$completed = @{}
if (Test-Path -LiteralPath $summaryPath) {
    foreach ($row in (Import-Csv -LiteralPath $summaryPath -Delimiter ';')) {
        if ($row.status -eq 'OK') { $completed[$row.case_id] = $true }
    }
} else {
    'case_id;grid;mach;alpha_deg;control_point_offset;pressure_rule;solver;status;attempt;exit_code;runtime_s;Cx;Cy;Cz;CD_stream;CN_stream;residual_norm;report_path' |
        Set-Content -LiteralPath $summaryPath -Encoding utf8
}

function Write-RunStatus([string]$State, [string]$CurrentCase, [double]$LastRuntime = 0.0) {
    $rows = @(Import-Csv -LiteralPath $summaryPath -Delimiter ';')
    $doneIds = @($rows | Where-Object status -eq 'OK' | Select-Object -ExpandProperty case_id -Unique)
    $attemptedIds = @($rows | Select-Object -ExpandProperty case_id -Unique)
    $failures = @($attemptedIds | Where-Object { $_ -notin $doneIds }).Count
    $runtimeRows = @($rows | Where-Object { $_.status -eq 'OK' -and $_.runtime_s -ne '' })
    $meanRuntime = if ($runtimeRows.Count) { [double](($runtimeRows | Measure-Object runtime_s -Average).Average) } else { 0.0 }
    $remaining = [Math]::Max(0, $cases.Count - $doneIds.Count)
    [ordered]@{
        state = $State
        current_case = $CurrentCase
        successful = $doneIds.Count
        failures = $failures
        total = $cases.Count
        completed_percent = [Math]::Round(100.0 * $doneIds.Count / $cases.Count, 1)
        last_case_runtime_s = [Math]::Round($LastRuntime, 3)
        mean_runtime_s = [Math]::Round($meanRuntime, 3)
        eta_hours = [Math]::Round($meanRuntime * $remaining / 3600.0, 2)
        started = $runStarted.ToString('o')
        updated = (Get-Date).ToString('o')
    } | ConvertTo-Json | Set-Content -LiteralPath $statusPath -Encoding utf8
}

Write-RunStatus 'running' '' 0.0

function Invoke-MachLine([string]$InputPath) {
    $startInfo = [System.Diagnostics.ProcessStartInfo]::new()
    $startInfo.FileName = $exe
    $startInfo.WorkingDirectory = $inputRoot
    $startInfo.UseShellExecute = $false
    $startInfo.CreateNoWindow = $true
    $startInfo.RedirectStandardInput = $true
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true
    $process = [System.Diagnostics.Process]::new()
    $process.StartInfo = $startInfo
    if (-not $process.Start()) { throw "Could not start MachLine" }
    $stdoutTask = $process.StandardOutput.ReadToEndAsync()
    $stderrTask = $process.StandardError.ReadToEndAsync()
    $process.StandardInput.WriteLine($InputPath)
    $process.StandardInput.Close()
    $process.WaitForExit()
    $stdout = $stdoutTask.GetAwaiter().GetResult()
    $stderr = $stderrTask.GetAwaiter().GetResult()
    [pscustomobject]@{
        ExitCode = $process.ExitCode
        Output = @($stdout, $stderr) | Where-Object { $_ -ne '' }
    }
}

$executed = 0
foreach ($case in $cases) {
    if ($completed.ContainsKey($case.case_id)) { continue }
    if ($MaxCases -gt 0 -and $executed -ge $MaxCases) { break }
    $executed++
    $finalStatus = 'FAILED'
    $lastRuntime = 0.0
    for ($attempt = 1; $attempt -le 2; $attempt++) {
        Remove-Item -LiteralPath $case.report_path -Force -ErrorAction SilentlyContinue
        # MachLine's interactive filename buffer is short, so use the relative
        # name from the inputs working directory rather than the absolute path.
        $runResult = Invoke-MachLine $case.input_name
        $caseOutput = $runResult.Output
        $exitCode = $runResult.ExitCode
        $caseOutput | ForEach-Object { $_.ToString() } | Add-Content -LiteralPath $logPath -Encoding utf8

        $status = 'FAILED'
        $runtime = $cx = $cy = $cz = $cd = $cn = $residual = ''
        if (Test-Path -LiteralPath $case.report_path) {
            try {
                $report = Get-Content -Raw -LiteralPath $case.report_path | ConvertFrom-Json
                $status = if ([int]$report.solver_results.solver_status_code -eq 0) { 'OK' } else { 'SOLVER_FAILED' }
                $runtime = [double]$report.total_runtime
                $cx = [double]$report.total_forces.Cx
                $cy = [double]$report.total_forces.Cy
                $cz = [double]$report.total_forces.Cz
                $angle = [Math]::PI * [double]$case.alpha_deg / 180.0
                $cd = $cx * [Math]::Cos($angle) + $cz * [Math]::Sin($angle)
                $cn = $cz * [Math]::Cos($angle) - $cx * [Math]::Sin($angle)
                $residual = [double]$report.solver_results.residual.norm
            } catch {
                $status = 'REPORT_ERROR'
            }
        }
        $values = @(
            $case.case_id, $case.grid, $case.mach, $case.alpha_deg, $case.control_point_offset,
            $case.pressure_rule, $case.solver, $status, $attempt, $exitCode, $runtime, $cx, $cy,
            $cz, $cd, $cn, $residual, $case.report_path
        ) | ForEach-Object { ([string]$_).Replace(';', ',') }
        ($values -join ';') | Add-Content -LiteralPath $summaryPath -Encoding utf8
        $lastRuntime = if ($runtime -eq '') { 0.0 } else { [double]$runtime }
        $finalStatus = $status
        Write-RunStatus 'running' $case.case_id $lastRuntime
        if ($status -eq 'OK') { break }
    }
}

if ($MaxCases -eq 0) {
    & (Join-Path $here 'run_vspaero_extension.ps1')
    if (-not (Test-Path -LiteralPath (Join-Path $here 'vspaero_extension.csv'))) {
        Write-RunStatus 'failed_vspaero_extension' '' 0.0
        throw "VSPAERO extension did not produce vspaero_extension.csv"
    }
    $analysisOutput = & $python (Join-Path $here 'analyze_results.py') 2>&1
    $analysisCode = $LASTEXITCODE
    $analysisOutput | ForEach-Object { $_.ToString() } |
        Add-Content -LiteralPath (Join-Path $here 'analysis.log') -Encoding utf8
    if ($analysisCode -ne 0) {
        Write-RunStatus 'failed_analysis' '' 0.0
        throw "Analysis failed with exit code $analysisCode"
    }

    $existingWorkbookPath = Join-Path (Split-Path $here -Parent) 'outputs\01a0354f-59ac-7e63-af78-2b654a52d736\RepairMach_overnight_refinement.xlsx'
    if (-not (Test-Path -LiteralPath $existingWorkbookPath)) {
        $markerOutput = & $node $marker --operation-kind create --expected-output-count 1 --output-format xlsx 2>&1
        $markerCode = $LASTEXITCODE
        $markerOutput | ForEach-Object { $_.ToString() } |
            Add-Content -LiteralPath (Join-Path $here 'workbook.log') -Encoding utf8
        if ($markerCode -ne 0) {
            Write-RunStatus 'failed_workbook_marker' '' 0.0
            throw "Workbook operation marker failed with exit code $markerCode"
        }
    } else {
        'Workbook operation marker already completed earlier in this artifact workflow; not repeated.' |
            Add-Content -LiteralPath (Join-Path $here 'workbook.log') -Encoding utf8
    }

    $workbookOutput = & $node (Join-Path $here 'build_workbook.mjs') 2>&1
    $workbookCode = $LASTEXITCODE
    $workbookOutput | ForEach-Object { $_.ToString() } |
        Add-Content -LiteralPath (Join-Path $here 'workbook.log') -Encoding utf8
    if ($workbookCode -ne 0) {
        Write-RunStatus 'failed_workbook' '' 0.0
        throw "Workbook build failed with exit code $workbookCode"
    }

    # The delivered workbook must be autonomous: no external-link parts and
    # no bracketed workbook references in worksheet formulas.
    $workbookPath = Join-Path (Split-Path $here -Parent) 'outputs\01a0354f-59ac-7e63-af78-2b654a52d736\RepairMach_overnight_refinement.xlsx'
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $archive = [System.IO.Compression.ZipFile]::OpenRead($workbookPath)
    try {
        $externalParts = @($archive.Entries | Where-Object { $_.FullName -like 'xl/externalLinks/*' })
        $externalFormulaEntries = @()
        foreach ($entry in @($archive.Entries | Where-Object { $_.FullName -like 'xl/worksheets/*.xml' })) {
            $reader = New-Object System.IO.StreamReader($entry.Open())
            try { $xmlText = $reader.ReadToEnd() } finally { $reader.Dispose() }
            if ($xmlText -match '<f[^>]*>[^<]*\[[^<]*</f>') { $externalFormulaEntries += $entry.FullName }
        }
        if ($externalParts.Count -gt 0 -or $externalFormulaEntries.Count -gt 0) {
            Write-RunStatus 'failed_external_link_check' '' 0.0
            throw "Workbook contains external links"
        }
    } finally {
        $archive.Dispose()
    }
    'External-link check: OK; charts and formulas use workbook-internal cells only.' |
        Add-Content -LiteralPath (Join-Path $here 'workbook.log') -Encoding utf8
    "Completed: $((Get-Date).ToString('o'))" | Set-Content -LiteralPath $completePath -Encoding utf8
    Write-RunStatus 'complete' '' 0.0
} else {
    Write-RunStatus 'paused' '' 0.0
}
