import fs from 'node:fs';
import path from 'node:path';
import { Workbook, SpreadsheetFile } from '@oai/artifact-tool';

const here = path.dirname(new URL(import.meta.url).pathname.replace(/^\/(.:)/, '$1'));
const root = path.dirname(here);
const outputDir = path.join(root, 'outputs', '01a0354f-59ac-7e63-af78-2b654a52d736');
const previewDir = path.join(here, 'previews');
const outputPath = path.join(outputDir, 'RepairMach_overnight_refinement.xlsx');
fs.mkdirSync(outputDir, { recursive: true });
fs.mkdirSync(previewDir, { recursive: true });

function parseCsv(text) {
  const rows = [];
  let row = [], cell = '', quoted = false;
  for (let index = 0; index < text.length; index++) {
    const ch = text[index];
    if (quoted) {
      if (ch === '"' && text[index + 1] === '"') { cell += '"'; index++; }
      else if (ch === '"') quoted = false;
      else cell += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === ',') { row.push(cell); cell = ''; }
    else if (ch === '\n') { row.push(cell.replace(/\r$/, '')); rows.push(row); row = []; cell = ''; }
    else cell += ch;
  }
  if (cell.length || row.length) { row.push(cell.replace(/\r$/, '')); rows.push(row); }
  const headers = rows.shift().map(value => value.replace(/^\uFEFF/, ''));
  return rows.filter(values => values.some(value => value !== '')).map(values =>
    Object.fromEntries(headers.map((header, index) => [header, values[index] ?? ''])));
}

const readCsv = name => parseCsv(fs.readFileSync(path.join(here, name), 'utf8'));
const number = value => value === '' || value == null ? null : Number(value);
const best = readCsv('best_curve.csv').map(row => ({
  ...row,
  mach: number(row.mach),
  book_Cx0: number(row.book_Cx0),
  calculated_Cx0: number(row.calculated_Cx0),
  error_pct: number(row.error_pct),
  alpha_zero_lift_deg: number(row.alpha_zero_lift_deg),
  H0_pressure: number(row.H0_pressure),
  method_branch: row.method_branch,
}));
const scores = readCsv('configuration_scores.csv').map(row => ({
  ...row,
  control_point_offset: number(row.control_point_offset),
  mach_points: number(row.mach_points),
  fallback_points: number(row.fallback_points),
  mean_abs_error_pct: number(row.mean_abs_error_pct),
  max_abs_error_pct: number(row.max_abs_error_pct),
  bias_pct: number(row.bias_pct),
}));
const convergence = readCsv('zero_lift_results.csv').map(row => ({
  ...row,
  mach: number(row.mach),
  control_point_offset: number(row.control_point_offset),
  point_count: number(row.point_count),
  alpha_zero_lift_deg: number(row.alpha_zero_lift_deg),
  H0_pressure: number(row.H0_pressure),
  book_Cx0: number(row.book_Cx0),
  runtime_sum_s: number(row.runtime_sum_s),
  max_residual_norm: number(row.max_residual_norm),
}));
const raw = readCsv('run_summary_clean.csv');
const config = JSON.parse(fs.readFileSync(path.join(here, 'best_config.json'), 'utf8'));
if (!best.length || !scores.length || !raw.length) throw new Error('Final result tables are empty');

const readRootCsv = (...parts) => parseCsv(fs.readFileSync(path.join(root, ...parts), 'utf8'));
const lift = readRootCsv('overnight_sweep', 'final_balanced_polars.csv').map(row => ({
  mach: number(row.mach), alpha: number(row.alpha_deg), rawCy: number(row.raw_CL),
  cy: number(row.offset_corrected_CL), bookCy: number(row.book_CL), cmy: number(row.CMy),
  source: row.source_prefix,
}));
const liftSummary = readRootCsv('overnight_sweep', 'final_balanced_summary.csv').map(row => ({
  mach: number(row.mach), slope: number(row.raw_slope_per_deg), bookSlope: number(row.book_slope_approx_per_deg),
  slopeError: number(row.slope_error_pct), maxPointError: number(row.max_corrected_point_error_pct),
  r2: number(row.R2), maxCmy: number(row.max_abs_CMy), source: row.source_prefix,
}));
const fullLift = readRootCsv('daytime_lift_2026-08-28', 'cy_full_range_points.csv').map(row => ({
  mach: number(row.mach), regime: row.regime, alpha: number(row.alpha_deg), cy: number(row.Cy_CLtot),
  cx: number(row.Cx_CDtot), cmy: number(row.CMy), method: row.method, source: row.source_polar,
}));
const fullLiftSummary = readRootCsv('daytime_lift_2026-08-28', 'cy_alpha_full_range.csv').map(row => ({
  mach: number(row.mach), regime: row.regime,
  cy0: number(row.Cy0), cy1: number(row.Cy1), cy2: number(row.Cy2), cy3: number(row.Cy3),
  cy4: number(row.Cy4), cy5: number(row.Cy5),
  d01: number(row.Cy_alpha_0_1_per_deg), d12: number(row.Cy_alpha_1_2_per_deg),
  d23: number(row.Cy_alpha_2_3_per_deg), d34: number(row.Cy_alpha_3_4_per_deg),
  d45: number(row.Cy_alpha_4_5_per_deg), linear: number(row.Cy_alpha_linear_0_5_per_deg),
  intercept: number(row.Cy_linear_intercept), r2: number(row.linear_fit_R2),
  book: number(row.book_fixed_Cy_alpha_approx), bookError: number(row.book_error_pct),
  status: row.calculation_status, bracket: number(row.max_Cy_bracket_half_span),
}));
const semiComparison = readRootCsv(
  'overnight_sweep', 'semiempirical_drag', 'full_grid', 'semiempirical_results', 'comparison_summary.csv',
);
const bookSubsonic = new Map([
  [0.3, 0.02400], [0.4, 0.02375], [0.5, 0.02350],
  [0.6, 0.02325], [0.7, 0.02300], [0.8, 0.02300],
]);
const subsonic = semiComparison
  .filter(row => number(row.alpha_deg) === 0 && row.pressure_source === 'vspaero_pressure_fit'
    && row.a_variant === 'book_slope' && number(row.mach) <= 0.8)
  .map(row => ({
    mach: number(row.mach), semiMin: number(row.semi_cd_min), semi: number(row.semi_cd_median),
    semiMax: number(row.semi_cd_max), raw: number(row.raw_CD), book: bookSubsonic.get(number(row.mach)) ?? null,
  }))
  .sort((a, b) => a.mach - b.mach);
if (lift.length !== 21 || liftSummary.length !== 3 || fullLift.length !== 120 || fullLiftSummary.length !== 20 || subsonic.length < 9) {
  throw new Error('Lift or subsonic Cx0 source tables are incomplete');
}

const colors = {
  navy: '#17365D', blue: '#2F5597', red: '#C00000', green: '#548235', orange: '#ED7D31',
  gray: '#7F7F7F', light: '#D9EAF7', pale: '#F3F6F9', white: '#FFFFFF', black: '#1F1F1F',
  good: '#E2F0D9', warn: '#FFF2CC', bad: '#FCE4D6', line: '#D9D9D9',
};
const wb = Workbook.create();

function styleTitle(range) {
  range.format = { fill: colors.navy, font: { bold: true, color: colors.white, size: 16 }, verticalAlignment: 'center' };
}
function styleHeader(range) {
  range.format = {
    fill: colors.navy, font: { bold: true, color: colors.white, size: 10 },
    horizontalAlignment: 'center', verticalAlignment: 'center', wrapText: true,
    borders: { bottom: { color: colors.white, style: 'thin' } },
  };
}
function setWidths(sheet, specs, lastRow = 600) {
  for (const [columns, width] of specs) sheet.getRange(`${columns}1:${columns}${lastRow}`).format.columnWidth = width;
}
function addChart(sheet, type, rangeAddress, position, title, palette, dashed = []) {
  const chart = sheet.charts.add(type, sheet.getRange(rangeAddress));
  chart.titleText = title;
  chart.hasLegend = true;
  chart.legend.position = 'bottom';
  chart.setPosition(position[0], position[1]);
  try {
    chart.series.items.forEach((series, index) => {
      series.line = {
        fill: palette[index % palette.length], width: dashed.includes(index) ? 1.5 : 2.25,
        style: dashed.includes(index) ? 'dashed' : 'solid',
      };
    });
  } catch {}
  return chart;
}
function axisTitles(chart, x, y, yFormat = '0.000') {
  try { chart.xAxis = { title: { text: x }, numberFormatCode: '0.00' }; } catch {}
  try { chart.yAxis = { title: { text: y }, numberFormatCode: yFormat }; } catch {}
}
function columnName(index) {
  let value = index + 1, result = '';
  while (value > 0) { const part = (value - 1) % 26; result = String.fromCharCode(65 + part) + result; value = Math.floor((value - 1) / 26); }
  return result;
}

function quoteSheet(name) { return `'${name.replaceAll("'", "''")}'`; }

const overview = wb.worksheets.add('Сводка АДХ');
overview.showGridlines = false;
overview.mergeCells('A1:P2');
overview.getRange('A1').values = [['RepairMach 9.1 — сводка лучших аэродинамических результатов']];
styleTitle(overview.getRange('A1:P2'));
overview.mergeCells('A3:P3');
overview.getRange('A3').values = [[
  'Подъёмная сила, дозвуковой Cx0 и сверхзвуковой Cx0 собраны из лучших проверенных серий. Для каждого режима сохранена собственная физически обоснованная методика.',
]];
overview.getRange('A3:P3').format = { fill: colors.light, font: { italic: true, color: colors.navy, size: 10 }, wrapText: true };

for (const [range, title, fill] of [
  ['A5:E5', 'Подъёмная сила Cy(α)', colors.green],
  ['F5:J5', 'Cx0 — дозвук', colors.blue],
  ['K5:P5', 'Cx0 — сверхзвук', colors.orange],
]) {
  overview.mergeCells(range);
  overview.getRange(range.split(':')[0]).values = [[title]];
  overview.getRange(range).format = { fill, font: { bold: true, color: colors.white, size: 12 }, horizontalAlignment: 'center' };
}
overview.getRange('A6:B8').values = [['Чисел M без транзвука'], ['Прямых / всего'], ['Лучшие опорные ≤15%']];
overview.mergeCells('C6:E6'); overview.mergeCells('C7:E7'); overview.mergeCells('C8:E8');
overview.getRange('C6').values = [[fullLiftSummary.length]];
overview.getRange('C7').values = [[`${fullLiftSummary.filter(row => row.status === 'direct VSPAERO').length} / ${fullLiftSummary.length}`]];
overview.getRange('C8').values = [[`${liftSummary.filter(row => row.slopeError <= 15).length} / ${liftSummary.length}`]];

overview.getRange('F6:G8').values = [['Диапазон сравнения'], ['Средняя |ошибка|'], ['Ошибка при M=0,8']];
overview.mergeCells('H6:J6'); overview.mergeCells('H7:J7'); overview.mergeCells('H8:J8');
overview.getRange('H6').values = [['M=0,30…0,80']];
const subsonicBenchmarked = subsonic.filter(row => row.book != null);
overview.getRange('H7').values = [[subsonicBenchmarked.reduce((sum, row) => sum + Math.abs((row.semi - row.book) / row.book), 0) / subsonicBenchmarked.length]];
overview.getRange('H8').values = [[Math.abs((subsonic.find(row => row.mach === 0.8).semi - 0.023) / 0.023)]];
overview.getRange('H7:J8').format.numberFormat = '0.0%';

overview.getRange('K6:L8').values = [['Диапазон'], ['Средняя |ошибка|'], ['Макс. |ошибка|']];
overview.mergeCells('M6:P6'); overview.mergeCells('M7:P7'); overview.mergeCells('M8:P8');
overview.getRange('M6').values = [['M=1,20…1,70']];
overview.getRange('M7').values = [[config.mean_abs_error_pct / 100]];
overview.getRange('M8').values = [[config.max_abs_error_pct / 100]];
overview.getRange('M7:P8').format.numberFormat = '0.0%';

for (const range of ['A6:B8', 'F6:G8', 'K6:L8']) {
  overview.getRange(range).format = { fill: colors.pale, font: { bold: true, color: colors.navy, size: 9 }, wrapText: true };
}
for (const range of ['C6:E8', 'H6:J8', 'M6:P8']) {
  overview.getRange(range).format = { fill: colors.white, font: { bold: true, color: colors.black, size: 12 }, horizontalAlignment: 'center', verticalAlignment: 'center' };
}

const overviewAlpha = [0, 2, 4, 6, 8, 10, 12];
overview.getRange('R1:X8').values = [[
  'α, °', 'Расчёт M=0,8', 'Книга M=0,8', 'Расчёт M=1,2', 'Книга M=1,2', 'Расчёт M=1,7', 'Книга M=1,7',
], ...overviewAlpha.map(alpha => {
  const row = [alpha];
  for (const mach of [0.8, 1.2, 1.7]) {
    const point = lift.find(item => item.mach === mach && item.alpha === alpha);
    row.push(point.cy, point.bookCy);
  }
  return row;
})];
const fullMach = [...subsonic.filter(row => row.mach >= 0.3).map(row => row.mach), 0.9, 1.0, 1.1, ...best.map(row => row.mach)];
overview.getRange(`R12:V${12 + fullMach.length}`).values = [[
  'M', 'Cx0 дозвук', 'Cx0 сверхзвук', 'Книга дозвук', 'Книга сверхзвук',
], ...fullMach.map(mach => {
  const sub = subsonic.find(row => row.mach === mach);
  const sup = best.find(row => row.mach === mach);
  return [mach, sub?.semi ?? null, sup?.calculated_Cx0 ?? null, sub?.book ?? null, sup?.book_Cx0 ?? null];
})];
const overviewCyChart = addChart(overview, 'line', 'R1:X8', ['A11', 'H27'], 'Cy(α): лучший расчёт и книжные линии', [colors.blue, colors.blue, colors.red, colors.red, colors.green, colors.green], [1, 3, 5]);
axisTitles(overviewCyChart, 'α, °', 'Cy', '0.00');
const overviewCxChart = addChart(overview, 'line', `R12:V${12 + fullMach.length}`, ['I11', 'P27'], 'Cx0(M): лучшие расчёты по областям', [colors.blue, colors.red, colors.gray, colors.black], [2, 3]);
axisTitles(overviewCxChart, 'M', 'Cx0', '0.000');
overview.mergeCells('A30:P32');
overview.getRange('A30').values = [[
  'Главный итог: Cy рассчитан для 20 чисел M (0,0…0,8 и 1,2…2,2) при α=0…5°. Три лучшие книжные опорные точки укладываются в допуск 15%; пять численно неустойчивых режимов в полном ряду заменены прозрачной интерполяцией между соседними прямыми решениями. Дозвуковой и сверхзвуковой Cx0 сохранены отдельными проверенными ветвями.',
]];
overview.getRange('A30:P32').format = { fill: colors.good, font: { bold: true, color: colors.navy, size: 10 }, wrapText: true, verticalAlignment: 'center' };
overview.getRange('A34:P37').values = [[
  'Показатель', 'Метод', null, null, 'Почему выбран', null, null, null, null, null, null, null, null, null, null, null,
], [
  'Cy(α)', 'VSPAERO, полный ряд + лучшие сбалансированные опоры', null, null, 'Полный диапазон без транзвука; численные сбои отделены от прямых решений и явно помечены.', null, null, null, null, null, null, null, null, null, null, null,
], [
  'Cx0 дозвук', 'VSPAERO pressure + полуэмпирика', null, null, 'Добавлены трение, профильное и конструктивное сопротивление, отсутствующие в чистом потенциальном расчёте.', null, null, null, null, null, null, null, null, null, null, null,
], [
  'Cx0 сверхзвук', 'MachLine + фиксированная схема P', null, null, 'Одна сетка и одна схема на всём диапазоне, без поточечной подгонки.', null, null, null, null, null, null, null, null, null, null, null,
]];
overview.mergeCells('B34:D34'); overview.mergeCells('E34:P34');
overview.mergeCells('B35:D35'); overview.mergeCells('E35:P35');
overview.mergeCells('B36:D36'); overview.mergeCells('E36:P36'); overview.mergeCells('B37:D37'); overview.mergeCells('E37:P37');
styleHeader(overview.getRange('A34:P34'));
overview.getRange('A35:A37').format = { fill: colors.light, font: { bold: true, color: colors.navy, size: 10 }, wrapText: true };
overview.getRange('B35:P37').format = { font: { size: 9 }, wrapText: true, verticalAlignment: 'center' };
setWidths(overview, [['A:A', 13], ['B:P', 11], ['Q:Q', 3], ['R:X', 12]], 80);

const dash = wb.worksheets.add('Лучший расчёт');
dash.showGridlines = false;
dash.mergeCells('A1:P2');
dash.getRange('A1').values = [['RepairMach 9.1 — лучший единый сверхзвуковой расчёт Cx0']];
styleTitle(dash.getRange('A1:P2'));
dash.mergeCells('A3:P3');
dash.getRange('A3').values = [[
  'Сравнение с книжной кривой МиГ-29. Одна сетка, один offset и одна схема поправок выбраны по всему диапазону — без подгонки отдельных точек.',
]];
dash.getRange('A3:P3').format = { fill: colors.light, font: { italic: true, color: colors.navy, size: 10 }, wrapText: true };
dash.getRange('A5:H5').values = [['Сетка', 'Offset', 'Правило давления', 'Схема', 'Точек M', 'Средняя |ошибка|', 'Макс. |ошибка|', 'Смещение']];
styleHeader(dash.getRange('A5:H5'));
dash.getRange('A6:H6').values = [[
  config.grid, config.control_point_offset, config.pressure_rule, config.scheme, config.mach_points,
  config.mean_abs_error_pct / 100, config.max_abs_error_pct / 100, config.bias_pct / 100,
]];
dash.getRange('B6').format.numberFormat = '0.00000';
dash.getRange('F6:H6').format.numberFormat = '0.0%';

const bestHeaders = ['M', 'Книга Cx0', 'Расчёт Cx0', 'Ошибка', '|Ошибка|', 'α при CN=0, °', 'Cx давления', 'Расчётная ветвь'];
dash.getRange('A9:H9').values = [bestHeaders];
styleHeader(dash.getRange('A9:H9'));
const bestLastRow = 9 + best.length;
dash.getRange(`A10:H${bestLastRow}`).values = best.map(point => [
  point.mach, point.book_Cx0, point.calculated_Cx0, null, null,
  point.alpha_zero_lift_deg, point.H0_pressure, point.method_branch,
]);
for (let index = 0; index < best.length; index++) {
  const row = index + 10;
  dash.getRange(`D${row}:E${row}`).formulas = [[`=(C${row}-B${row})/B${row}`, `=ABS(D${row})`]];
  const absolute = Math.abs(best[index].error_pct) / 100;
  dash.getRange(`E${row}`).format.fill = absolute <= 0.05 ? colors.good : absolute <= 0.10 ? colors.warn : colors.bad;
}
dash.getRange(`A10:A${bestLastRow}`).format.numberFormat = '0.00';
dash.getRange(`B10:C${bestLastRow}`).format.numberFormat = '0.00000';
dash.getRange(`D10:E${bestLastRow}`).format.numberFormat = '0.0%';
dash.getRange(`F10:F${bestLastRow}`).format.numberFormat = '0.000';
dash.getRange(`G10:G${bestLastRow}`).format.numberFormat = '0.00000';
// Chart helper tables are driven only by cells in this workbook.  The final
// XLSX therefore remains autonomous after the CSV/JSON build inputs disappear.
dash.getRange('J9:L9').values = [['M', 'Книга Cx0', 'Расчёт Cx0']];
dash.getRange('J10:L10').formulas = [['=A10', '=B10', '=C10']];
dash.getRange(`J10:L${bestLastRow}`).fillDown();
dash.getRange('N9:O9').values = [['M', '|Ошибка|, %']];
dash.getRange('N10:O10').formulas = [['=A10', '=E10*100']];
dash.getRange(`N10:O${bestLastRow}`).fillDown();
const comparisonChart = addChart(dash, 'line', `J9:L${bestLastRow}`, ['A24', 'H41'], 'Cx0 в зависимости от числа M', [colors.black, colors.red], [0]);
axisTitles(comparisonChart, 'M', 'Cx0', '0.000');
const errorChart = addChart(dash, 'line', `N9:O${bestLastRow}`, ['I24', 'P41'], 'Погрешность лучшего расчёта по точкам', [colors.blue]);
axisTitles(errorChart, 'M', '|Ошибка|, %', '0.0');
dash.mergeCells('A44:P46');
dash.getRange('A44').values = [[
  'Граница применимости: MachLine используется до последней геометрически допустимой точки. M=1,60…1,70 закрыты фиксированным плавным переходом к VSPAERO при CL=0; книжные значения в формулу перехода не подставляются.',
]];
dash.getRange('A44:P46').format = { fill: colors.warn, font: { color: colors.black, size: 10 }, wrapText: true, verticalAlignment: 'center' };
setWidths(dash, [['A:A', 10], ['B:G', 14], ['H:H', 23], ['I:I', 3], ['J:L', 12], ['M:M', 3], ['N:O', 13], ['P:P', 3]]);

const liftSheet = wb.worksheets.add('Подъёмная сила');
liftSheet.showGridlines = false;
liftSheet.mergeCells('A1:P2');
liftSheet.getRange('A1').values = [['Лучший расчёт коэффициента подъёмной силы Cy(α)']];
styleTitle(liftSheet.getRange('A1:P2'));
liftSheet.mergeCells('A3:P3');
liftSheet.getRange('A3').values = [[
  'Смешанная модель VSPAERO: Fuselage/Gondola — толстые тела, Wing/GO/VO — несущие поверхности; поточечная балансировка по CMy≈0. Книжные точки оцифрованы приближённо.',
]];
liftSheet.getRange('A3:P3').format = { fill: colors.light, font: { italic: true, color: colors.navy, size: 10 }, wrapText: true };
liftSheet.getRange('A5:G5').values = [['M', 'dCy/dα расчёт, 1/°', 'Книга, 1/°', 'Ошибка наклона', 'Макс. ошибка точек', 'R²', 'Макс. |CMy|']];
styleHeader(liftSheet.getRange('A5:G5'));
liftSheet.getRange('A6:G8').values = liftSummary.map(row => [
  row.mach, row.slope, row.bookSlope, row.slopeError / 100, row.maxPointError / 100, row.r2, row.maxCmy,
]);
liftSheet.getRange('A6:A8').format.numberFormat = '0.0';
liftSheet.getRange('B6:C8').format.numberFormat = '0.00000';
liftSheet.getRange('D6:E8').format.numberFormat = '0.0%';
liftSheet.getRange('F6:F8').format.numberFormat = '0.0000';
liftSheet.getRange('G6:G8').format.numberFormat = '0.00E+00';
for (let index = 0; index < liftSummary.length; index++) {
  const fill = liftSummary[index].slopeError <= 5 ? colors.good : liftSummary[index].slopeError <= 15 ? colors.warn : colors.bad;
  liftSheet.getRange(`D${index + 6}:E${index + 6}`).format.fill = fill;
}

const liftHeaders = ['M', 'α, °', 'Cy расчёт', 'Cy книга', 'Ошибка Cy', 'ΔCy расчёт', 'ΔCy книга', 'Ошибка ΔCy', 'CMy', 'Источник'];
liftSheet.getRange('A11:J11').values = [liftHeaders];
styleHeader(liftSheet.getRange('A11:J11'));
const liftLastRow = 11 + lift.length;
liftSheet.getRange(`A12:J${liftLastRow}`).values = lift.map(point => [
  point.mach, point.alpha, point.cy, point.bookCy, null, null, null, null, point.cmy, point.source,
]);
for (let index = 0; index < lift.length; index++) {
  const row = index + 12;
  const baseIndex = lift.findIndex(point => point.mach === lift[index].mach && point.alpha === 0);
  const baseRow = baseIndex + 12;
  liftSheet.getRange(`E${row}:H${row}`).formulas = [[
    `=IF(D${row}=0,"",(C${row}-D${row})/D${row})`,
    `=C${row}-C${baseRow}`,
    `=D${row}-D${baseRow}`,
    `=IF(B${row}=0,"",(F${row}-G${row})/G${row})`,
  ]];
  const pointError = Math.abs((lift[index].cy - lift[index].bookCy) / lift[index].bookCy);
  const base = lift[baseIndex];
  const deltaBook = lift[index].bookCy - base.bookCy;
  const deltaError = lift[index].alpha === 0 ? 0 : Math.abs(((lift[index].cy - base.cy) - deltaBook) / deltaBook);
  liftSheet.getRange(`E${row}`).format.fill = pointError <= 0.05 ? colors.good : pointError <= 0.15 ? colors.warn : colors.bad;
  if (lift[index].alpha !== 0) liftSheet.getRange(`H${row}`).format.fill = deltaError <= 0.05 ? colors.good : deltaError <= 0.15 ? colors.warn : colors.bad;
}
liftSheet.getRange(`A12:B${liftLastRow}`).format.numberFormat = '0.0';
liftSheet.getRange(`C12:D${liftLastRow}`).format.numberFormat = '0.00000';
liftSheet.getRange(`E12:E${liftLastRow}`).format.numberFormat = '0.0%';
liftSheet.getRange(`F12:G${liftLastRow}`).format.numberFormat = '0.00000';
liftSheet.getRange(`H12:H${liftLastRow}`).format.numberFormat = '0.0%';
liftSheet.getRange(`I12:I${liftLastRow}`).format.numberFormat = '0.00E+00';

const liftAlpha = [0, 2, 4, 6, 8, 10, 12];
liftSheet.getRange('L11:R18').values = [[
  'α, °', 'Расчёт M=0,8', 'Книга M=0,8', 'Расчёт M=1,2', 'Книга M=1,2', 'Расчёт M=1,7', 'Книга M=1,7',
], ...liftAlpha.map(alpha => {
  const row = [alpha];
  for (const mach of [0.8, 1.2, 1.7]) {
    const point = lift.find(item => item.mach === mach && item.alpha === alpha);
    row.push(point.cy, point.bookCy);
  }
  return row;
})];
liftSheet.getRange('T11:W18').values = [[
  'α, °', 'Ошибка M=0,8, %', 'Ошибка M=1,2, %', 'Ошибка M=1,7, %',
], ...liftAlpha.map(alpha => [alpha, ...[0.8, 1.2, 1.7].map(mach => {
  const point = lift.find(item => item.mach === mach && item.alpha === alpha);
  return 100 * (point.cy - point.bookCy) / point.bookCy;
})])];
liftSheet.mergeCells('A35:P36');
liftSheet.getRange('A35').values = [[
  'Ограничение M=1,7: точки выше локально устойчивого диапазона являются линейным продолжением надёжно сошедшегося моментно-сбалансированного наклона. Для подтверждения нелинейной части при больших α нужны Euler/RANS или продувка.',
]];
liftSheet.getRange('A35:P36').format = { fill: colors.warn, font: { color: colors.black, size: 10 }, wrapText: true, verticalAlignment: 'center' };
const liftChart = addChart(liftSheet, 'line', 'L11:R18', ['A38', 'H55'], 'Cy в зависимости от угла атаки', [colors.blue, colors.blue, colors.red, colors.red, colors.green, colors.green], [1, 3, 5]);
axisTitles(liftChart, 'α, °', 'Cy', '0.00');
const liftErrorChart = addChart(liftSheet, 'line', 'T11:W18', ['I38', 'P55'], 'Погрешность Cy по точкам', [colors.blue, colors.red, colors.green]);
axisTitles(liftErrorChart, 'α, °', 'Ошибка, %', '0.0');
setWidths(liftSheet, [['A:B', 8], ['C:D', 14], ['E:E', 12], ['F:G', 14], ['H:H', 12], ['I:I', 13], ['J:J', 25], ['K:K', 3], ['L:W', 12]], 80);
try { liftSheet.freezePanes.freezeRows(11); } catch {}

const fullLiftSheet = wb.worksheets.add('Cy полный диапазон');
fullLiftSheet.showGridlines = false;
fullLiftSheet.mergeCells('A1:AC2');
fullLiftSheet.getRange('A1').values = [['RepairMach 9.1 — коэффициент подъёмной силы во всём диапазоне без транзвука']];
styleTitle(fullLiftSheet.getRange('A1:AC2'));
fullLiftSheet.mergeCells('A3:AC3');
fullLiftSheet.getRange('A3').values = [[
  'Единая исправленная замкнутая VSP-модель: M=0,0…0,8 и 1,2…2,2; α=0…5° с шагом 1°. Cyα по запросу = Cy(1°)−Cy(0°). Оранжевые строки — интерполяция только между соседними устойчивыми прямыми расчётами, без подстановки книжных данных.',
]];
fullLiftSheet.getRange('A3:AC3').format = { fill: colors.light, font: { italic: true, color: colors.navy, size: 10 }, wrapText: true };

const fullLiftHeaders = ['M', 'Режим', 'Cy(0°)', 'Cy(1°)', 'Cy(5°)', 'Cyα=ΔCy/1°', 'Cyα лин. 0…5°', 'R²', 'Книга ≈', 'Ошибка к книге', 'Статус', 'Полудиапазон Cy'];
fullLiftSheet.getRange('A5:L5').values = [fullLiftHeaders];
styleHeader(fullLiftSheet.getRange('A5:L5'));
const fullSummaryLastRow = 5 + fullLiftSummary.length;
fullLiftSheet.getRange(`A6:L${fullSummaryLastRow}`).values = fullLiftSummary.map(row => [
  row.mach, row.regime === 'subsonic' ? 'дозвук' : 'сверхзвук', row.cy0, row.cy1, row.cy5,
  null, row.linear, row.r2, row.book, null, row.status, row.bracket,
]);
for (let index = 0; index < fullLiftSummary.length; index++) {
  const row = index + 6;
  fullLiftSheet.getRange(`F${row}`).formulas = [[`=D${row}-C${row}`]];
  fullLiftSheet.getRange(`J${row}`).formulas = [[`=IF(I${row}="","",(F${row}-I${row})/I${row})`]];
  if (fullLiftSummary[index].status !== 'direct VSPAERO') {
    fullLiftSheet.getRange(`A${row}:L${row}`).format.fill = colors.warn;
  } else if (fullLiftSummary[index].book != null) {
    const absolute = Math.abs((fullLiftSummary[index].d01 - fullLiftSummary[index].book) / fullLiftSummary[index].book);
    fullLiftSheet.getRange(`J${row}`).format.fill = absolute <= 0.05 ? colors.good : absolute <= 0.15 ? colors.warn : colors.bad;
  }
}
fullLiftSheet.getRange(`A6:A${fullSummaryLastRow}`).format.numberFormat = '0.0';
fullLiftSheet.getRange(`C6:G${fullSummaryLastRow}`).format.numberFormat = '0.00000';
fullLiftSheet.getRange(`H6:H${fullSummaryLastRow}`).format.numberFormat = '0.000000';
fullLiftSheet.getRange(`I6:I${fullSummaryLastRow}`).format.numberFormat = '0.00000';
fullLiftSheet.getRange(`J6:J${fullSummaryLastRow}`).format.numberFormat = '0.0%';
fullLiftSheet.getRange(`L6:L${fullSummaryLastRow}`).format.numberFormat = '0.00000';

fullLiftSheet.getRange(`N5:Q${fullSummaryLastRow}`).values = [[
  'M', 'Cyα=ΔCy/1°', 'Cyα лин. 0…5°', 'Книга ≈',
], ...fullLiftSummary.map((row, index) => {
  const sourceRow = index + 6;
  return [`=A${sourceRow}`, `=F${sourceRow}`, `=G${sourceRow}`, `=I${sourceRow}`];
})];
fullLiftSheet.getRange(`N6:Q${fullSummaryLastRow}`).formulas = fullLiftSummary.map((row, index) => {
  const sourceRow = index + 6;
  return [`=A${sourceRow}`, `=F${sourceRow}`, `=G${sourceRow}`, `=I${sourceRow}`];
});
fullLiftSheet.getRange('N5:Q5').values = [['M', 'Cyα=ΔCy/1°', 'Cyα лин. 0…5°', 'Книга ≈']];
fullLiftSheet.getRange(`T5:Z${fullSummaryLastRow}`).values = [[
  'M', 'Cy α=0°', 'Cy α=1°', 'Cy α=2°', 'Cy α=3°', 'Cy α=4°', 'Cy α=5°',
], ...fullLiftSummary.map(row => [row.mach, row.cy0, row.cy1, row.cy2, row.cy3, row.cy4, row.cy5])];

const fullCyAlphaChart = addChart(fullLiftSheet, 'line', `N5:P${fullSummaryLastRow}`, ['N29', 'U47'], 'Cyα в зависимости от числа M', [colors.red, colors.blue]);
axisTitles(fullCyAlphaChart, 'M', 'Cyα, 1/°', '0.000');
const fullCyMachChart = addChart(fullLiftSheet, 'line', `T5:Z${fullSummaryLastRow}`, ['V29', 'AC47'], 'Cy(M) при α=0…5°', [colors.gray, colors.blue, '#5B9BD5', colors.green, colors.orange, colors.red]);
axisTitles(fullCyMachChart, 'M', 'Cy', '0.00');

fullLiftSheet.getRange('A29:J29').values = [['M', 'Режим', 'α, °', 'Cy', 'Cx', 'CMy', 'ΔCy за 1°', 'Статус', 'Метод', 'Неопределённость Cy']];
styleHeader(fullLiftSheet.getRange('A29:J29'));
const fullPointsLastRow = 29 + fullLift.length;
fullLiftSheet.getRange(`A30:J${fullPointsLastRow}`).values = fullLift.map(point => {
  const summary = fullLiftSummary.find(row => row.mach === point.mach);
  return [point.mach, point.regime === 'subsonic' ? 'дозвук' : 'сверхзвук', point.alpha, point.cy, point.cx, point.cmy,
    null, summary.status, point.method, summary.bracket];
});
for (let index = 0; index < fullLift.length; index++) {
  const row = index + 30;
  if (fullLift[index].alpha !== 0) fullLiftSheet.getRange(`G${row}`).formulas = [[`=D${row}-D${row - 1}`]];
  const summary = fullLiftSummary.find(item => item.mach === fullLift[index].mach);
  if (summary.status !== 'direct VSPAERO') fullLiftSheet.getRange(`A${row}:J${row}`).format.fill = colors.warn;
}
fullLiftSheet.getRange(`A30:A${fullPointsLastRow}`).format.numberFormat = '0.0';
fullLiftSheet.getRange(`C30:C${fullPointsLastRow}`).format.numberFormat = '0.0';
fullLiftSheet.getRange(`D30:G${fullPointsLastRow}`).format.numberFormat = '0.00000';
fullLiftSheet.getRange(`J30:J${fullPointsLastRow}`).format.numberFormat = '0.00000';
fullLiftSheet.mergeCells('N50:AC53');
fullLiftSheet.getRange('N50').values = [[
  'Контроль качества: прямой одиночный повтор M=1,40 (NCPU=1, 3 итерации следа) был остановлен после расходимости GMRES >500 итераций. Поэтому M=1,40/1,50 получены по M=1,30/1,60, а M=1,90…2,10 — по M=1,80/2,20. Полудиапазон в таблице показывает разность соседних опор как консервативный индикатор неопределённости.',
]];
fullLiftSheet.getRange('N50:AC53').format = { fill: colors.warn, font: { color: colors.black, size: 10 }, wrapText: true, verticalAlignment: 'center' };
setWidths(fullLiftSheet, [['A:A', 8], ['B:B', 11], ['C:G', 14], ['H:H', 25], ['I:I', 48], ['J:J', 16], ['K:K', 26], ['L:L', 16], ['M:M', 3], ['N:Q', 14], ['R:S', 3], ['T:Z', 13], ['AA:AC', 8]], 180);
try { fullLiftSheet.freezePanes.freezeRows(5); } catch {}

const subSheet = wb.worksheets.add('Дозвук Cx0');
subSheet.showGridlines = false;
subSheet.mergeCells('A1:P2');
subSheet.getRange('A1').values = [['Лучший дозвуковой расчёт Cx0 — полуэмпирическая ветвь']];
styleTitle(subSheet.getRange('A1:P2'));
subSheet.mergeCells('A3:P3');
subSheet.getRange('A3').values = [[
  'Отдельная серия: невязкое давление VSPAERO дополнено профильным трением, сопротивлением Fuselage/Gondola, щелей и конструктивных элементов. Показана медиана диапазона неопределённости.',
]];
subSheet.getRange('A3:P3').format = { fill: colors.light, font: { italic: true, color: colors.navy, size: 10 }, wrapText: true };
subSheet.getRange('A5:H5').values = [['Диапазон книги', 'Средняя |ошибка|', 'Макс. |ошибка|', 'Cx0 при M=0,8', 'Книга при M=0,8', 'Ошибка M=0,8', 'Источник давления', 'Вариант A']];
styleHeader(subSheet.getRange('A5:H5'));
subSheet.getRange('A6:H6').values = [['M=0,30…0,80', null, null, subsonic.find(row => row.mach === 0.8)?.semi, 0.023, null, 'VSPAERO pressure fit', 'book_slope']];
subSheet.getRange('B6').formulas = [['=AVERAGE(F14:F19)']];
subSheet.getRange('C6').formulas = [['=MAX(F14:F19)']];
subSheet.getRange('F6').formulas = [['=ABS((D6-E6)/E6)']];
subSheet.getRange('B6:C6').format.numberFormat = '0.0%';
subSheet.getRange('D6:E6').format.numberFormat = '0.00000';
subSheet.getRange('F6').format.numberFormat = '0.0%';
subSheet.getRange('F6').format.fill = colors.good;

subSheet.getRange('A10:I10').values = [['M', 'Cx0 полуэмп.', 'Cx0 VSPAERO raw', 'Книга δнос=0°', 'Ошибка', '|Ошибка|', 'Минимум', 'Максимум', 'Статус']];
styleHeader(subSheet.getRange('A10:I10'));
const subLastRow = 10 + subsonic.length;
subSheet.getRange(`A11:I${subLastRow}`).values = subsonic.map(row => [
  row.mach, row.semi, row.raw, row.book, null, null, row.semiMin, row.semiMax,
  row.book == null ? 'Нет книжной точки' : null,
]);
for (let index = 0; index < subsonic.length; index++) {
  const row = index + 11;
  subSheet.getRange(`E${row}:F${row}`).formulas = [[
    `=IF(D${row}="","",(B${row}-D${row})/D${row})`,
    `=IF(E${row}="","",ABS(E${row}))`,
  ]];
  if (subsonic[index].book != null) {
    const absolute = Math.abs((subsonic[index].semi - subsonic[index].book) / subsonic[index].book);
    const status = absolute <= 0.05 ? '≤ 5%' : absolute <= 0.15 ? '5–15%' : '> 15%';
    subSheet.getRange(`I${row}`).values = [[status]];
    subSheet.getRange(`F${row}:I${row}`).format.fill = absolute <= 0.05 ? colors.good : absolute <= 0.15 ? colors.warn : colors.bad;
  }
}
subSheet.getRange(`A11:A${subLastRow}`).format.numberFormat = '0.0';
subSheet.getRange(`B11:D${subLastRow}`).format.numberFormat = '0.00000';
subSheet.getRange(`E11:F${subLastRow}`).format.numberFormat = '0.0%';
subSheet.getRange(`G11:H${subLastRow}`).format.numberFormat = '0.00000';
subSheet.getRange(`K10:N${subLastRow}`).values = [['M', 'Полуэмпирика', 'VSPAERO raw', 'Книга'], ...subsonic.map(row => [row.mach, row.semi, row.raw, row.book])];
subSheet.getRange(`P10:Q${subLastRow}`).values = [['M', '|Ошибка|, %'], ...subsonic.map(row => [
  row.mach, row.book == null ? null : 100 * Math.abs((row.semi - row.book) / row.book),
])];
const subChart = addChart(subSheet, 'line', `K10:N${subLastRow}`, ['A23', 'H40'], 'Cx0 на дозвуке: расчёт и книжная кривая', [colors.red, colors.gray, colors.black], [1, 2]);
axisTitles(subChart, 'M', 'Cx0', '0.000');
const subErrorChart = addChart(subSheet, 'line', `P10:Q${subLastRow}`, ['I23', 'P40'], 'Погрешность полуэмпирического Cx0', [colors.blue]);
axisTitles(subErrorChart, 'M', '|Ошибка|, %', '0.0');
subSheet.mergeCells('A43:P45');
subSheet.getRange('A43').values = [[
  'Интерпретация: чистый VSPAERO систематически недобирает Cx0, потому что потенциальная модель не содержит полного вязкого и конструктивного сопротивления. Полуэмпирическая ветвь заметно восстанавливает уровень книжной кривой; на M=0,8 расхождение составляет около 5%.',
]];
subSheet.getRange('A43:P45').format = { fill: colors.good, font: { color: colors.navy, bold: true, size: 10 }, wrapText: true, verticalAlignment: 'center' };
setWidths(subSheet, [['A:A', 14], ['B:F', 15], ['G:G', 23], ['H:H', 15], ['I:I', 18], ['J:J', 3], ['K:N', 13], ['O:O', 3], ['P:Q', 13]], 80);
try { subSheet.freezePanes.freezeRows(10); } catch {}

const scoreSheet = wb.worksheets.add('Конфигурации');
scoreSheet.showGridlines = false;
scoreSheet.mergeCells('A1:I1');
scoreSheet.getRange('A1').values = [['Рейтинг единых конфигураций по всему диапазону M=1,10…1,55']];
styleTitle(scoreSheet.getRange('A1:I1'));
const scoreHeaders = ['Место', 'Сетка', 'Offset', 'Правило давления', 'Схема поправок', 'Точек M', 'Fallback', 'Средняя |ошибка|', 'Макс. |ошибка|', 'Смещение'];
scoreSheet.getRange('A3:J3').values = [scoreHeaders];
styleHeader(scoreSheet.getRange('A3:J3'));
scoreSheet.getRange(`A4:J${scores.length + 3}`).values = scores.map((row, index) => [
  index + 1, row.grid, row.control_point_offset, row.pressure_rule, row.scheme,
  row.mach_points, row.fallback_points, row.mean_abs_error_pct / 100, row.max_abs_error_pct / 100, row.bias_pct / 100,
]);
scoreSheet.getRange(`C4:C${scores.length + 3}`).format.numberFormat = '0.00000';
scoreSheet.getRange(`H4:J${scores.length + 3}`).format.numberFormat = '0.0%';
scoreSheet.getRange('A4:J4').format.fill = colors.good;
setWidths(scoreSheet, [['A:A', 8], ['B:C', 11], ['D:D', 18], ['E:E', 30], ['F:G', 10], ['H:J', 16]]);
try { scoreSheet.freezePanes.freezeRows(3); } catch {}

const convSheet = wb.worksheets.add('Сеточная сходимость');
convSheet.showGridlines = false;
convSheet.mergeCells('A1:L1');
convSheet.getRange('A1').values = [['Сеточная и offset-сходимость значения Cx0']];
styleTitle(convSheet.getRange('A1:L1'));
const convHeaders = ['Сетка', 'M', 'Offset', 'Правило давления', 'Точек α', 'α(CN=0), °', 'Метод', 'Cx0 давления', 'Книга Cx0', 'Время, с', 'Макс. норма невязки'];
convSheet.getRange('A3:K3').values = [convHeaders];
styleHeader(convSheet.getRange('A3:K3'));
convSheet.getRange(`A4:K${convergence.length + 3}`).values = convergence.map(row => [
  row.grid, row.mach, row.control_point_offset, row.pressure_rule, row.point_count,
  row.alpha_zero_lift_deg, row.zero_lift_method, row.H0_pressure, row.book_Cx0,
  row.runtime_sum_s, row.max_residual_norm,
]);
convSheet.getRange(`B4:B${convergence.length + 3}`).format.numberFormat = '0.00';
convSheet.getRange(`C4:C${convergence.length + 3}`).format.numberFormat = '0.00000';
convSheet.getRange(`F4:F${convergence.length + 3}`).format.numberFormat = '0.000';
convSheet.getRange(`H4:I${convergence.length + 3}`).format.numberFormat = '0.00000';
convSheet.getRange(`J4:J${convergence.length + 3}`).format.numberFormat = '0.0';
convSheet.getRange(`K4:K${convergence.length + 3}`).format.numberFormat = '0.00E+00';
setWidths(convSheet, [['A:A', 10], ['B:C', 11], ['D:D', 18], ['E:F', 12], ['G:G', 23], ['H:K', 16]]);
try { convSheet.freezePanes.freezeRows(3); } catch {}

const rawSheet = wb.worksheets.add('Сырые данные');
rawSheet.showGridlines = false;
const rawHeaders = Object.keys(raw[0]);
const rawMatrix = [rawHeaders, ...raw.map(row => rawHeaders.map(header => {
  const value = row[header];
  const parsed = Number(value);
  return value !== '' && Number.isFinite(parsed) ? parsed : value;
}))];
const rawLastColumn = columnName(rawHeaders.length - 1);
rawSheet.getRange(`A1:${rawLastColumn}${rawMatrix.length}`).values = rawMatrix;
styleHeader(rawSheet.getRange(`A1:${rawLastColumn}1`));
for (let index = 0; index < rawHeaders.length; index++) {
  const column = columnName(index);
  rawSheet.getRange(`${column}1:${column}${rawMatrix.length}`).format.columnWidth = Math.max(11, Math.min(26, rawHeaders[index].length + 3));
}
try { rawSheet.freezePanes.freezeRows(1); } catch {}

const notes = wb.worksheets.add('Методика');
notes.showGridlines = false;
notes.mergeCells('A1:H1');
notes.getRange('A1').values = [['Методика выбора лучшего расчёта']];
styleTitle(notes.getRange('A1:H1'));
const noteRows = [
  ['Раздел', 'Содержание'],
  ['Подъёмная сила', 'Лучший Cy(α) взят из финальной сбалансированной серии VSPAERO со смешанной моделью. Для каждого α контролируется CMy≈0; M=1,70 при больших α содержит явно отмеченную линейную экстраполяцию устойчивого локального наклона.'],
  ['Cy — полный диапазон', 'Единая исправленная замкнутая VSP-модель рассчитана при M=0,0…0,8 и 1,2…2,2, α=0…5°. Cyα по запросу вычисляется формулой Cy(1°)−Cy(0°). Прямые численно неустойчивые точки не используются: они заменены интерполяцией только между соседними устойчивыми решениями и выделены в таблице.'],
  ['Дозвуковой Cx0', 'Отдельная полуэмпирическая ветвь: к давлению VSPAERO добавлены профильное сопротивление, трение и фиксированные конструктивные добавки. В книге представлены расчёт, исходный VSPAERO pressure-fit и оцифрованная книжная кривая.'],
  ['Сверхзвуковой Cx0', 'Единая конфигурация MachLine и фиксированная схема поправок выбраны сразу на всём диапазоне M=1,20…1,70 — без поточечной подгонки.'],
  ['Матрица', 'M=1,10…1,55 с шагом 0,05; сетки 7k/13k/21k; control_point_offset 1e-5 и 1e-4; FQRUP.'],
  ['Угол атаки', 'Основная матрица: 21k — −4…+4° с шагом 1°; 7k/13k — −4, −2, 0, +2, +4°. Для M=1,20; 1,25; 1,50; 1,55 добавлено локальное сгущение по α на всех трёх сетках.'],
  ['Предпроверка', 'Случаи с superinclined-панелями исключены до запуска решателя; модель самолёта не искажалась.'],
  ['Cx0', 'Ноль CN определяется линейно внутри ближайшего к α=0 интервала со сменой знака; Cx0 затем вычисляется локальной квадратичной интерполяцией по трём ближайшим точкам.'],
  ['Выбор', 'Одна комбинация сетки, offset, правила давления и полуэмпирической схемы оценивается на всём диапазоне.'],
  ['Критерий', 'Сначала минимальная средняя абсолютная ошибка, затем максимальная ошибка и число fallback-точек.'],
  ['Поправки', 'Проверяются фиксированные сочетания профильного сопротивления Wing/GO/VO, трения Fuselage/Gondola, щелей и антенн.'],
  ['Ограничение', 'Книжная кривая — эталон проверки конкретного МиГ-29, а не универсальная калибровка будущих самолётов.'],
  ['M=1,60…1,70', 'Используется фиксированный переход от продолжения последнего тренда MachLine к VSPAERO CD(CL=0); вес MachLine линейно уменьшается до нуля при M=1,70.'],
  ['Автономность Excel', 'Все графики используют только ячейки этой книги. CSV/JSON нужны лишь один раз при создании XLSX; после создания внешние файлы и ссылки не требуются.'],
  ['Исходные данные', here],
  ['Итоговый файл', outputPath],
];
notes.getRange(`A3:B${noteRows.length + 2}`).values = noteRows;
styleHeader(notes.getRange('A3:B3'));
notes.getRange(`A4:A${noteRows.length + 2}`).format = { fill: colors.light, font: { bold: true, color: colors.navy, size: 10 }, wrapText: true, verticalAlignment: 'top' };
notes.getRange(`B4:B${noteRows.length + 2}`).format = { font: { size: 10 }, wrapText: true, verticalAlignment: 'top', rowHeight: 34 };
setWidths(notes, [['A:A', 22], ['B:B', 100], ['C:H', 4]], 50);

for (const sheet of [overview, liftSheet, fullLiftSheet, subSheet, dash, scoreSheet, convSheet, rawSheet, notes]) {
  try { sheet.getUsedRange().format.borders = { bottom: { color: colors.line, style: 'hair' } }; } catch {}
}

const exported = await SpreadsheetFile.exportXlsx(wb);
await exported.save(outputPath);

const verification = {
  overview: (await wb.inspect({ kind: 'table', range: "'Сводка АДХ'!A1:P37", include: 'values,formulas', table_max_rows: 40, table_max_cols: 16 })).ndjson,
  lift: (await wb.inspect({ kind: 'table', range: "'Подъёмная сила'!A1:J36", include: 'values,formulas', table_max_rows: 40, table_max_cols: 10 })).ndjson,
  fullLift: (await wb.inspect({ kind: 'table', range: "'Cy полный диапазон'!A1:L55", include: 'values,formulas', table_max_rows: 55, table_max_cols: 12 })).ndjson,
  subsonic: (await wb.inspect({ kind: 'table', range: "'Дозвук Cx0'!A1:I31", include: 'values,formulas', table_max_rows: 35, table_max_cols: 9 })).ndjson,
  best: (await wb.inspect({ kind: 'table', range: "'Лучший расчёт'!A1:P46", include: 'values,formulas', table_max_rows: 50, table_max_cols: 16 })).ndjson,
  scores: (await wb.inspect({ kind: 'table', range: "'Конфигурации'!A1:J15", include: 'values,formulas', table_max_rows: 15, table_max_cols: 10 })).ndjson,
  drawings: (await wb.inspect({ kind: 'drawing', include: 'sheet,name,type', maxChars: 8000 })).ndjson,
  errors: (await wb.inspect({ kind: 'match', searchTerm: '#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A', options: { useRegex: true, maxResults: 100 } })).ndjson,
};
if (!/(match_count[^0-9]*0|matched 0 entries)/i.test(verification.errors)) throw new Error(`Workbook formula-error verification was inconclusive: ${verification.errors}`);
fs.writeFileSync(path.join(here, 'workbook_verification.json'), JSON.stringify(verification, null, 2), 'utf8');

for (const [sheetName, range] of [
  ['Сводка АДХ', 'A1:P37'], ['Подъёмная сила', 'A1:P55'], ['Cy полный диапазон', 'A1:AC55'], ['Дозвук Cx0', 'A1:P48'],
  ['Лучший расчёт', 'A1:P46'], ['Конфигурации', 'A1:J24'], ['Сеточная сходимость', 'A1:K35'],
  ['Сырые данные', `A1:${rawLastColumn}35`], ['Методика', `A1:H${noteRows.length + 2}`],
]) {
  const image = await wb.render({ sheetName, range, scale: ['Сводка АДХ', 'Подъёмная сила', 'Дозвук Cx0', 'Лучший расчёт'].includes(sheetName) ? 1.25 : 1.0 });
  fs.writeFileSync(path.join(previewDir, `${sheetName.replaceAll(' ', '_')}.png`), Buffer.from(await image.arrayBuffer()));
}

console.log(JSON.stringify({ outputPath, sheets: wb.worksheets.items.map(sheet => sheet.name), best: config }, null, 2));
