#!/usr/bin/env python3
"""Build the non-transonic RepairMach lift dataset from completed VSPAERO polars."""

from __future__ import annotations

import csv
import math
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
POLARS = (
    ROOT / "overnight_sweep" / "semiempirical_drag" / "full_grid"
    / "subsonic_M0p0_0p8" / "subsonic_M0p0_0p8.polar",
    ROOT / "overnight_sweep" / "semiempirical_drag" / "full_grid"
    / "supersonic_M1p1_2p2" / "supersonic_M1p1_2p2.polar",
)
BALANCED_SUMMARY = ROOT / "overnight_sweep" / "final_balanced_summary.csv"
BALANCED_POLARS = ROOT / "overnight_sweep" / "final_balanced_polars.csv"

# Approximate digitization of the book's fixed-stabilizer Cy_alpha(M) curve.
# Transonic values are intentionally omitted from the final dataset.
BOOK_FIXED = {
    0.4: 0.070,
    0.6: 0.075,
    0.8: 0.083,
    1.2: 0.099,
    1.3: 0.090,
    1.5: 0.073,
    1.7: 0.062,
    2.0: 0.053,
}


def read_polar(path: Path) -> list[dict[str, float]]:
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    header_index = next(
        index for index, line in enumerate(lines)
        if "Mach" in line and "AoA" in line and "CLtot" in line and "CMytot" in line
    )
    names = lines[header_index].split()
    selected = ("Mach", "AoA", "CLtot", "CDtot", "CMytot")
    indices = {name: names.index(name) for name in selected}
    rows: list[dict[str, float]] = []
    for line in lines[header_index + 1:]:
        values = line.split()
        if len(values) != len(names):
            continue
        try:
            row = {name: float(values[index]) for name, index in indices.items()}
        except ValueError:
            continue
        if all(math.isfinite(value) for value in row.values()):
            rows.append(row)
    return rows


def linear_fit(x: list[float], y: list[float]) -> tuple[float, float, float]:
    x_mean = sum(x) / len(x)
    y_mean = sum(y) / len(y)
    denominator = sum((value - x_mean) ** 2 for value in x)
    slope = sum((a - x_mean) * (b - y_mean) for a, b in zip(x, y)) / denominator
    intercept = y_mean - slope * x_mean
    residual = sum((b - (intercept + slope * a)) ** 2 for a, b in zip(x, y))
    total = sum((b - y_mean) ** 2 for b in y)
    r2 = 1.0 - residual / total if total else 1.0
    return slope, intercept, r2


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    HERE.mkdir(parents=True, exist_ok=True)
    raw = [row for path in POLARS for row in read_polar(path)]
    selected = [
        row for row in raw
        if (row["Mach"] <= 0.8 + 1e-8 or row["Mach"] >= 1.2 - 1e-8)
        and -1e-8 <= row["AoA"] <= 5.0 + 1e-8
    ]
    selected.sort(key=lambda row: (row["Mach"], row["AoA"]))

    groups: dict[float, list[dict[str, float]]] = {}
    for row in selected:
        groups.setdefault(round(row["Mach"], 6), []).append(row)

    # The closed full-body VSPAERO model has repeatable numerical singularities:
    # M=1.40 is divergent, M=1.45...1.53 is NaN, and M=1.90...2.10 produces
    # non-smooth finite outliers. An independent one-point M=1.40 rerun with
    # NCPU=1 and WakeNumIter=3 also diverged after 500 GMRES iterations.
    # We therefore reject those rows and linearly interpolate alpha-by-alpha
    # only between stable DIRECT full-model solutions. No book ordinate is used.
    interpolation_brackets = {
        1.4: (1.3, 1.6),
        1.5: (1.3, 1.6),
        1.9: (1.8, 2.2),
        2.0: (1.8, 2.2),
        2.1: (1.8, 2.2),
    }
    for target_mach, (lower_mach, upper_mach) in interpolation_brackets.items():
        lower_by_alpha = {round(row["AoA"], 6): row for row in groups[lower_mach]}
        upper_by_alpha = {round(row["AoA"], 6): row for row in groups[upper_mach]}
        fraction = (target_mach - lower_mach) / (upper_mach - lower_mach)
        interpolated = []
        for alpha in range(6):
            lower = lower_by_alpha.get(float(alpha))
            upper = upper_by_alpha.get(float(alpha))
            if lower is None or upper is None:
                raise RuntimeError(
                    f"Missing M={lower_mach:.2f}/{upper_mach:.2f} bracket at alpha={alpha}"
                )
            row = {"Mach": target_mach, "AoA": float(alpha)}
            for field in ("CLtot", "CDtot", "CMytot"):
                row[field] = lower[field] + fraction * (upper[field] - lower[field])
            row["CL_bracket_half_span"] = 0.5 * abs(upper["CLtot"] - lower["CLtot"])
            row["interpolation_lower_mach"] = lower_mach
            row["interpolation_upper_mach"] = upper_mach
            interpolated.append(row)
        groups[target_mach] = interpolated

    expected_mach = [round(value / 10, 1) for value in range(0, 9)] + [round(value / 10, 1) for value in range(12, 23)]
    if sorted(groups) != expected_mach:
        raise RuntimeError(f"Incomplete Mach grid: got {sorted(groups)}, expected {expected_mach}")

    point_rows: list[dict[str, object]] = []
    derivative_rows: list[dict[str, object]] = []
    for mach in expected_mach:
        points = sorted(groups[mach], key=lambda row: row["AoA"])
        alphas = [round(point["AoA"], 6) for point in points]
        if alphas != [0, 1, 2, 3, 4, 5]:
            raise RuntimeError(f"Incomplete alpha grid at M={mach}: {alphas}")
        cy = [point["CLtot"] for point in points]
        slope, intercept, r2 = linear_fit(alphas, cy)
        local = [cy[index + 1] - cy[index] for index in range(5)]
        book = BOOK_FIXED.get(mach)
        derivative_rows.append({
            "mach": mach,
            "regime": "subsonic" if mach <= 0.8 else "supersonic",
            "Cy0": cy[0],
            "Cy1": cy[1],
            "Cy2": cy[2],
            "Cy3": cy[3],
            "Cy4": cy[4],
            "Cy5": cy[5],
            "Cy_alpha_0_1_per_deg": local[0],
            "Cy_alpha_1_2_per_deg": local[1],
            "Cy_alpha_2_3_per_deg": local[2],
            "Cy_alpha_3_4_per_deg": local[3],
            "Cy_alpha_4_5_per_deg": local[4],
            "Cy_alpha_linear_0_5_per_deg": slope,
            "Cy_linear_intercept": intercept,
            "linear_fit_R2": r2,
            "book_fixed_Cy_alpha_approx": book,
            "book_error_pct": (100.0 * (slope - book) / book) if book else None,
            "calculation_status": (
                f"interpolation M{interpolation_brackets[mach][0]:.1f}-M{interpolation_brackets[mach][1]:.1f}"
                if mach in interpolation_brackets else "direct VSPAERO"
            ),
            "max_Cy_bracket_half_span": max(
                float(point.get("CL_bracket_half_span", 0.0)) for point in points
            ),
        })
        for point in points:
            point_rows.append({
                "mach": mach,
                "regime": "subsonic" if mach <= 0.8 else "supersonic",
                "alpha_deg": point["AoA"],
                "Cy_CLtot": point["CLtot"],
                "Cx_CDtot": point["CDtot"],
                "CMy": point["CMytot"],
                "method": (
                    f"linear interpolation of stable full-model VSPAERO solutions "
                    f"M={interpolation_brackets[mach][0]:.1f}/{interpolation_brackets[mach][1]:.1f}; "
                    "GO incidence from VSP model"
                    if mach in interpolation_brackets else
                    "direct VSPAERO full corrected closed model; GO incidence from VSP model"
                ),
                "source_polar": str(
                    POLARS[0] if mach <= 0.8 else POLARS[1]
                ),
            })

    write_csv(HERE / "cy_full_range_points.csv", point_rows)
    write_csv(HERE / "cy_alpha_full_range.csv", derivative_rows)

    balanced_summary = list(csv.DictReader(BALANCED_SUMMARY.open(encoding="utf-8-sig", newline="")))
    balanced_points = list(csv.DictReader(BALANCED_POLARS.open(encoding="utf-8-sig", newline="")))
    write_csv(HERE / "balanced_validation_summary.csv", [dict(row) for row in balanced_summary])
    write_csv(HERE / "balanced_validation_points.csv", [dict(row) for row in balanced_points])

    measured = [row for row in derivative_rows if row["book_fixed_Cy_alpha_approx"] is not None]
    mean_abs = sum(abs(float(row["book_error_pct"])) for row in measured) / len(measured)
    max_abs = max(abs(float(row["book_error_pct"])) for row in measured)
    report_lines = [
        "# Полный диапазон подъёмной силы RepairMach 9.1",
        "",
        "## Итог",
        "",
        f"- Расчётных чисел М: {len(derivative_rows)}.",
        f"- Расчётных точек Cy: {len(point_rows)}.",
        "- Дозвук: M=0,0…0,8 с шагом 0,1.",
        "- Сверхзвук: M=1,2…2,2 с шагом 0,1.",
        "- Транзвуковая область M=0,9…1,1 исключена.",
        "- Углы атаки: 0…5° с шагом 1°.",
        "- Прямые точки M=1,40…1,50 отклонены: повтор M=1,40 с NCPU=1 и тремя итерациями следа расходился после 500 итераций GMRES; полоса M=1,45…1,53 давала NaN.",
        "- M=1,40 и 1,50 интерполированы по устойчивым прямым решениям M=1,30/1,60; M=1,90…2,10 — по M=1,80/2,20, поскольку исходные конечные числа нарушали гладкость Cyα(M).",
        "- Интерполяция выполнялась отдельно для каждого угла атаки и не использует книжную кривую.",
        "- Cyα основной: Cy(1°) − Cy(0°); дополнительно сохранены все локальные шаги и линейный наклон 0…5°.",
        f"- Средняя абсолютная ошибка линейного Cyα на доступных книжных узлах: {mean_abs:.2f}%.",
        f"- Максимальная абсолютная ошибка линейного Cyα на доступных книжных узлах: {max_abs:.2f}%.",
        "",
        "## Методика",
        "",
        "Использована одна исправленная замкнутая VSP-модель во всём диапазоне. Значение Cy — поле CLtot VSPAERO при β=0. Балансировочный угол ГО в этом полном ряду равен углу, записанному в VSP-модели; отдельные ранее проверенные моментно-сбалансированные точки M=0,8, 1,2 и 1,7 сохранены в Excel как независимая валидация.",
        "",
        "## Cyα по числам М",
        "",
        "| M | Режим | Cy(0°) | Cy(5°) | Cyα 0→1 | Cyα лин. 0…5 | R² | Книга | Ошибка | Статус |",
        "|---:|:---|---:|---:|---:|---:|---:|---:|---:|:---|",
    ]
    for row in derivative_rows:
        book = row["book_fixed_Cy_alpha_approx"]
        error = row["book_error_pct"]
        report_lines.append(
            f"| {row['mach']:.1f} | {row['regime']} | {row['Cy0']:.6f} | {row['Cy5']:.6f} | "
            f"{row['Cy_alpha_0_1_per_deg']:.6f} | {row['Cy_alpha_linear_0_5_per_deg']:.6f} | "
            f"{row['linear_fit_R2']:.6f} | {book:.5f} | {error:+.2f}% | {row['calculation_status']} |"
            if book is not None else
            f"| {row['mach']:.1f} | {row['regime']} | {row['Cy0']:.6f} | {row['Cy5']:.6f} | "
            f"{row['Cy_alpha_0_1_per_deg']:.6f} | {row['Cy_alpha_linear_0_5_per_deg']:.6f} | "
            f"{row['linear_fit_R2']:.6f} | — | — | {row['calculation_status']} |"
        )
    (HERE / "REPORT.md").write_text("\n".join(report_lines) + "\n", encoding="utf-8")
    print(f"Wrote {len(point_rows)} points and {len(derivative_rows)} Mach summaries")
    print(HERE / "REPORT.md")


if __name__ == "__main__":
    main()
