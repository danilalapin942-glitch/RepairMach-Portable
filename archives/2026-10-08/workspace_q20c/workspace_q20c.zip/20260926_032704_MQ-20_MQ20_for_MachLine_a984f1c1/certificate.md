# Сертификат геометрии RepairMach

- ID: `RMC-E25FE112E67AA319`
- Методика: `RM91-GEOMETRY-CERT-1`
- Вердикт: **FAIL**
- Создан: 2026-09-26T03:27:23+03:00
- MASTER: `5710974615718259376ea2aca54fd14efa1837069e1b031d1461485dac955fbd`
- MASTER неизменён: **да**
- Пригодность для решателя: **нет**
- Представлена полная геометрия: **нет**
- Требуется гибридная замена: **нет**

Сертификат подтверждает прослеживаемость и пригодность геометрии для указанной постановки. Он не подтверждает аэродинамическую точность и не заменяет сеточную или экспериментальную верификацию.

## Область действия

- Запрошенный Mach: `[[0.0, 0.8], [1.2, 2.2]]`
- Запрошенный alpha: `[0.0, 5.0]` град
- Квалификационный профиль: `full_anchor_envelope`
- Подтверждённых опорных точек: `0`

## Backends

| Backend | Пригоден | Постановка | Подтверждённая область |
|---|---:|---|---|
| vspaero | нет | None | none |
| machline | нет | None | none |
| parasite_drag | нет | None | none |
| hybrid | нет | direct_or_optional | none |

## Численный двойник MachLine

Полная составная сетка используется для аудита всей геометрии. В решатель передаётся только водонепроницаемая толстотельная часть; тонкие Wing/GO/VO остаются в контуре VSPAERO.

- Геометрический допуск: **нет**
- Маскированное давление/волна для гибрида: **нет**
- Самостоятельная полная сила без донной поправки: **нет**
- Полная аудиторская сетка: `15424` панелей
- Сетка решателя: `10432` панелей; watertight=`True`
- Ограниченный ремонт: `0` из `77` разрешённых панелей

### Геометрический Mach-критерий

| M | alpha, град | Недопустимых панелей | Минимальный запас |
|---:|---:|---:|---:|
| 1.2 | 0.0 | 1176 | 0.166667 |
| 1.2 | 5.0 | 1174 | 0.163777 |
| 2.2 | 0.0 | 1506 | 0.545455 |
| 2.2 | 5.0 | 1505 | 0.542565 |

## Преобразования

Преобразования геометрии не потребовались.

## Исключения

Нет.

## Диагностика

| Код | Уровень | Компонент | Сообщение |
|---|---|---|---|
| `GEO-MACH-001` | BLOCKER |  | MachLine-критерий не выполнен во всём диапазоне Mach и alpha; автоматическое абсолютное смещение вершин запрещено |
| `GEO-MACH-SOLVER-001` | BLOCKER |  | Подготовленная толстотельная сетка не прошла реальные угловые пробы MachLine и проверку маскированных сил |

## План дальнейших действий

- Состояние: **blocked**
- Можно выпускать расчёт без дополнительных действий: **нет**
- Обязательных действий: `2`; блокирующих: `2`; автоматизируемых: `1`
- Минимально повторить этапы: `inventory, semantic_audit, transformation_plan, solver_twins, mesh_ladder, machline_export, machline_qualification, hybrid_assembly, workbook, certificate`
- Повторно проверить backends: `machline, hybrid`
- Ветви без незакрытых действий: `vspaero=да, machline=нет, parasite_drag=да, hybrid=нет`
- Новый сертификат геометрии: **да**

| Приоритет | ID | Владелец | Компонент | Причина | Маршрут | Действие | Минимальный повтор |
|---:|---|---|---|---|---|---|---|
| 1 | `CA-001` | operator |  | `GEO-MACH-001` | `CORRECT_SUPERSONIC_PANEL_ORIENTATION` | Исправить поверхности, нарушающие сверхзвуковой геометрический критерий, и повторить всю сеточную лестницу MachLine. | inventory, semantic_audit, transformation_plan, solver_twins, mesh_ladder, machline_export, machline_qualification, hybrid_assembly, workbook, certificate |
| 1 | `CA-002` | repairmach |  | `GEO-MACH-SOLVER-001` | `REQUALIFY_MACHLINE_NUMERICS` | Повторить независимые пробы MachLine на полной сеточной лестнице; при повторном отказе передать оператору локализованный компонент. | machline_qualification, hybrid_assembly, workbook, certificate |

## Артефакты

- Семантический аудит: `C:\Users\admin\.codex\.chatgpt-projects\g-p-6910508be2a081919b9cb5881a96c92b\q20c\20260926_032704_MQ-20_MQ20_for_MachLine_a984f1c1\semantic_audit.json`
- Исходная диагностика: `C:\Users\admin\.codex\.chatgpt-projects\g-p-6910508be2a081919b9cb5881a96c92b\q20c\20260926_032704_MQ-20_MQ20_for_MachLine_a984f1c1\native_diagnostics.json`
- План: `C:\Users\admin\.codex\.chatgpt-projects\g-p-6910508be2a081919b9cb5881a96c92b\q20c\20260926_032704_MQ-20_MQ20_for_MachLine_a984f1c1\transformation_plan.json`
- Отклонения: `C:\Users\admin\.codex\.chatgpt-projects\g-p-6910508be2a081919b9cb5881a96c92b\q20c\20260926_032704_MQ-20_MQ20_for_MachLine_a984f1c1\geometry_deltas.json`
- План дальнейших действий: `C:\Users\admin\.codex\.chatgpt-projects\g-p-6910508be2a081919b9cb5881a96c92b\q20c\20260926_032704_MQ-20_MQ20_for_MachLine_a984f1c1\corrective_action_plan.json`
