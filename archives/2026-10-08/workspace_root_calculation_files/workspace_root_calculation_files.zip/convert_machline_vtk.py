from pathlib import Path

src = Path(r"C:\RepairMach\05_machline_results\vtk\MIG_full_M15_a0_body.vtk")
out = Path(__file__).with_name("MIG_full_M15_a0_body.vtp")
lines = src.read_text(encoding="ascii").splitlines()


def index(prefix: str) -> int:
    return next(i for i, line in enumerate(lines) if line.startswith(prefix))


points_header = index("POINTS ")
point_count = int(lines[points_header].split()[1])
points = [" ".join(line.split()) for line in lines[points_header + 1 : points_header + 1 + point_count]]

polygons_header = index("POLYGONS ")
polygon_count = int(lines[polygons_header].split()[1])
polygon_rows = [line.split() for line in lines[polygons_header + 1 : polygons_header + 1 + polygon_count]]
connectivity = [" ".join(row[1:]) for row in polygon_rows]
offsets = [str(3 * (i + 1)) for i in range(polygon_count)]

cp_header = next(i for i, line in enumerate(lines) if line.startswith("SCALARS C_p_ise "))
cp = [" ".join(line.split()) for line in lines[cp_header + 2 : cp_header + 2 + polygon_count]]

with out.open("w", encoding="ascii", newline="\n") as file:
    file.write('<?xml version="1.0"?>\n')
    file.write('<VTKFile type="PolyData" version="0.1" byte_order="LittleEndian">\n<PolyData>\n')
    file.write(
        f'<Piece NumberOfPoints="{point_count}" NumberOfVerts="0" NumberOfLines="0" '
        f'NumberOfStrips="0" NumberOfPolys="{polygon_count}">\n'
    )
    file.write('<PointData/>\n<CellData Scalars="C_p_ise">\n')
    file.write('<DataArray type="Float64" Name="C_p_ise" format="ascii">\n')
    file.write("\n".join(cp) + "\n</DataArray>\n</CellData>\n")
    file.write('<Points>\n<DataArray type="Float64" NumberOfComponents="3" format="ascii">\n')
    file.write("\n".join(points) + "\n</DataArray>\n</Points>\n")
    file.write('<Polys>\n<DataArray type="Int32" Name="connectivity" format="ascii">\n')
    file.write("\n".join(connectivity) + "\n</DataArray>\n")
    file.write('<DataArray type="Int32" Name="offsets" format="ascii">\n')
    file.write(" ".join(offsets) + "\n</DataArray>\n</Polys>\n")
    file.write("</Piece>\n</PolyData>\n</VTKFile>\n")

print(out)
print(out.stat().st_size)
