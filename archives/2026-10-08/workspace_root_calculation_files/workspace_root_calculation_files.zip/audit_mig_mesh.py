from collections import defaultdict
from math import acos, degrees, sqrt
from pathlib import Path

tri_path = Path(r"C:\RepairMach\02_working_meshes\final\MIG_full_auto.tri")
vtk_path = Path(r"C:\RepairMach\05_machline_results\vtk\MIG_full_M15_a0_body.vtk")

rows = tri_path.read_text(encoding="ascii").splitlines()
nv, nf = map(int, rows[0].split())
vertices = [tuple(map(float, row.split())) for row in rows[1 : 1 + nv]]
faces = [tuple(int(x) - 1 for x in row.split()) for row in rows[1 + nv : 1 + nv + nf]]

parent = list(range(nv))


def find(a):
    while parent[a] != a:
        parent[a] = parent[parent[a]]
        a = parent[a]
    return a


def union(a, b):
    a, b = find(a), find(b)
    if a != b:
        parent[b] = a


edges = defaultdict(list)
areas = []
normals = []
degenerate = []
for fi, (a, b, c) in enumerate(faces):
    union(a, b)
    union(b, c)
    for u, v in ((a, b), (b, c), (c, a)):
        edges[tuple(sorted((u, v)))].append((fi, u, v))
    pa, pb, pc = vertices[a], vertices[b], vertices[c]
    ab = tuple(pb[i] - pa[i] for i in range(3))
    ac = tuple(pc[i] - pa[i] for i in range(3))
    cr = (ab[1]*ac[2]-ab[2]*ac[1], ab[2]*ac[0]-ab[0]*ac[2], ab[0]*ac[1]-ab[1]*ac[0])
    mag = sqrt(sum(x*x for x in cr))
    areas.append(0.5 * mag)
    if mag == 0:
        degenerate.append(fi)
        normals.append((0.0, 0.0, 0.0))
    else:
        normals.append(tuple(x / mag for x in cr))

boundary = [e for e, uses in edges.items() if len(uses) == 1]
nonmanifold = [e for e, uses in edges.items() if len(uses) > 2]
same_direction = []
for e, uses in edges.items():
    if len(uses) == 2:
        _, u1, v1 = uses[0]
        _, u2, v2 = uses[1]
        if u1 == u2 and v1 == v2:
            same_direction.append(e)

min_dot = 1.0
min_pair = None
vertex_faces = defaultdict(list)
for fi, face in enumerate(faces):
    for v in face:
        vertex_faces[v].append(fi)
for v, fs in vertex_faces.items():
    for ii, f1 in enumerate(fs):
        n1 = normals[f1]
        for f2 in fs[ii + 1 :]:
            n2 = normals[f2]
            dot = max(-1.0, min(1.0, sum(n1[k] * n2[k] for k in range(3))))
            if dot < min_dot:
                min_dot = dot
                min_pair = (v, f1, f2)

vtk = vtk_path.read_text(encoding="ascii").splitlines()
cp_i = next(i for i, line in enumerate(vtk) if line.startswith("SCALARS C_p_ise "))
cp = [float(line.split()[0]) for line in vtk[cp_i + 2 : cp_i + 2 + nf]]
vac = -0.634920634920635

component_faces = defaultdict(list)
for fi, face in enumerate(faces):
    component_faces[find(face[0])].append(fi)

print(f"vertices={nv} faces={nf} unique_edges={len(edges)}")
print(f"boundary_edges={len(boundary)} nonmanifold_edges={len(nonmanifold)} same_direction_pairs={len(same_direction)}")
print(f"degenerate_faces={len(degenerate)} min_area={min(areas):.6g}")
print(f"connected_components={len(component_faces)}")
print(f"max_vertex_normal_angle_deg={degrees(acos(min_dot)):.9f} vertex={min_pair[0]+1} panels={min_pair[1]+1},{min_pair[2]+1}")
problem_vertex, problem_face_1, problem_face_2 = min_pair
print(f"problem_vertex_xyz={vertices[problem_vertex]}")
for problem_face in (problem_face_1, problem_face_2):
    print(
        f"problem_panel={problem_face+1} vertices={tuple(v+1 for v in faces[problem_face])} "
        f"normal={normals[problem_face]} area={areas[problem_face]:.9g} Cp={cp[problem_face]:.9g}"
    )
print("largest components: panels, vacuum%, bbox")
for root, fs in sorted(component_faces.items(), key=lambda item: len(item[1]), reverse=True)[:20]:
    vids = {v for fi in fs for v in faces[fi]}
    xyz = [vertices[v] for v in vids]
    bbox = tuple((min(p[k] for p in xyz), max(p[k] for p in xyz)) for k in range(3))
    vacuum_fraction = 100 * sum(abs(cp[fi] - vac) < 1e-8 for fi in fs) / len(fs)
    print(len(fs), f"{vacuum_fraction:.3f}%", bbox)
